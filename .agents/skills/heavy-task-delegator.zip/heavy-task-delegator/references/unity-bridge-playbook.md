# Unity Bridge Playbook (unity-synaptic)

Purpose: stop the "poke the editor until something works" failure mode. Every rule
below exists because it cost real calls in a real session (evidence column).

Applies to the pi tools `unity_list_categories`, `unity_list_tools`,
`unity_search_tools`, `unity_execute`, `unity_run_csharp`, `unity_inspect`,
`unity_modify`, `unity_create` — and to any MCP client talking to
`unity-synaptic` (`unity-mcp v1.1.0`, 358 inner tools).

---

## 0. Budget (hard stop)

| Phase | Max calls | What counts |
|---|---|---|
| Recon | 3 | find the object/scene + read one sample schema |
| Act | 3 | the mutations that produce the end state |
| Verify | 2 | authoritative read-back + `git diff` |

Over budget → stop and report what is known/unknown. **Do not keep poking.**
Mutating calls that return empty/unknown are *not* success; they are unknowns.

## 1. Tool discovery — never guess a name

- 9 meta-tools only: `list_categories`, `list_tools`, `search_tools`,
  `get_tools_reference`, `execute`, `run_csharp`, `inspect`, `modify`, `create`.
  The other ~358 live behind **`unity_execute(tool_name, params)`**.
- **Guessing a `unity_*` name is a policy breach.** Guessed wrong in a real session:
  `unity_get_project_info`, `unity_open_scene`, `unity_get_component` (3 calls burnt),
  while the tools that existed all along were `unity_get_project_stats`,
  `unity_load_scene`, `unity_get_component_details`.
- **First move on any new Unity task: grep the on-disk catalog** (free, 0 bridge calls):
  `grep -i "scene" references/unity-tools-catalog.md` — regenerated from
  `unity_get_tools_reference()` and version-pinned below.
- `list_tools(category)` / `search_tools(q)` **can crash** with
  `UnicodeEncodeError: 'charmap' codec can't encode character '\U0001f3ac'`
  (emoji in tool titles, Windows cp1258 stdout). One crash = change strategy:
  use `list_categories` (plain text, safe) or grep the catalog instead.
  **Never retry the same failing call.**

## 2. Verified tool table

Verified against Unity 6000.3.27f1, unity-mcp 1.1.0 (2026-10-25).

| Need | Tool | Required params |
|---|---|---|
| Editor truth (play/compile/FPS/mem) | `unity_get_runtime_status` | — |
| Compile errors | `unity_analyze_console_logs` | `logType:"error"`, `limit`, `includeStackTrace` |
| Console summary / clear | `unity_console` | `operation`, `logType`, `limit` |
| Build scene list (read) | `unity_get_build_settings` | — |
| Build scene list (write) | `unity_add_scene_to_build` | `scenePath`, `operation`, `buildIndex` (-1 = append) |
| All scenes on disk + in-build flag | `unity_list_all_scenes` | `includeInactive`, `sortBy`, `searchPath` |
| Load scene | `unity_load_scene` | `scenePath` \| `sceneName`, `mode: Single\|Additive`, `setActive` |
| Save / new scene | `unity_manage_scene` | `operation`, `path` |
| Active scene | `unity_set_active_scene` | `sceneName` |
| Unload scene | `unity_unload_scene` | `sceneName`, `removeUnsavedChanges` |
| Scene summary (cheap) | `unity_get_scene_summary` | — |
| Scene full dump (**>1MB — avoid**) | `unity_get_scene_info` | — |
| Add component | `unity_add_component` | `gameObject`, `component` |
| Set component props | `unity_update_component` | `gameObject`, `component`, … |
| Read component fields | `unity_get_component_details` | `gameObjectName`, `componentType`, `includeSerializedProperties` |
| Find objects by type | `unity_find_gameobjects_by_component` | `componentType`, `includeInactive` |
| Inspect anything | `unity_dynamic_inspect` | `target: gameobject\|component\|scene\|project\|prefabs\|hierarchy`, `name`, `component`, `path` |
| Inspector dump | `unity_get_inspector_info` | `gameObjectName`, `componentFilter` |
| PlayerSettings | `unity_get_player_settings` | — |
| Build status | `unity_get_build_status` | — |
| Project stats | `unity_get_project_stats` | — |
| Refresh + recompile | `unity_force_refresh_assets` | `importMode: default\|force\|forcesynchronous` |
| Menus (e.g. enter Play) | `unity_execute_menu_item` | `menuPath` (e.g. `Edit/Play`) |
| Screenshot Scene view | `unity_capture_scene_view` | `filename`, `path` |
| Screenshot Game view (auto Play) | `unity_capture_game_view` → wait 3s → `unity_get_screenshot_result` | `view` |
| Play-state monitoring | `unity_monitor_play_state` | `enable` |
| Compile monitoring | `unity_monitor_compile` | `enable` |

Known-unreliable through the pi wrapper (returned `exit null: (no output)` on
`unity_inspect target=component` and on `unity_execute_batch`): **do not use them as
verification**. If a call has no body, treat it as unverified and re-read with
`unity_get_runtime_status` / `unity_get_build_settings` / `git diff`.

## 3. `run_csharp` contract

- **≤3 statements + exactly one `return <expr>;`.** Fully-qualified types.
- **No** `var`, `foreach`, LINQ, `StringBuilder`, `new` collections — a first attempt
  with those returned `Expected result but none captured` plus **50 KB of
  `Mono.CSharp warning CS1685`** dumped into context (duplicate `System.Object`
  from unityjit mscorlib — harmless noise, never diagnose it).
- Working shape (verified):

```csharp
UnityEditor.EditorBuildSettings.scenes = new UnityEditor.EditorBuildSettingsScene[] {
  new UnityEditor.EditorBuildSettingsScene("Assets/Scenes/Game.unity", true)
};
UnityEditor.AssetDatabase.SaveAssets();
return UnityEditor.EditorBuildSettings.scenes.Length;
```

- A `return expr;` statement is *not* proof the mutation happened → **always read back**
  with the dedicated getter, then `git diff` the settings file.
- Compile-check after writing a `.cs`: `unity_analyze_console_logs(logType:"error")`
  then `unity_force_refresh_assets`. **Never** grep `Editor.log` for `error CS` — it
  matches the Mono.CSharp eval noise and truncates at 50 KB. Cheap local proof of a
  new type: `ls -l --time-style=+%H:%M:%S Library/ScriptAssemblies/Assembly-CSharp.dll`
  newer than the `.cs`, plus `grep -c <TypeName> Library/ScriptAssemblies/Assembly-CSharp.dll`.

## 4. Verification ladder (cheapest to most expensive)

1. `unity_get_runtime_status` — play mode, paused, compiling, **Compilation: OK**, FPS.
2. The dedicated getter for what you changed (`unity_get_build_settings`,
   `unity_get_component_details`, `unity_get_player_settings`).
3. `git diff --stat` for on-disk truth (ProjectSettings/*.asset, scenes).
4. `unity_analyze_console_logs(logType:"error")` for compile/runtime errors.
5. `Editor.log` grep — **last resort**, always filtered to a path or a type name.

## 5. Scene & project edits: tools before YAML

- Hand-editing `.unity` / `ProjectSettings/*.asset` YAML is the **last** option.
  Real cost: a camera `<Component>` was inserted by hand with an invented `fileID`,
  then validated only by loading the scene, while `unity_add_component` +
  `unity_update_component` existed.
- YAML is acceptable only when: (a) no tool covers it, (b) the insertion point is
  unique, (c) `fileID`/`guid` uniqueness is grep-checked, (d) the scene is loaded
  immediately after to prove it parses, (e) the new component is read back.
- After any scene edit, `EditorSceneManager` marks dirty state — say whether the
  scene is saved or left dirty; never silently save the user's scene.

## 6. Mutation policy

Ask before, or state it and revert after:

- `unity_load_scene` / `unity_unload_scene` — closes the user's open scene.
- Entering Play mode (`unity_execute_menu_item "Edit/Play"`,
  `unity_run_csharp` with `EditorApplication.isPlaying = true`) — steals the editor.
  Note: `unity_capture_game_view` enters Play mode automatically.
- `unity_force_refresh_assets(importMode: force|forcesynchronous)` — full reimport.
- Any `build` / package / HybridCLR menu item.

Read-only calls (`get_*`, `list_*`, `inspect`, `analyze_*`, `console` read) are free
to use inside the budget.

## 7. Playtest recipe (verified end to end)

1. `unity_list_all_scenes(includeInactive:true)` → which scenes exist.
2. `unity_get_build_settings` → what is in the build list (may be stale/empty).
3. `unity_add_scene_to_build` per scene, entry scene `buildIndex: 0`.
4. `unity_get_build_settings` → read back (authoritative), then `git diff`.
5. Playtest in editor: `unity_execute_menu_item "Edit/Play"`, then
   `unity_get_runtime_status` (expect `Play Mode: True`), then
   `unity_capture_game_view` + 3 s + `unity_get_screenshot_result` as evidence.
6. Standalone: build via `project.yaml` `commands.build`, run `commands.run`.

## 8. Modal dialog = blocked main thread (the real reason calls "hang")

**Symptom:** `unity_execute` / `unity_inspect` / `unity_run_csharp` sits for ~180 s and
returns `exit null: (no output)`, or the whole bridge stops answering. Nothing was wrong
with the tool name or the params.

**Chain (verified 2026-10-25):**

1. A **modal dialog** opens in the Editor — most often *"Scene has been modified
externally — Reload?"* after a `.unity` file was written outside Unity (hand-edited YAML,
`git checkout`/`restore`/`stash`, another tool), or unsaved-scene / compile-error /
play-mode dialogs.
2. A modal blocks the Editor **main thread**, so the Synaptic bridge never dequeues the
request and never replies.
3. `bin/mcp_call.py` waits `--timeout`, the pi extension's spawn timer fires at the same
180 s and **kills the child** (`code === null`) → `exit null: (no output)`.
4. **The request stays queued in Unity.** When the dialog is dismissed it executes —
late. Retrying therefore applies the change **twice** (double component, doubled scene
list entries, duplicated GameObjects).

**Rule: `exit null` / empty body is not a failure to retry — it is an unanswered
request. Stop, read state, then decide.**

- Never re-issue the same call. First `unity_get_runtime_status` (also check
  `unrelated` getters: `unity_get_build_settings`, `unity_get_component_details`) to see
  whether the queued call already landed.
- Ask the user to dismiss the popup; you cannot dismiss it from the bridge.
- The extension now reports `UNITY_BUSY — … blocked by a modal dialog` instead of the
  bare `exit null`, and the python client times out ~20 s before the kill timer.

**Prevention (do these instead):**

| Do not | Do |
|---|---|
| Hand-edit a `.unity` that is open in the Editor | Close it (`unity_load_scene` elsewhere) first, or edit through `unity_add_component` / `unity_update_component` so Unity writes the file itself |
| `git checkout` / `restore` / `stash` a `.unity` while the Editor is open | Stash only when the scene is closed, then `unity_force_refresh_assets` |
| Fire tool calls while `unity_get_runtime_status` says `Compiling: True` | Wait for `Compilation: OK` |
| Enter Play mode with compile errors | Fix first: `unity_analyze_console_logs(logType:"error")` |
| Retry a call that returned nothing | Read back, then report |

## 9. Bridge down vs Editor busy — do not keep calling

Two different failures, two different responses. Mixing them is why the same call got
re-sent into a dead socket and burned a full timeout each time.

| | **UNITY_DOWN** (link dead) | **UNITY_BUSY** (Editor blocked) |
|---|---|---|
| Evidence | `unityWebSocket not open (readyState=null)`, `server closed stdout`, `ENOENT`, `ECONNREFUSED`, `initialize` error | `exit null: (no output)`, node-side `error: timeout`, no reply |
| Where | node process alive, **Unity not connected** | Unity connected, **main thread stuck** on a modal |
| Response | **Stop. Do not send.** Recovery below | Dismiss the dialog, then **read state before retrying** |

Server facts (read from `MCPServer/index-supersave.js`):

- Unity is a **WebSocket client**; if it drops, the next command is rejected
  **instantly** with `unityWebSocket not open (readyState=null)` — a fast, cheap signal.
- Every Unity command has a **60 s** timeout inside node. If a call hangs *longer* than
  that, the Editor never dequeued it → modal, not network.
- pi spawns a **fresh node process per call**, so right after a Unity restart the first
  call can legitimately return `readyState=null`; give it a few seconds.

### The architecture that makes this work (or breaks it)

- **Unity is always the WebSocket client**, connecting to `ws://127.0.0.1:8090`
  (`NexusEditorMCPService.cs`, `GetServerUrl()`). The node process is the server.
- pi spawns **a new node process per tool call**. If no one keeps the port, each call
  becomes leader, answers, and **dies → the Unity socket drops with it**, then Unity has to
  auto-reconnect while the next call waits. That churn is the real "MCP keeps losing the
  connection" cause, not the network.
- Fix (now built into the extension): **one long-lived leader on :8090** (`ensureUnityLeader()`
  spawns it detached on first use); every pi call is a *follower* that forwards over HTTP
  (`shareModeLeaderPort` / `/execute`) and never touches the Unity socket.
- **`GET http://127.0.0.1:8090/health`** answers in ~600 ms without spawning anything:
  `{"status":"ok","mode":"supersave","shareMode":false,"unityConnected":true|false}`.
  `unityConnected:false` = server fine, Editor not attached → **fail in milliseconds**
  (`UNITY_DISCONNECTED`, breaker 15 s) instead of waiting 25 s for a silent timeout.
  Unity has auto-reconnect (`EditorPrefs NexusMCP_AutoReconnect`), so after fixing the
  Editor side just retry — no restart needed.
- Manually: `curl -s localhost:8090/health`, and to (re)start a leader by hand:
  `cd %LOCALAPPDATA%\Synaptic\MCPServer && node index-supersave.js`.

### The fast path the extension now uses (measured 2026-10-25)

**`POST http://127.0.0.1:8090/execute`** with `{"tool": "<CLEAN name>", "params": {...}}` —
synchronous, one HTTP request, ~10–40 ms:

| call | before | after |
|---|---|---|
| `unity_bridge_status` | 25 000 ms | **16 ms** |
| `unity_get_build_settings` | 25 000 ms (then breaker) | **12 ms** |
| `unity_run_csharp` `return 6*7;` | 50 KB warning wall + retry | **10 ms** → `{"result":42}` |
| `unity_inspect scene` | `exit null` | **39 ms** |

Two bugs this bypasses:

1. **Clean names only.** Commands going through `/execute` must be the registry's clean
   name (`get_build_settings`), **not** `unity_get_build_settings` → Unity answers
   `Unknown tool: unity_get_build_settings`. The MCP `execute` meta-tool strips the
   prefix; the share-mode `forwardToLeader()` path does **not** — so followers mis-name
   every command.
2. **`sendUnityCommand` retries 30 × 10 s** (up to 5 minutes) while the socket is down.
   That is where the long "calls and waits" went. The HTTP call now has our own timeout.

Still use the node/python path (`mcp_call.py`) for the **meta tools only**
(`list_categories`, `list_tools`, `search_tools`, `get_tools_reference`) — they never
touch Unity and work with the Editor closed.

### What the bridge now does for you

- **Tiered timeouts**: reads (`get_*`, `list_*`, `analyze_*`, `inspect`) 45 s · mutations
  75 s · build/import/refresh/capture/batch 180 s. No more 3-minute wait for a `get_*`.
- **Circuit breaker**: the first connection-class failure opens it for 60 s (30 s for
  busy); every Unity call in that window fails in ~0 s with `UNITY_DOWN (…s left) —
  refusing "<tool>" without sending it`. A successful call closes it.
- **`unity_bridge_status`** — one tool, two layers, ≤20 s each:
  `layer 1 node MCP server: OK/DOWN` → `layer 2 Unity Editor: OK/DOWN` + the fix line.
  Use it **instead of** probing with `unity_get_runtime_status` when Unity work just failed.
- Meta tools (`list_categories`, `list_tools`, `search_tools`, `get_tools_reference`) bypass
  the breaker — they work with Unity closed, which is how you can still discover tool names.

### Recovery ladder

1. If a modal is open → dismiss it (it also blocks the bridge).
2. In Unity: **Tools > Synaptic Pro > AI Reconnect** (or **Reset Internal State**);
   restarting the Editor always works.
3. `unity_bridge_status` once. If layer 1 is DOWN too, the node server is the problem —
   check `%LOCALAPPDATA%\Synaptic\MCPServer\logs\`.
4. Only then resume the task, re-reading state (a request queued before the drop may have
   executed late).

## 10. Ponytail disclosure line

Close any Unity-touching task with: which editor state was mutated, whether the
scene was saved, and which verification was skipped.
