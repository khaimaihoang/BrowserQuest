# Synaptic AI Pro - Tools Reference
Total: 356 tools in 32 categories

## AI (3 tools)

### unity_create_ai_pathfinding
Create an AI pathfinding system with A* algorithm
**Parameters:**
- `systemName`: string - Name of the generated pathfinding manager GameObject
- `algorithm`: string - Pathfinding algorithm used by the generated system
- `gridWidth`: number - Width of the pathfinding grid in cells
- `gridHeight`: number - Height of the pathfinding grid in cells
- `use3D`: boolean - Use a 3D voxel grid instead of a 2D grid

### unity_create_neural_network
Create a neural network system for AI decision making
**Parameters:**
- `networkName`: string - Name of the generated neural network script and asset
- `networkType`: string - Neural network architecture style to generate
- `inputSize`: number - Number of neurons in the input layer
- `hiddenSize`: number - Number of neurons in each hidden layer
- `outputSize`: number - Number of neurons in the output layer

### unity_setup_ml_agent
Setup a Machine Learning Agent for reinforcement learning
**Parameters:**
- `agentName`: string - Name of the generated ML-Agents agent GameObject
- `agentType`: string - Complexity preset for the agent behavior script
- `vectorObservationSize`: number - Length of the vector observation array fed to the policy
- `useVisualObservation`: boolean - Attach a camera sensor for visual observations

## Animation (14 tools)

### unity_add_animation_state
Add a new state to an Animator Controller
**Parameters:**
- `controllerPath`: string (required) - Path to the Animator Controller asset
- `stateName`: string - Name of the animation state to add
- `animationClipPath`: string - Path to animation clip
- `layerIndex`: number - Index of the Animator layer to add the state into
- `isDefault`: boolean - If true, set this state as the layer default entry state

### unity_add_animation_transition
Create a transition between animation states
**Parameters:**
- `controllerPath`: string (required) - Path to the Animator Controller
- `fromState`: string (required) - Source state name (use "Any" for Any State)
- `toState`: string (required) - Destination state name
- `condition`: string - Parameter name for condition
- `conditionValue`: string - Value for condition
- `hasExitTime`: boolean - If true, the transition waits for the source state exit time before triggering
- `transitionDuration`: number - Blend duration of the transition in seconds
- `layerIndex`: number - Index of the Animator layer containing the source state

### unity_analyze_animation_performance
Analyze and optimize animation performance
**Parameters:**
- `targetObject`: string - Specific object or all animated objects
- `includeBlendShapes`: boolean - Include SkinnedMeshRenderer blend shape costs in analysis

### unity_bake_animation
Bake runtime animation into an animation clip
**Parameters:**
- `sourceObject`: string (required) - GameObject with animation to bake
- `animationName`: string - Name of the baked animation clip asset to create
- `startFrame`: number - First frame of the recording range to bake
- `endFrame`: number - Last frame of the recording range to bake
- `frameRate`: number - Sampling frame rate of the baked clip in frames per second
- `path`: string - Asset folder path where the baked animation clip will be saved

### unity_create_animation
Create animation for GameObject
**Parameters:**
- `gameObject`: string (required) - Target GameObject name to attach the Animator/Animation to
- `animationName`: string (required) - Name for the new animation clip
- `duration`: number - Animation duration in seconds (default 1)
- `loop`: boolean - Whether the animation loops (default false)

### unity_create_animation_clip
Create a new animation clip with sample curves
**Parameters:**
- `name`: string - Name of the new animation clip asset
- `path`: string - Asset folder path where the animation clip will be saved
- `duration`: number - Duration of the animation clip in seconds
- `frameRate`: number - Sampling frame rate of the clip in frames per second
- `targetObject`: string - GameObject the sample curves target (used for binding paths)
- `animationType`: string - Type of sample curve generated for the clip

### unity_create_animation_event
Add an event to an animation clip
**Parameters:**
- `clipPath`: string (required) - Path to the animation clip
- `time`: number - Time in seconds
- `functionName`: string - Name of the MonoBehaviour method invoked when the event fires
- `stringParameter`: string - Optional string argument passed to the event handler
- `floatParameter`: number - Optional float argument passed to the event handler
- `intParameter`: number - Optional int argument passed to the event handler

### unity_create_animation_layer_mask
Create an avatar mask for animation layers
**Parameters:**
- `maskName`: string (required) - Name for the mask
- `bodyParts`: array (required) - Body parts to include
- `savePath`: string - Asset path where the AvatarMask asset will be saved

### unity_create_animator_controller
Create a new Animator Controller with default states and parameters
**Parameters:**
- `name`: string - Name of the new Animator Controller asset
- `path`: string - Asset folder path where the Animator Controller will be saved
- `targetObject`: string - GameObject to apply the controller to
- `applyToObject`: boolean - If true, assign the created controller to the targetObject Animator component

### unity_get_animation_details
Get detailed information about an animation clip
**Parameters:**
- `path`: string (required) - Path to animation asset

### unity_import_mixamo_animation
Import and setup animation from Mixamo
**Parameters:**
- `fbxPath`: string (required) - Path to Mixamo FBX file
- `targetRig`: string - Target character rig
- `loopAnimation`: boolean - Enable loop wrap mode on the imported AnimationClip

### unity_organize_animation_assets
Organize animation files into proper folder structure
**Parameters:**
- `sourcePath`: string (required) - Source folder path
- `targetPath`: string - Target folder path
- `groupBy`: string - Grouping strategy for organizing animation files into subfolders

### unity_retarget_animation
Retarget animation from one avatar to another
**Parameters:**
- `sourceClip`: string (required) - Source animation clip path
- `targetAvatar`: string (required) - Target avatar/rig path
- `outputPath`: string - Asset path to save the retargeted AnimationClip

### unity_setup_animation_layer
Add and configure an animation layer
**Parameters:**
- `controllerPath`: string (required) - Path to the Animator Controller
- `layerName`: string - Display name of the new Animator layer
- `weight`: number - Initial layer weight controlling how strongly it contributes to the final pose
- `blendMode`: string - Layer blending mode: override replaces, additive adds onto lower layers
- `avatarMaskPath`: string - Path to an Avatar Mask asset that restricts which bones the layer affects

## AssetManagement (12 tools)

### unity_analyze_dependencies
Analyze and visualize asset dependencies in the project
**Parameters:**
- `assetPath`: string - Specific asset to analyze (optional, analyzes all if not specified)
- `maxDepth`: number - Maximum depth of dependency tree
- `includePackages`: boolean - Include package dependencies

### unity_auto_organize_folders
Automatically organize assets into appropriate folders
**Parameters:**
- `rootFolder`: string - Root project folder to organize, typically Assets
- `createStandardFolders`: boolean - Create standard Unity subfolders such as Scripts, Prefabs, Materials
- `moveAssets`: boolean - Actually move existing assets into the proper folders
- `dryRun`: boolean - Preview the changes without modifying any assets on disk

### unity_check_folder
Check if folder exists
**Parameters:**
- `path`: string (required) - Project-relative folder path to check for existence (e.g., Assets/Prefabs)

### unity_cleanup_empty_objects
Remove empty GameObjects from scene
**Parameters:**
- `dryRun`: boolean - When true, only report empty GameObjects that would be removed without modifying the scene

### unity_create_folder
Create a new folder
**Parameters:**
- `path`: string (required) - Project-relative path of the new folder to create (e.g., Assets/MyNewFolder)

### unity_create_project_snapshot
Create a snapshot of the current project state
**Parameters:**
- `name`: string (required) - Unique name for the project snapshot capturing the current Unity project state
- `description`: string - Optional human-readable description explaining the purpose of this snapshot

### unity_delete_asset
Delete an asset from the project
**Parameters:**
- `assetPath`: string (required) - Path of asset to delete
- `moveToTrash`: boolean - Move to trash instead of permanent delete

### unity_export_project_structure
Export project folder structure
**Parameters:**
- `format`: string - Output format for the exported project folder structure: json data, ASCII tree, or csv table
- `includeFileSize`: boolean - Whether to include file size information for each asset in the exported structure

### unity_get_asset_dependencies
🔗 Get all dependencies of an asset (textures, materials, scripts, etc.). Shows complete dependency tree.
**Parameters:**
- `assetPath`: string (required) - Asset path (e.g., Assets/Prefabs/Player.prefab)
- `recursive`: boolean - Get recursive dependencies
- `includeBuiltIn`: boolean - Include built-in Unity assets
- `groupByType`: boolean - Group results by asset type

### unity_list_folders
List folders in a path
**Parameters:**
- `path`: string - Project-relative path to enumerate child folders under (defaults to project root Assets)

### unity_rename_asset
Rename an asset file
**Parameters:**
- `oldPath`: string (required) - Current asset path
- `newName`: string (required) - New name for the asset

### unity_validate_naming_conventions
Check if project assets follow naming conventions
**Parameters:**
- `checkPascalCase`: boolean - Check PascalCase for scripts
- `checkCamelCase`: boolean - Check camelCase for variables
- `checkUnderscores`: boolean - Check for underscores in names
- `customPatterns`: array - Custom regex patterns to check

## Audio (14 tools)

### unity_create_adaptive_music
Create intro+loop music system with dynamic transitions
**Parameters:**
- `name`: string (required) - Name of the adaptive music system GameObject to create
- `bpm`: number - Tempo of the music in beats per minute used for synced transitions
- `beatsPerBar`: number - Number of beats per musical bar for bar-aligned transitions

### unity_create_audio_clip
Import audio file or create procedural audio clip
**Parameters:**
- `name`: string (required) - Name of the audio clip asset to create or import
- `path`: string - Optional source file path to import the audio from
- `loadType`: string - How the audio clip is loaded into memory at runtime
- `compressionFormat`: string - Compression codec used for the imported audio data
- `quality`: number - Compression quality from 0 (lowest) to 1 (highest)
- `sampleRate`: number - Target sample rate in Hz for the audio clip
- `forceToMono`: boolean - Whether to mix all channels down to a single mono channel

### unity_create_audio_mixer
Create an audio mixer
**Parameters:**
- `name`: string (required) - Name for the new AudioMixer asset
- `groups`: array - Mixer group names to create (e.g., ["Master", "Music", "SFX"])

### unity_create_audio_mixing
Setup real-time audio mixing and ducking systems
**Parameters:**
- `mixerName`: string (required) - Name of the AudioMixer asset to create

### unity_create_audio_source
Create and configure an AudioSource component on a GameObject
**Parameters:**
- `gameObject`: string (required) - GameObject to attach the AudioSource to
- `audioClip`: string - Audio clip asset path
- `playOnAwake`: boolean - Play on scene start (default true)
- `loop`: boolean - Loop the audio clip (default false)
- `volume`: number - Volume level (0-1, default 1)
- `pitch`: number - Pitch multiplier (-3 to 3, default 1)
- `spatialMode`: string - 2D non-positional or 3D spatial (default 3D)
- `minDistance`: number - Distance below which audio is full volume (default 1)
- `maxDistance`: number - Distance beyond which audio is silent (default 500)

### unity_create_audio_visualization
Create visual effects that react to audio
**Parameters:**
- `visualizerName`: string (required) - Name of the audio visualizer GameObject to create
- `audioSource`: string (required) - AudioSource GameObject whose output drives the visualization
- `visualizationType`: string (required) - Audio analysis method used to drive the visuals
- `targetObjects`: array - GameObjects whose properties are animated by the audio
- `frequencyBands`: number - Number of frequency bands sampled from the spectrum
- `sensitivity`: number - Multiplier applied to the analyzed audio amplitude
- `responseProperty`: string - Transform or material property animated in response to audio
- `smoothing`: number - Temporal smoothing factor between 0 (none) and 1 (max)

### unity_create_reverb_zones
Create audio reverb zones for environmental effects
**Parameters:**
- `name`: string (required) - Name of the AudioReverbZone GameObject to create
- `position`: object (required) - World-space position of the reverb zone center
- `minDistance`: number - Inner radius in world units where full reverb is applied
- `maxDistance`: number - Outer radius in world units where reverb fades to zero
- `reverbPreset`: string - Unity AudioReverbPreset defining environmental reverb characteristics

### unity_create_sound_pools
Create sound variation pools for dynamic audio
**Parameters:**
- `poolName`: string (required) - Identifier for the sound pool asset
- `audioClips`: array (required) - List of AudioClip asset names or paths to include in the pool
- `playbackMode`: string - Selection strategy used when picking the next clip to play
- `weights`: array - Per-clip probability weights when playbackMode is Weighted
- `pitchVariation`: number - Random pitch variation amount applied per playback
- `volumeVariation`: number - Random volume variation amount applied per playback
- `cooldownTime`: number - Minimum seconds between successive plays from this pool

### unity_get_audio_details
Get detailed information about an audio clip
**Parameters:**
- `path`: string (required) - Path to audio asset

### unity_setup_3d_audio
Configure 3D spatial audio settings for an AudioSource
**Parameters:**
- `audioSource`: string (required) - GameObject with the AudioSource to configure
- `dopplerLevel`: number - Doppler effect strength (0-5)
- `spread`: number - Stereo spread in degrees (0-360)
- `volumeRolloff`: string - Distance attenuation curve
- `minDistance`: number - Full volume distance
- `maxDistance`: number - Silence distance
- `customCurve`: boolean - Use custom rolloff curve

### unity_setup_audio_effects
Add and configure audio effects (filters, reverb, echo, etc.)
**Parameters:**
- `audioSource`: string (required) - Name or path of the target AudioSource GameObject to attach effects to

### unity_setup_audio_occlusion
Configure audio occlusion for realistic sound blocking
**Parameters:**
- `audioSource`: string (required) - Name of the AudioSource GameObject to apply occlusion to
- `enableOcclusion`: boolean - Whether occlusion calculations are active at runtime
- `occlusionLayers`: array - Physics layer names that block or attenuate sound
- `maxOcclusionDistance`: number - Maximum raycast distance in world units used to detect occluders
- `occlusionDamping`: number - Volume attenuation factor applied per occluder from 0 to 1

### unity_setup_audio_triggers
Configure event-based audio triggers
**Parameters:**
- `triggerName`: string (required) - Identifier for this audio trigger configuration
- `triggerType`: string (required) - Type of Unity event that fires this trigger
- `targetGameObject`: string (required) - GameObject in the scene that hosts the trigger collider or event

### unity_setup_spatial_audio
Configure advanced spatial audio for VR/AR
**Parameters:**
- `audioSource`: string (required) - Name of the AudioSource GameObject to spatialize
- `spatializerPlugin`: string - Spatializer plugin used to render 3D audio
- `enableBinaural`: boolean - Whether to enable binaural HRTF rendering for headphones
- `enableHeadTracking`: boolean - Whether to use head tracking data for VR/AR spatialization

## Batch (5 tools)

### unity_batch_material_apply
Apply a material to multiple objects at once.
**Parameters:**
- `materialPath`: string (required) - Path to the material asset (e.g., Assets/Materials/MyMaterial.mat)
- `targetObjects`: string - Comma-separated list of specific object names
- `searchPattern`: string - Find objects by name pattern (supports regex)
- `searchScope`: string - Where to search for objects
- `replaceAll`: boolean - Replace all materials on each renderer

### unity_batch_prefab_create
Find assets that are not referenced in the project
**Parameters:**
- `sourceObjects`: string - Comma-separated list of object names
- `searchPattern`: string - Find objects by name pattern (supports regex)
- `outputFolder`: string - Folder to save prefabs
- `namingPattern`: string - Prefab naming pattern. {name} = original name
- `createVariants`: boolean - Create prefab variants if source is already a prefab instance
- `deleteOriginal`: boolean - Delete original scene objects after prefab creation

### unity_batch_prefab_update
Add, remove, or modify components on multiple prefabs at once.
**Parameters:**
- `prefabFolder`: string (required) - Folder containing prefabs
- `componentType`: string (required) - Component type name (e.g., Rigidbody, BoxCollider, AudioSource)
- `operation`: string (required) - What to do with the component
- `properties`: string - Properties to set if operation is "modify"

### unity_batch_rename
Rename multiple assets at once using search/replace patterns or regex.
**Parameters:**
- `searchPattern`: string (required) - Text to search for in asset names
- `replacePattern`: string (required) - Text to replace with
- `scope`: string - Where to search: selected assets, specific folder, or entire project
- `folderPath`: string - Folder path (required if scope is "folder")
- `useRegex`: boolean - Treat searchPattern as regex
- `caseSensitive`: boolean - Whether the search pattern matching should be case sensitive when locating asset names
- `dryRun`: boolean - Preview changes without applying (recommended first)

### unity_extract_all_text
Extract all text content from the project for localization or AI training
**Parameters:**
- `includeScripts`: boolean - Extract text from scripts
- `includeUI`: boolean - Extract text from UI elements
- `includeComments`: boolean - Include code comments
- `format`: string - Output format: json, txt, csv

## Build (4 tools)

### unity_get_build_settings
Get Unity build settings

### unity_get_player_settings
Get Unity player settings

### unity_get_project_summary
Get overall project summary

### unity_get_quality_settings
Get Unity quality settings

## Camera (13 tools)

### unity_create_blend_list_camera
Create a Blend List Camera that manages a prioritized list of child virtual cameras
**Parameters:**
- `name`: string - Name of the Blend List camera
- `priority`: number - Camera priority
- `follow`: string - GameObject to follow
- `lookAt`: string - GameObject to look at
- `loop`: boolean - Loop through child cameras
- `showDebugText`: boolean - Show debug information

### unity_create_clear_shot_camera
Create a Clear Shot Camera for dynamic shot selection with obstacle avoidance
**Parameters:**
- `name`: string (required) - Name of the Clear Shot camera
- `follow`: string - GameObject to follow
- `lookAt`: string - GameObject to look at
- `priority`: number - Camera priority

### unity_create_freelook_camera
Create a Cinemachine FreeLook Camera for third-person orbiting. REQUIRED: "follow" parameter must specify an existing GameObject name in the scene. The target GameObject must exist before creating the camera. Example: unity_create_freelook_camera({name: "PlayerCamera", follow: "Player"}). Will fail if follow target does not exist.
**Parameters:**
- `name`: string (required) - Name of the FreeLook camera (required)
- `follow`: string (required) - GameObject name to follow and orbit around (REQUIRED - must exist in scene before calling this tool)
- `lookAt`: string - GameObject to look at (defaults to follow target)
- `topRigHeight`: number - Top rig height offset
- `topRigRadius`: number - Top rig radius
- `middleRigHeight`: number - Middle rig height offset
- `middleRigRadius`: number - Middle rig radius
- `bottomRigHeight`: number - Bottom rig height offset
- `bottomRigRadius`: number - Bottom rig radius
- `xAxisSpeed`: number - Horizontal rotation speed
- `yAxisSpeed`: number - Vertical rotation speed
- `priority`: number - Camera priority

### unity_create_mixing_camera
Create a Mixing Camera that blends multiple child cameras with weighted averaging
**Parameters:**
- `name`: string - Name of the Mixing camera
- `priority`: number - Camera priority
- `weight0`: number - Weight for child camera 0
- `weight1`: number - Weight for child camera 1
- `weight2`: number - Weight for child camera 2
- `weight3`: number - Weight for child camera 3
- `weight4`: number - Weight for child camera 4
- `weight5`: number - Weight for child camera 5
- `weight6`: number - Weight for child camera 6
- `weight7`: number - Weight for child camera 7

### unity_create_state_driven_camera
Create a State-Driven Camera that switches based on Animator state
**Parameters:**
- `name`: string (required) - Name of the State-Driven camera
- `animatedTarget`: string (required) - GameObject with Animator component
- `layerIndex`: number - Animator layer index
- `follow`: string - GameObject to follow
- `lookAt`: string - GameObject to look at
- `priority`: number - Camera priority

### unity_create_virtual_camera
Create a Cinemachine Virtual Camera with follow and look at targets

### unity_get_active_camera_info
Get information about the currently active Cinemachine virtual camera

### unity_get_camera_info
Get information about cameras in the scene
**Parameters:**
- `cameraName`: string - Specific camera name (omit for all)

### unity_set_camera_enabled
Enable or disable a Cinemachine virtual camera
**Parameters:**
- `camera`: string (required) - Name of the Cinemachine camera
- `enabled`: boolean (required) - Enable (true) or disable (false) the camera

### unity_set_camera_priority
Change the priority of a Cinemachine virtual camera
**Parameters:**
- `camera`: string (required) - Name of the Cinemachine camera
- `priority`: number (required) - New priority value (higher priority cameras take precedence)

### unity_setup_camera
Setup camera in the scene
**Parameters:**
- `name`: string - Camera GameObject name (default "Main Camera")
- `fieldOfView`: number - Vertical field of view in degrees (default 60)
- `cameraType`: string - Projection mode: Perspective for 3D depth, Orthographic for 2D/isometric (default Perspective)

### unity_update_camera_target
Update Follow and/or LookAt targets of a Cinemachine camera
**Parameters:**
- `camera`: string (required) - Name of the Cinemachine camera
- `follow`: string - New Follow target (empty string to clear)
- `lookAt`: string - New LookAt target (empty string to clear)

### unity_update_virtual_camera
Update settings of an existing Cinemachine Virtual Camera
**Parameters:**
- `camera`: string (required) - Virtual camera name
- `priority`: number - New priority
- `follow`: string - New follow target
- `lookAt`: string - New look at target
- `fov`: number - New field of view
- `nearClipPlane`: number - Near clip plane distance
- `farClipPlane`: number - Far clip plane distance
- `dutch`: number - Camera roll/tilt angle in degrees
- `orthographic`: boolean - Use orthographic projection
- `orthographicSize`: number - Orthographic camera size
- `bodyType`: string - Body component type
- `aimType`: string - Aim component type
- `noiseProfile`: string - Camera shake noise profile
- `noiseAmplitude`: number - Noise amplitude/intensity (0-2)
- `noiseFrequency`: number - Noise frequency (0-2)

## Cinemachine (9 tools)

### unity_add_confiner_extension
Add Confiner Extension to restrict camera movement within bounds
**Parameters:**
- `camera`: string (required) - Virtual camera name
- `boundingVolume`: string (required) - GameObject with Collider defining the bounds
- `confineMode`: string - 3D or 2D confine mode
- `damping`: number - Damping for confinement

### unity_add_impulse_listener
Add an Impulse Listener extension to a virtual camera to receive shake effects
**Parameters:**
- `camera`: string (required) - Name of the Virtual Camera to add listener to
- `gain`: number - Overall gain for impulse reaction
- `amplitudeGain`: number - Amplitude gain for reaction
- `frequencyGain`: number - Frequency gain for reaction

### unity_create_dolly_track
Create a Cinemachine Dolly Track with waypoints for camera path animation
**Parameters:**
- `name`: string (required) - Name of the dolly track
- `looped`: boolean - Whether the path loops
- `cameraName`: string - Virtual camera to attach to track

### unity_create_impulse_source
Create an Impulse Source for triggering camera shake effects
**Parameters:**
- `gameObject`: string (required) - Name of the GameObject to add Impulse Source to
- `amplitudeGain`: number - Impulse amplitude gain
- `frequencyGain`: number - Impulse frequency gain
- `impulseDuration`: number - Duration of the impulse in seconds
- `defaultVelocity`: string - Default velocity as "x,y,z"

### unity_create_target_group
Create a Target Group for managing multiple camera targets with automatic framing
**Parameters:**
- `name`: string - Name of the Target Group
- `positionMode`: string - Position calculation mode
- `rotationMode`: string - Rotation calculation mode
- `updateMethod`: string - Update method

### unity_setup_advanced_blend_tree
Create complex blend trees for animation
**Parameters:**
- `controllerPath`: string (required) - Path to animator controller
- `blendTreeName`: string (required) - Name for blend tree
- `blendType`: string - Blend tree dimension and interpolation algorithm used by the Animator

### unity_setup_blend_tree
Create a blend tree for smooth animation transitions
**Parameters:**
- `controllerPath`: string (required) - Path to the Animator Controller
- `stateName`: string - Name of the state that hosts the blend tree
- `blendType`: string - Blend tree dimension: 1D uses one parameter, 2D uses two
- `parameterName`: string - Animator parameter that drives blending between motions
- `layerIndex`: number - Index of the Animator layer containing the blend tree state

### unity_setup_cinemachine_brain
Setup Cinemachine Brain on a camera (required for Cinemachine to work)
**Parameters:**
- `camera`: string - Camera to add Brain to
- `blendStyle`: string - Default blend style
- `defaultBlendTime`: number - Default blend time in seconds
- `updateMethod`: string - Brain update method

### unity_update_brain_blend_settings
Update the default blend settings on the Cinemachine Brain
**Parameters:**
- `defaultBlendTime`: number - Default blend duration in seconds
- `defaultBlendStyle`: string - Default blend curve style
- `customBlendsAsset`: string - Path to custom blends asset

## Debug (6 tools)

### unity_control_game_speed
Control Unity game speed (time scale) for debugging
**Parameters:**
- `operation`: string - Time scale operation to perform
- `speed`: number - Time scale multiplier when operation is set, e.g. 0.5 for half speed
- `preset`: string - Named speed preset applied to Time.timeScale
- `pauseMode`: string - How to apply the pause when operation is pause

### unity_debug_bt
Get debug information about a behavior tree
**Parameters:**
- `agentName`: string (required) - Name of the BT agent

### unity_debug_draw
Draw debug shapes in Unity scene
**Parameters:**
- `type`: string - Debug shape type to draw, or clear to remove existing shapes
- `duration`: number - How long the debug shape stays visible in seconds
- `color`: string - Color used to draw the debug shape
- `start`: string - Start position for line (e.g., "0,0,0")
- `end`: string - End position for line (e.g., "1,1,1")
- `origin`: string - Origin position for ray
- `direction`: string - Direction vector for ray
- `length`: number - Length of ray
- `center`: string - Center position
- `size`: string - Box size (e.g., "1,1,1")
- `radius`: number - Sphere radius
- `points`: string - Semicolon-separated points (e.g., "0,0,0;1,1,0;2,1,0")

### unity_manage_breakpoints
Manage debugging breakpoints in Unity
**Parameters:**
- `operation`: string - Breakpoint behavior to register on hit
- `condition`: string - Condition for breakpoint (e.g., "frame > 100", "time > 5")
- `message`: string - Message logged when the breakpoint triggers

### unity_profile_performance
Get Unity performance profiling data
**Parameters:**
- `category`: string - Profiler category to sample
- `duration`: number - Sampling duration in seconds, 0 means a single snapshot
- `detailed`: boolean - Include detailed per-marker breakdown in the result

### unity_run_tests
Run Unity Test Runner tests with auto-execution. Operations: run (start tests and wait for results), list (list available tests)
**Parameters:**
- `operation`: string - Operation: run (execute tests), list (list available tests)
- `mode`: string - Test mode: editmode or playmode
- `filter`: string - Optional test name filter

## Editor (7 tools)

### unity_analyze_console_logs
Detailed analysis of Unity console logs with file paths, line numbers and stack traces. CRITICAL: Always use this BEFORE unity_force_refresh_assets when you edit .cs files - check for syntax/compile errors with logType:"error". This prevents compilation failures and ensures clean workflows. Returns detailed error info including file paths and line numbers for easy fixing.
**Parameters:**
- `logType`: string - Filter Unity console logs by severity level
- `limit`: number - Maximum number of log entries to analyze and return
- `includeStackTrace`: boolean - Include full stack trace information in the analysis output
- `operation`: string - Operation mode for console log analysis

### unity_console
Unity console log count and basic info retrieval
**Parameters:**
- `operation`: string - Console operation to perform: read logs or clear them
- `logType`: string - Filter logs by type or return all
- `limit`: number - Maximum number of log entries to return

### unity_force_refresh_assets
Force Unity to refresh the asset database and recompile scripts. IMPORTANT: Before using this tool after editing .cs files, always run unity_analyze_console_logs with logType:"error" to check for syntax/compile errors. If errors exist, fix them first. Only refresh when error-free. Essential after modifying .cs files to ensure changes are recognized before invoking methods.
**Parameters:**
- `importMode`: string - Import mode: "default" (normal refresh), "force" (force reimport all), "forcesynchronous" (force reimport and wait for completion)

### unity_get_component_details
Get detailed information about a specific component on a GameObject, including all serialized properties
**Parameters:**
- `gameObjectName`: string (required) - Name of the GameObject
- `componentType`: string (required) - Type of the component (e.g., "Transform", "Rigidbody", "BoxCollider")
- `includeSerializedProperties`: boolean - Include all serialized properties

### unity_get_inspector_info
Get detailed inspector information for a specific GameObject, including all components, properties, and values
**Parameters:**
- `gameObjectName`: string (required) - Name of the GameObject to inspect
- `includePrivateFields`: boolean - Include private/protected fields in inspection
- `includeEvents`: boolean - Include UnityEvent information
- `componentFilter`: string - Filter by specific component type (e.g., "Transform", "Rigidbody")

### unity_get_selected_object_info
Get detailed inspector information for the currently selected GameObject in the Unity Editor
**Parameters:**
- `includePrivateFields`: boolean - Include private/protected fields in inspection
- `includeEvents`: boolean - Include UnityEvent information
- `componentFilter`: string - Filter by specific component type

### unity_invoke_context_menu
Invoke a method decorated with [ContextMenu] attribute on a component. Perfect for triggering custom editor actions like BuildLayout(), GenerateUI(), etc. WORKFLOW: 1) Edit code 2) unity_analyze_console_logs(error) 3) Fix errors if any 4) unity_force_refresh_assets 5) unity_analyze_console_logs(error) 6) Use this tool. This ensures error-free execution.
**Parameters:**
- `componentName`: string (required) - Name of the component class (e.g., "HomeScreenFlexLayout")
- `methodName`: string (required) - Name of the method to invoke (e.g., "BuildLayout")
- `gameObjectName`: string - Name of the GameObject containing the component (optional, will search scene if not provided)

## GameObject (11 tools)

### unity_add_component
Add a component to a GameObject
**Parameters:**
- `gameObject`: string (required) - GameObject name
- `component`: string (required) - Component type (e.g., Rigidbody, BoxCollider)

### unity_create_gameobject
Create a new GameObject in Unity scene. Note: Auto-retries on connection failure during Unity recompilation.
**Parameters:**
- `name`: string (required) - Name of the GameObject
- `type`: string - Type of primitive to create
- `parent`: string - Parent GameObject name

### unity_delete_gameobject
Delete a GameObject from the scene
**Parameters:**
- `name`: string (required) - Name of the GameObject to delete

### unity_duplicate_gameobject
Duplicate an existing GameObject
**Parameters:**
- `gameObject`: string (required) - Name or hierarchy path of the source GameObject in the active scene to duplicate
- `newName`: string - Optional name for the duplicated GameObject; defaults to source name with (Clone) suffix

### unity_find_gameobjects_by_component
Find all GameObjects with specific component
**Parameters:**
- `componentType`: string (required) - Unity component type name to search for (e.g., Rigidbody, AudioSource, MeshRenderer)
- `includeInactive`: boolean - Whether to include inactive GameObjects in the scene search results

### unity_get_gameobject_detail
Get detailed information for a specific GameObject (<10KB). Returns: transform, components with details, children, parent. Find GameObject by name or instanceId (use unity_get_gameobjects_list first to get IDs).
**Parameters:**
- `nameOrId`: string (required) - GameObject name or instanceId (from unity_get_gameobjects_list)

### unity_get_gameobject_details
Get detailed information about a specific GameObject
**Parameters:**
- `objectName`: string (required) - Name of the GameObject

### unity_get_gameobjects_list
Get filtered list of GameObjects (<50KB). Returns GameObject names, IDs, paths, layers, tags. Supports filters: layer, tag, name (contains), activeOnly. Max 100 results.
**Parameters:**
- `layerFilter`: string - Filter by layer name (e.g. "UI", "Default")
- `tagFilter`: string - Filter by tag (e.g. "Player", "Enemy")
- `nameFilter`: string - Filter by name (contains, case-sensitive)
- `activeOnly`: boolean - Only return active GameObjects
- `maxCount`: number - Maximum number of results (default: 100)

### unity_set_active_scene
⭐ Set the active scene in multi-scene editing. The active scene is where new GameObjects are created by default.
**Parameters:**
- `sceneName`: string (required) - Name of the scene to set as active

### unity_update_component
Update component properties. Use gameObject for target object name and component for component type.
**Parameters:**
- `gameObject`: string - GameObject name
- `gameObjectName`: string - GameObject name (alias)
- `component`: string - Component type
- `componentName`: string - Component type (alias)
- `properties`: string (required) - Properties to update (JSON object or string)

### unity_update_gameobject
Update properties of an existing GameObject
**Parameters:**
- `name`: string (required) - Name of the GameObject
- `newName`: string - New name to rename the GameObject to
- `active`: boolean - Whether the GameObject is active in the scene
- `tag`: string - Tag name to assign (e.g., "Player", "Enemy", "Untagged")
- `layer`: number - Layer index (0-31) to assign to the GameObject

## GameSystems (5 tools)

### unity_create_game_controller
Create player controller for different game types (FirstPerson, ThirdPerson, TopDown, Platformer2D)
**Parameters:**
- `type`: string - Player controller archetype to generate
- `playerName`: string - Name of the generated player GameObject
- `includeCamera`: boolean - Also create and attach a camera rig for the player
- `movementSpeed`: number - Player movement speed in Unity units per second
- `jumpHeight`: number - Player jump height in Unity world units

### unity_create_game_template
Create complete game templates for different genres
**Parameters:**
- `genre`: string - Game genre template to scaffold
- `name`: string - Name used for the generated game template scene and assets
- `includeUI`: boolean - Generate default UI Canvas with HUD elements
- `includeAudio`: boolean - Add AudioSources and basic music/SFX setup

### unity_create_state_machine
Create a state machine for character or game states
**Parameters:**
- `targetObject`: string - GameObject name to attach the state machine to
- `type`: string - State machine category, for example Character, Enemy, or Game
- `states`: string - Comma-separated state names

### unity_quick_prototype
Create a quick playable prototype with specified elements
**Parameters:**
- `elements`: string - Comma-separated prototype elements to include, e.g. player,enemies,collectibles
- `worldSize`: number - Size in Unity units of the generated square world
- `playerType`: string - Primitive shape used as the placeholder player mesh

### unity_setup_inventory_system
Create an inventory system with UI
**Parameters:**
- `size`: number - Number of inventory slots to create
- `hasUI`: boolean - Also generate a Canvas-based inventory UI
- `stackable`: boolean - Allow stacking of identical items in one slot

## GOAP (10 tools)

### unity_create_goap_action
Create an action for GOAP agents
**Parameters:**
- `agentName`: string (required) - Name of the GOAP agent
- `actionName`: string (required) - Name of the action
- `description`: string (required) - What this action does
- `preconditions`: array (required) - Conditions that must be true before action (e.g., ["has_weapon", "enemy_in_range"])
- `effects`: array (required) - Effects after action completion (e.g., ["enemy_defeated", "area_secure"])
- `cost`: number - Cost of performing this action

### unity_create_goap_agent
Define a goal for GOAP agents using natural language
**Parameters:**
- `name`: string (required) - Name of the GOAP agent
- `agentType`: string - Type: "Guard", "Worker", "Enemy", "NPC", "Merchant", "Monster", etc.
- `capabilities`: array - Capabilities: "movement", "combat", "ranged", "melee", "stealth", "healing", "building"

### unity_create_goap_template
Create a complete game-specific GOAP AI from pre-built professional templates.
**Parameters:**
- `templateType`: string (required) - Pre-built GOAP template type for common game AI archetypes
- `difficulty`: string - Difficulty preset that scales agent stats and reaction times
- `behaviors`: array - Additional natural language behaviors to include
- `customizations`: string - Template-specific customizations

### unity_debug_goap_decisions
Visualize and debug GOAP decision-making process
**Parameters:**
- `agentName`: string (required) - Name of the GOAP agent to debug
- `showGraph`: boolean - Show decision graph
- `showWorldState`: boolean - Show current world state
- `showPlan`: boolean - Show current action plan
- `logToConsole`: boolean - Log decisions to console

### unity_define_behavior_language
Define complete AI behavior using natural language description. Supports English and Japanese.
**Parameters:**
- `agentName`: string (required) - Name of the GOAP agent
- `behavior`: string (required) - Natural language behavior description. Examples: "Patrol and attack enemies on sight, retreat when health low" or "巡回して敵を攻撃、体力低下時は撤退"
- `gameContext`: string - Game context (FPS, RTS, RPG, Stealth, Survival, Horror) - adds context-specific actions
- `difficulty`: string - AI difficulty level affecting reaction speed, accuracy, and decision quality

### unity_define_goap_goal
Define a goal for GOAP agents using natural language
**Parameters:**
- `agentName`: string (required) - Name of the GOAP agent
- `goalName`: string (required) - Name of the goal
- `description`: string (required) - Natural language description of the goal (e.g., "Keep area safe from enemies")
- `priority`: number - Priority of the goal (0-100)
- `conditions`: string - Conditions for goal activation (e.g., "enemy detected within 10 units")

### unity_generate_goap_action_set
Automatically generate a complete action set based on agent type and goals
**Parameters:**
- `agentName`: string (required) - Name of the GOAP agent
- `agentRole`: string (required) - Role of the agent
- `environment`: string - Environment type (e.g., "forest", "urban", "dungeon")
- `includeDefaults`: boolean - Include default actions for the role

### unity_optimize_goap_performance
Optimize GOAP agent performance for better frame rates
**Parameters:**
- `agentName`: string - Specific agent to optimize (or all if not specified)
- `maxPlanDepth`: number - Maximum planning depth
- `planningFrequency`: number - How often to replan (seconds)
- `enableMultithreading`: boolean - Use multithreading for planning
- `cacheSize`: number - Plan cache size

### unity_setup_behavior_tree
Setup a behavior tree AI system for complex AI behaviors
**Parameters:**
- `treeName`: string - Name of the generated behavior tree asset and script
- `aiType`: string - AI archetype to seed the behavior tree with
- `includePatrol`: boolean - Include a patrol sequence in the generated tree
- `includeChase`: boolean - Include a chase branch when the player is detected
- `includeAttack`: boolean - Include an attack branch when target is in range

### unity_setup_goap_world_state
Configure the world state for GOAP planning
**Parameters:**
- `agentName`: string (required) - Name of the GOAP agent
- `worldState`: string (required) - World state key-value pairs (e.g., {"has_weapon": true, "enemies_nearby": 2})
- `sensors`: array - Sensors to add (e.g., ["enemy_detector", "health_monitor"])
- `updateFrequency`: number - How often to update world state (seconds)

## Input (13 tools)

### unity_create_drag_drop
Setup drag and drop functionality
**Parameters:**
- `draggableObject`: string (required) - Name of the GameObject that can be dragged
- `dropZones`: array - Names of GameObjects that accept the dragged object
- `snapToGrid`: boolean - Whether dropped objects snap to a grid
- `gridSize`: number - Grid cell size in world units when snapToGrid is true
- `showGhost`: boolean - Whether to show a ghost preview while dragging
- `returnOnInvalidDrop`: boolean - Whether the object returns to its origin on invalid drop
- `dragThreshold`: number - Pixel distance required before drag begins
- `allowRotation`: boolean - Whether the dragged object can be rotated

### unity_create_gesture_recognition
Setup gesture recognition for touch or motion input
**Parameters:**
- `gestureName`: string (required) - Identifier for the gesture recognizer
- `gestureType`: string (required) - Predefined gesture template to recognize
- `callbackEvent`: string - Name of the UnityEvent to invoke when the gesture is detected

### unity_create_input_recording
Setup input recording and playback system for testing or replay
**Parameters:**
- `recorderName`: string (required) - Identifier for the input recorder asset
- `recordingMode`: string (required) - Which input devices to capture
- `includeTimestamps`: boolean - Whether to record per-event timestamps
- `compression`: boolean - Whether to compress the recorded data
- `maxRecordingTime`: number - Maximum recording duration in seconds
- `autoSave`: boolean - Whether the recording is saved automatically when stopped

### unity_create_input_validation
Create input validation system for text fields and forms
**Parameters:**
- `validatorName`: string (required) - Identifier for the input validator component
- `validationType`: string (required) - Built-in validation rule applied to the field
- `customPattern`: string - Custom regex pattern used when validationType is Custom
- `minLength`: number - Minimum allowed input length in characters
- `maxLength`: number - Maximum allowed input length in characters
- `errorMessage`: string - Message shown to the user when validation fails
- `realTimeValidation`: boolean - Whether to validate as the user types

### unity_create_pinch_zoom
Setup pinch-to-zoom functionality
**Parameters:**
- `targetObject`: string (required) - Name of the GameObject, camera, or UI element to zoom
- `zoomType`: string - What is zoomed by the pinch gesture
- `minZoom`: number - Lower bound for the zoom factor
- `maxZoom`: number - Upper bound for the zoom factor
- `zoomSpeed`: number - Multiplier applied to pinch delta when changing zoom
- `smoothing`: boolean - Whether to interpolate zoom changes for smoother motion
- `centerOnPinch`: boolean - Whether to recenter the view on the pinch midpoint

### unity_get_input_settings
Get Unity input settings

### unity_setup_accessibility_input
Configure accessibility features for input (screen readers, large buttons, etc)
**Parameters:**
- `accessibilityName`: string (required) - Identifier for this accessibility configuration
- `features`: array (required) - List of accessibility features to enable
- `buttonScaling`: number - Scale multiplier applied to interactive UI elements
- `contrastLevel`: string - High-contrast color profile to apply to UI

### unity_setup_custom_input
Configure custom input actions and bindings
**Parameters:**
- `actionName`: string (required) - Name of the InputAction to register
- `bindingType`: string - Value type produced by the action
- `actionMap`: string - InputActionMap that owns this action
- `initialValue`: string - Optional initial value applied to the action on enable

### unity_setup_haptic_feedback
Configure haptic/vibration feedback for mobile and controllers
**Parameters:**
- `feedbackName`: string (required) - Identifier for this haptic feedback preset
- `platform`: string - Target platform that receives the haptic signal
- `feedbackType`: string (required) - Predefined haptic intensity profile
- `duration`: number - Duration of the haptic pulse in seconds
- `intensity`: number - Strength of the haptic pulse from 0 to 1
- `pattern`: array - Custom pattern of on/off pulses in milliseconds

### unity_setup_input_system
Setup Unity Input System with predefined templates
**Parameters:**
- `template`: string - Predefined input bindings template to apply
- `createAsset`: boolean - Create a saved InputActionAsset in the project

### unity_setup_multitouch
Configure multitouch input handling
**Parameters:**
- `maxTouches`: number - Maximum number of simultaneous touches to track
- `touchSensitivity`: number - Multiplier applied to raw touch delta values
- `enableGestures`: boolean - Whether built-in gesture recognition is enabled
- `touchVisualization`: boolean - Whether to draw on-screen touch indicators
- `preventAccidentalTouches`: boolean - Whether to filter out small or stray touches
- `touchAreaPadding`: number - Extra pixel padding added around interactive areas

### unity_setup_swipe_detection
Configure swipe gesture detection
**Parameters:**
- `swipeDirections`: array - Allowed swipe directions to detect
- `minSwipeDistance`: number - Minimum pixel distance required to register a swipe
- `maxSwipeTime`: number - Maximum seconds allowed between touch start and end
- `detectDiagonals`: boolean - Whether diagonal swipes are detected
- `continuousDetection`: boolean - Whether swipes can fire repeatedly during a drag

### unity_setup_touch_effects
Configure visual effects for touch interactions
**Parameters:**
- `effectType`: string - Visual style of the touch effect
- `effectPrefab`: string - Optional prefab used when effectType is Custom
- `color`: string - Hex color string applied to the effect
- `size`: number - Scale multiplier applied to the effect
- `duration`: number - Effect lifetime in seconds
- `fadeOut`: boolean - Whether the effect fades out before disappearing
- `followFinger`: boolean - Whether the effect follows the finger while touching

## Lighting (10 tools)

### unity_create_light_probe_group
Create light probe groups for dynamic GI
**Parameters:**
- `groupName`: string - Name of the LightProbeGroup GameObject to create
- `gridSize`: object - Number of probes along each axis forming the probe lattice
- `spacing`: number - Distance in Unity units between adjacent probes on each axis
- `center`: object - World-space center position of the probe grid

### unity_create_lightning_effect
Create lightning strikes with flash effects
**Parameters:**
- `frequency`: number - Lightning strike frequency in strikes per second
- `intensity`: number - Brightness multiplier of the lightning flash light
- `duration`: number - Duration of each lightning flash in seconds
- `color`: string - Hex color of the lightning flash (e.g., "#E0E0FF")
- `minDelay`: number - Minimum delay between strikes in seconds
- `maxDelay`: number - Maximum delay between strikes in seconds
- `affectSkybox`: boolean - Whether the lightning flash also brightens the skybox

### unity_create_skybox_blend
Blend between day and night skyboxes
**Parameters:**
- `daySkybox`: string - Name of the daytime skybox material to use
- `nightSkybox`: string - Name of the nighttime skybox material to use
- `blendCurve`: string - Curve type for blending between day and night skyboxes
- `cloudSpeed`: number - Movement speed of clouds across the skybox
- `cloudOpacity`: number - Opacity of clouds in the skybox (0-1)

### unity_create_skybox_from_image
Create a Skybox from image(s). Supports: (1) Panoramic/HDRI - single 360° equirectangular image, (2) 6-Sided - six face textures, (3) Sphere/Dome - regular landscape photo on inverted sphere (best for non-360 photos)
**Parameters:**
- `type`: string - Skybox type: panoramic/hdri for 360° image, 6sided/cubemap for 6 faces, sphere/dome/landscape for regular photos on inverted sphere
- `imagePath`: string - Path to image. e.g., "Assets/Textures/sky.jpg"
- `front`: string - Front face texture path (for 6sided type)
- `back`: string - Back face texture path (for 6sided type)
- `left`: string - Left face texture path (for 6sided type)
- `right`: string - Right face texture path (for 6sided type)
- `up`: string - Up/Top face texture path (for 6sided type)
- `down`: string - Down/Bottom face texture path (for 6sided type)
- `materialName`: string - Name for the created material
- `exposure`: number - Skybox brightness (0.1-8.0, for panoramic/6sided)
- `rotation`: number - Skybox rotation in degrees (0-360)
- `applyToScene`: boolean - Apply material to scene RenderSettings skybox (for sphere type)
- `radius`: number - Sphere radius (for sphere/dome type)
- `followCamera`: boolean - Make sphere follow camera position (for sphere/dome type)
- `objectName`: string - GameObject name (for sphere/dome type)
- `applyToCamera`: boolean - Apply material to MainCamera skybox (for sphere type)

### unity_get_lighting_info
Get information about lights in the scene

### unity_setup_lighting
Setup lighting in the scene with extended options and presets
**Parameters:**
- `preset`: string - Predefined lighting preset that configures ambient, fog, and directional light to match a scene mood
- `ambientMode`: string - Ambient light source mode
- `ambientIntensity`: number - Ambient light intensity (0-2)
- `ambientSkyColor`: string - Ambient sky color as hex
- `ambientEquatorColor`: string - Ambient equator color as hex
- `ambientGroundColor`: string - Ambient ground color as hex (trilight)
- `fogEnabled`: boolean - Enable scene fog rendering
- `fogMode`: string - Fog falloff mode
- `fogColor`: string - Fog color as hex
- `fogDensity`: number - Fog density for exponential modes (0-1)
- `fogStartDistance`: number - Linear fog start distance
- `fogEndDistance`: number - Linear fog end distance
- `directionalLightIntensity`: number - Sun/directional light intensity (0-8)
- `directionalLightColor`: string - Directional light color as hex
- `directionalLightShadows`: string - Shadow type: none, hard, or soft

### unity_setup_lighting_preset
Apply professional lighting presets to the scene
**Parameters:**
- `preset`: string - Lighting environment preset that configures directional light, skybox, and ambient color
- `intensity`: number - Multiplier applied to directional light intensity (1 = preset default)
- `ambientMode`: string - RenderSettings.ambientMode source: Skybox samples skybox, Gradient blends sky/equator/ground, Color uses flat color
- `fog`: boolean - Enable RenderSettings.fog for distance-based atmospheric falloff
- `shadows`: string - Shadow quality: None disables shadows, Hard for hard-edged, Soft for filtered PCF shadows

### unity_setup_lighting_scenarios
💡 Create lighting scenarios for different moods - From dawn to midnight!
**Parameters:**
- `scenario`: string - Time-of-day or studio lighting preset that drives directional light color, intensity, and ambient
- `ambientIntensity`: number - Ambient light intensity
- `shadowStrength`: number - Shadow strength (0-1)
- `colorTemperature`: number - Light color temperature in Kelvin
- `foggy`: boolean - Add atmospheric fog

### unity_setup_reflection_probe
Setup reflection probes for realistic reflections
**Parameters:**
- `probeName`: string - Name of the ReflectionProbe GameObject to create in the scene
- `position`: object - World-space position of the probe origin in Unity units
- `size`: object - Bounding box size in Unity units of the volume the probe influences
- `resolution`: string - Cubemap face resolution in pixels; higher values produce sharper reflections at memory cost
- `updateMode`: string - ReflectionProbe refreshMode: OnAwake bakes on enable, EveryFrame realtime, ViaScripting manual
- `importance`: number - Probe importance used to resolve overlap order; higher values override lower ones

### unity_setup_volumetric_fog
Create atmospheric volumetric fog effects
**Parameters:**
- `fogName`: string - Name of the volumetric fog GameObject (LocalVolumetricFog in HDRP) to create
- `density`: number - Fog density per Unity unit; higher values produce thicker fog
- `color`: string - Fog tint as hex color (e.g., #FFFFFF for neutral white)
- `anisotropy`: number - Henyey-Greenstein scattering anisotropy in -1..1; positive forward-scatters light
- `lightPenetration`: number - How far light penetrates the fog volume in 0..1 range
- `noiseScale`: number - World-space scale of the 3D noise modulating fog density
- `noiseIntensity`: number - Strength of noise modulation applied to fog density (0..1)
- `windSpeed`: number - Animation speed of the noise field simulating wind drift
- `height`: number - Vertical extent in Unity units of the fog volume from the ground

## Material (9 tools)

### unity_create_advanced_material
Create materials with advanced settings and textures
**Parameters:**
- `materialName`: string (required) - Name of the Unity Material asset to create under Assets/Materials
- `shader`: string - Shader pipeline; Standard for Built-in, UniversalRP/Lit for URP, HDRP/Lit for HDRP

### unity_create_material
Create a new material
**Parameters:**
- `name`: string (required) - Name for the new material asset
- `shader`: string - Shader name (default "Standard")
- `metallic`: number - Metallic value (0 dielectric to 1 metal)
- `smoothness`: number - Surface smoothness (0 rough to 1 mirror)

### unity_create_material_property_block
Modify material properties without creating material instances
**Parameters:**
- `targetObject`: string (required) - Name of the GameObject whose Renderer receives the MaterialPropertyBlock
- `blockName`: string - Identifier used internally to track the MaterialPropertyBlock instance
- `preserveSharedMaterial`: boolean - When true keeps sharedMaterial intact and applies overrides per-renderer only
- `properties`: string - Dictionary mapping shader property names to override values (color, float, texture, vector)

### unity_get_material_details
Get detailed information about a material
**Parameters:**
- `path`: string (required) - Path to material asset

### unity_get_material_info
Get information about materials used in scene
**Parameters:**
- `objectName`: string - Specific object to check

### unity_get_material_properties
Get all properties and their current values from a material. Useful to see available parameters before modifying them.
**Parameters:**
- `materialPath`: string (required) - Path to the material asset (e.g., "Assets/Materials/Water.mat")

### unity_set_material_property
Modify properties of an existing material. Use this to change shader parameters like wave settings, colors, intensity values without recreating the material.
**Parameters:**
- `materialPath`: string (required) - Path to the material asset (e.g., "Assets/Materials/Water.mat")
- `propertyName`: string (required) - Shader property name (e.g., "_WaveHeight", "_ShallowColor", "_Smoothness")
- `propertyType`: string (required) - Type of the property
- `value`: string (required) - Value to set. Float: "1.5", Color: "#FF0000" or "1,0.5,0,1", Vector: "1,2,3,4", Texture: asset path

### unity_setup_material
Create or modify materials with PBR properties and shaders
**Parameters:**
- `targetObject`: string (required) - GameObject to apply the material to
- `materialName`: string - Name for the material asset
- `shader`: string - Shader preset
- `color`: string - Base color as hex
- `metallic`: number - Metallic value (0 to 1)
- `smoothness`: number - Smoothness (0 to 1)
- `emission`: boolean - Enable emissive glow
- `emissionColor`: string - Emission color as hex
- `transparency`: number - Alpha (0 to 1)
- `normalMap`: boolean - Enable normal map slot
- `texture`: string - Albedo texture asset path

### unity_vfx_set_color_gradient
Set color gradient for ColorOverLife or similar blocks
**Parameters:**
- `vfxPath`: string (required) - Path to VFX asset
- `contextIndex`: number (required) - Index of the context containing the block
- `blockIndex`: number (required) - Index of the ColorOverLife block
- `colors`: array (required) - Array of hex colors (e.g., ["#FF6600", "#FF0000", "#000000"])
- `times`: array - Array of time values (0-1), defaults to evenly distributed

## Monitoring (10 tools)

### unity_create_checkpoint
Create a checkpoint to restore later
**Parameters:**
- `name`: string (required) - Unique checkpoint name used later to restore the saved Unity scene state

### unity_get_events
Get recent Unity events
**Parameters:**
- `count`: number - Maximum number of most recent Unity events to retrieve

### unity_get_monitoring_status
Get current monitoring status

### unity_get_operation_history
Get history of Unity operations
**Parameters:**
- `count`: number - Maximum number of recent operation history entries to return

### unity_monitor_compile
Monitor script compilation events
**Parameters:**
- `enable`: boolean (required) - Enable or disable monitoring of Unity script compilation start and finish events

### unity_monitor_file_changes
Monitor file changes in the project
**Parameters:**
- `enable`: boolean (required) - Enable or disable file change monitoring for the Unity project asset folders
- `folders`: array - List of folder paths under Assets to watch; defaults to entire Assets folder

### unity_monitor_play_state
Monitor Unity play mode state changes
**Parameters:**
- `enable`: boolean (required) - Enable or disable monitoring of Unity Editor play mode state transitions

### unity_monitor_runtime_errors
🔴 Real-time runtime error monitoring and analysis tool. Detects and categorizes: NullReferenceException, IndexOutOfRange, MissingReference, and other runtime errors. Provides error patterns, stack trace analysis, affected files, potential issues detection (deep hierarchies, self-references), and specific solutions for each error type. Essential for debugging and error prevention.
**Parameters:**
- `timeWindow`: number - Time window in seconds to analyze errors (default: 60)
- `includeWarnings`: boolean - Include warnings in analysis (default: true)
- `analyzeStackTrace`: boolean - Analyze stack traces for patterns (default: true)

### unity_restore_checkpoint
Restore a previously created checkpoint
**Parameters:**
- `name`: string (required) - Name of a previously created checkpoint to roll the scene back to

### unity_subscribe_events
Subscribe to Unity events
**Parameters:**
- `events`: array (required) - List of Unity event names to subscribe to (e.g., playModeStateChanged, hierarchyChanged)

## Optimization (7 tools)

### unity_analyze_draw_calls
Analyze and report draw call optimization opportunities

### unity_auto_atlas_textures
Automatically create texture atlases from multiple textures
**Parameters:**
- `sourceFolder`: string (required) - Folder containing textures
- `atlasName`: string (required) - Name for the atlas
- `maxAtlasSize`: number - Maximum atlas texture size in pixels, e.g. 2048
- `padding`: number - Padding in pixels between sprites in the atlas
- `includeInBuild`: boolean - Include the generated atlas in the built player

### unity_check_best_practices
✅ Analyzes Unity scripts for compliance with Unity official guidelines, coding standards, security issues, and architectural patterns. Detects: Resources.Load usage, magic numbers, singleton patterns, API key hardcoding, PlayerPrefs security issues, high coupling, large classes, and provides compliance scoring with detailed recommendations.
**Parameters:**
- `scriptPath`: string - Full path to script (e.g., Assets/Scripts/MyScript.cs) - use this OR fileName
- `fileName`: string - Just the script name (e.g., MyScript.cs or MyScript) - use this OR scriptPath

### unity_estimate_build_size
Estimate build size for different platforms
**Parameters:**
- `platforms`: array - Target build platforms to estimate size for
- `includeStreamingAssets`: boolean - Include StreamingAssets folder contents in size estimation
- `compressionLevel`: string - Asset compression level used for the estimation

### unity_generate_lod
Automatically generate LOD groups for meshes
**Parameters:**
- `targetObject`: string (required) - GameObject or folder to process
- `lodLevels`: number - Number of LOD levels to generate, between 2 and 4
- `lodDistances`: array - Custom LOD distances
- `generateSimplifiedMeshes`: boolean - Auto-generate decimated meshes for each LOD level

### unity_optimize_textures_batch
Analyze and report draw call optimization opportunities
**Parameters:**
- `folder`: string - Folder path to search for textures
- `maxTextureSize`: number - Maximum texture size (256, 512, 1024, 2048, 4096)
- `compressionQuality`: string - Compression quality level

### unity_performance_report
Generate comprehensive performance analysis report
**Parameters:**
- `includeRendering`: boolean - Include rendering metrics such as draw calls and batches
- `includeTextures`: boolean - Include texture memory and import setting analysis
- `includeMeshes`: boolean - Include mesh vertex and triangle count analysis
- `includeScripts`: boolean - Include script CPU cost analysis in the report
- `includeAudio`: boolean - Include audio clip memory and compression analysis
- `targetPlatform`: string - Target platform used to apply performance budgets

## Other (47 tools)

### unity_add_bt_node
Add a node to a behavior tree.
**Parameters:**
- `agentName`: string (required) - Name of the BT agent
- `nodeType`: string (required) - Type of node to add
- `nodeName`: string - Name for the node
- `parentNode`: string - Parent node name (empty = root)
- `repeatCount`: number - For repeater: number of repeats (-1 = infinite)
- `cooldownTime`: number - For cooldown: cooldown duration in seconds
- `timeout`: number - For timeout: timeout duration in seconds
- `maxRetries`: number - For retry: max retry count
- `delay`: number - For delay: delay duration in seconds
- `duration`: number - For wait: wait duration in seconds
- `message`: string - For log: message to log

### unity_add_buoyancy
Add buoyancy physics to make an object float on the ocean
**Parameters:**
- `target`: string (required) - Target GameObject name
- `buoyancyForce`: number - Buoyancy force multiplier
- `waterDrag`: number - Water drag coefficient

### unity_add_dissolve_controller
Add dissolve effect controller to a GameObject for dramatic appear/disappear effects
**Parameters:**
- `target`: string (required) - Target GameObject name
- `duration`: number - Dissolve animation duration
- `edgeColor`: string - Edge glow color (hex)

### unity_add_grass_renderer
Add procedural grass renderer to a terrain or plane
**Parameters:**
- `target`: string (required) - Target GameObject (terrain or plane)
- `density`: number - Grass blade density
- `heightMax`: number - Maximum grass height
- `widthMax`: number - Maximum grass width

### unity_add_shield_controller
Add energy shield effect controller to a GameObject
**Parameters:**
- `target`: string (required) - Target GameObject name
- `shieldColor`: string - Shield color (hex)
- `hitDuration`: number - Hit impact effect duration

### unity_analyze_asset_usage
Find where an asset is used in the project
**Parameters:**
- `path`: string (required) - Path to asset
- `searchScenes`: boolean - Include scene files when scanning for asset references
- `searchPrefabs`: boolean - Include prefab assets when scanning for asset references

### unity_analyze_performance
⚡ Comprehensive performance analysis tool that detects expensive operations in Update loops, excessive GameObject.Find usage, inefficient coroutines, string performance issues, LINQ allocations, Draw Call problems, mesh/texture optimization opportunities, lighting issues, and UI performance bottlenecks. Provides detailed recommendations for optimization.
**Parameters:**
- `scriptPath`: string - Full path to script to analyze (e.g., Assets/Scripts/MyScript.cs) - use this OR fileName
- `fileName`: string - Just the script name (e.g., MyScript.cs or MyScript) - use this OR scriptPath
- `target`: string - GameObject name to analyze specifically (if not provided, analyzes entire scene)

### unity_check_messages
Check for pending messages from Unity

### unity_create_bt_agent
Create a BehaviorTreeRunner on a GameObject.
**Parameters:**
- `agentName`: string - Name for the new agent
- `targetObject`: string - Existing object to add BT to (if not creating new)
- `autoStart`: boolean - Auto-start the tree on play
- `tickInterval`: number - Tick interval in seconds (0 = every frame)

### unity_create_bt_from_description
Start running a behavior tree on an agent
**Parameters:**
- `agentName`: string (required) - Name of the agent to create BT for
- `description`: string (required) - Natural language description of the behavior
- `gameContext`: string - Game genre context to tune behavior tree generation (Generic, FPS, RPG, RTS, Stealth, Survival)

### unity_create_caustics
Create underwater caustics effect
**Parameters:**
- `targetObject`: string - GameObject name to receive the caustics projector or material
- `intensity`: number - Brightness multiplier of the caustics light pattern
- `scale`: number - Tiling scale of the caustics texture in world units
- `speed`: number - Animation playback speed of the caustics pattern

### unity_create_dissolve_material
Create dissolve effect material for appear/disappear transitions
**Parameters:**
- `name`: string (required) - Material name
- `baseColor`: string - Base color (hex)
- `edgeColor`: string - Dissolve edge glow color
- `edgeWidth`: number - Edge glow width
- `noiseScale`: number - Noise pattern scale
- `dissolveAmount`: number - Initial dissolve amount (0-1)

### unity_create_grass_material
Create stylized grass material with wind animation
**Parameters:**
- `name`: string (required) - Material name
- `topColor`: string - Grass tip color (hex)
- `bottomColor`: string - Grass base color (hex)
- `windStrength`: number - Wind sway strength
- `windSpeed`: number - Wind animation speed
- `subsurfaceColor`: string - Subsurface scattering color

### unity_create_hdrp_water
Create Unity HDRP Water System surface (Ocean, River, or Pool). Requires HDRP 2022.2+
**Parameters:**
- `name`: string - GameObject name
- `waterType`: string - Type of water surface
- `size`: number - Surface size in meters
- `windSpeed`: number - Wind speed affecting waves (0-100)
- `windDirection`: number - Wind direction in degrees (0-360)
- `waterColor`: string - Base water color (hex)
- `scatteringColor`: string - Subsurface scattering color (hex)
- `smoothness`: number - Surface smoothness (0-1)
- `foamAmount`: number - Foam amount (0-1)
- `causticsEnabled`: boolean - Enable caustics
- `causticsIntensity`: number - Caustics intensity (0-1)

### unity_create_ocean_system
Create a complete ocean system with infinite plane, 8-layer Gerstner waves, and WaterPro shader
**Parameters:**
- `name`: string - Ocean name
- `waterLevel`: number - Water surface Y position
- `gridSize`: number - Mesh grid resolution
- `tileSize`: number - Ocean tile size in units

### unity_create_shield_material
Create energy shield/force field material with fresnel and hit effects
**Parameters:**
- `name`: string (required) - Material name
- `shieldColor`: string - Shield color (hex)
- `fresnelPower`: number - Fresnel edge power
- `patternScale`: number - Hex pattern scale
- `pulseSpeed`: number - Pulse animation speed
- `transparency`: number - Base transparency (0-1)

### unity_create_sky_material
Create procedural sky material with day/night cycle support
**Parameters:**
- `name`: string (required) - Material name
- `topColor`: string - Sky top color (hex)
- `bottomColor`: string - Sky horizon color (hex)
- `sunColor`: string - Sun color (hex)
- `sunSize`: number - Sun disc size
- `cloudDensity`: number - Cloud density (0-1)
- `cloudSpeed`: number - Cloud movement speed
- `starDensity`: number - Star density for night (0-1)

### unity_create_transition_preset
Create reusable animation transition preset
**Parameters:**
- `presetName`: string (required) - Identifier for the saved transition preset
- `duration`: number - Transition duration in seconds or normalized time
- `exitTime`: number - Normalized time at which the source state can exit
- `hasFixedDuration`: boolean - If true, duration is in seconds rather than normalized time
- `interruptionSource`: string - Which state can interrupt this transition

### unity_create_water
Create water surface with waves and reflections
**Parameters:**
- `waterType`: string - Preset water body that determines waves, foam, and flow defaults
- `size`: number - Size of the water plane in world units
- `quality`: string - Shader and reflection quality tier for the water surface

### unity_dynamic_create
Create GameObjects, instantiate prefabs, load scenes, or add components. Universal creation tool.
**Parameters:**
- `type`: string (required) - What to create: gameobject (empty or primitive), prefab (instantiate from asset), scene (load scene), component (add to existing object)
- `name`: string - Name for new GameObject
- `primitive`: string - Primitive type (for gameobject)
- `asset`: string - Asset path for prefab (e.g., "Assets/Prefabs/Enemy.prefab")
- `scene`: string - Scene name or path to load
- `additive`: boolean - Load scene additively (for scene type)
- `gameObject`: string - Target GameObject (for component type)
- `component`: string - Component type to add (for component type)
- `parent`: string - Parent GameObject name
- `position`: object - World position
- `rotation`: object - Euler rotation
- `scale`: object - Local scale

### unity_dynamic_inspect
Dynamically inspect any Unity object, component, scene, or project assets. Use this to discover what properties are available before modifying them.
**Parameters:**
- `target`: string (required) - What to inspect: gameobject (properties/components), component (all serialized fields), scene (current scene info), project (project structure), prefabs (search prefabs), hierarchy (scene hierarchy)
- `name`: string - GameObject name (for gameobject/component targets)
- `component`: string - Component type to inspect (e.g., "Camera", "CinemachineVirtualCamera")
- `path`: string - Asset path filter for project/prefabs (e.g., "Assets/Prefabs/*")
- `depth`: number - Hierarchy depth for nested inspection (default: 2)

### unity_dynamic_modify
Dynamically modify any property of a Unity component using property paths. Use unity_dynamic_inspect first to discover available properties.
**Parameters:**
- `gameObject`: string (required) - GameObject name
- `component`: string (required) - Component type (e.g., "Transform", "Camera", "CinemachineVirtualCamera")
- `properties`: string (required) - Property paths and values as key-value pairs (e.g., {"m_Lens.FieldOfView": 60, "m_Priority": 10})
- `createIfMissing`: boolean - Add component if it does not exist

### unity_execute_batch
Execute multiple Unity commands in a single call to reduce token consumption and API round-trips.

### unity_execute_menu_item
Execute a Unity Editor menu item by its path. Use this to trigger any Unity menu action programmatically. Examples: "Edit/Preferences", "Window/Package Manager", "Assets/Refresh", "File/Save Project", "Tools/Synaptic Pro/AI Reconnect".
**Parameters:**
- `menuPath`: string (required) - The full menu path to execute (e.g., "Edit/Preferences", "Window/Package Manager", "Assets/Refresh")

### unity_fix_pink_materials
Scan project for pink/magenta materials (broken shaders) and automatically fix them for URP compatibility

### unity_generate_cloud_noise
Generate 3D noise texture for volumetric clouds, fog effects
**Parameters:**
- `name`: string (required) - Name of the generated texture
- `resolution`: number - Texture resolution
- `octaves`: number - Noise octaves (1-8)

### unity_generate_ramp_texture
Generate color ramp texture for toon shading, stylized rendering
**Parameters:**
- `name`: string (required) - Name of the generated texture
- `colors`: array - Array of hex colors for the ramp
- `steps`: number - Number of discrete color steps (2-16)

### unity_generate_sdf_texture
Generate Signed Distance Field texture for dissolve effects, shields, etc.
**Parameters:**
- `name`: string (required) - Name of the generated texture
- `resolution`: number - Texture resolution (64-2048)
- `pattern`: string - SDF pattern type

### unity_get_build_status
Get current build status and settings

### unity_get_error_status
Get current error and warning counts

### unity_get_memory_usage
Get current memory usage statistics

### unity_get_mesh_details
Get detailed information about a mesh asset
**Parameters:**
- `path`: string (required) - Path to mesh/model asset

### unity_get_performance_metrics
Get current performance metrics (FPS, frame time, etc.)

### unity_get_project_stats
Get overall project statistics

### unity_get_runtime_status
Get current runtime status (play mode, pause, etc.)

### unity_get_texture_details
Get detailed information about a texture asset
**Parameters:**
- `path`: string (required) - Path to texture asset

### unity_instantiate_prefab
Instantiate a prefab or FBX asset from the project into the scene. Supports any asset path including .prefab and .fbx files.
**Parameters:**
- `assetPath`: string (required) - Full asset path (e.g., "Assets/Prefabs/Player.prefab" or "Assets/Models/Chair.fbx")
- `name`: string - Name for the instantiated GameObject (defaults to asset name)
- `parent`: string - Parent GameObject name

### unity_run_csharp
Execute arbitrary C# code against the running Unity Editor (equivalent of Blender's run_python). UnityEngine / UnityEditor / System.Linq / Newtonsoft.Json are pre-imported. Use this as an escape hatch when no dedicated tool covers the operation. Examples: "AssetDatabase.SaveAssets(); return \"saved\";", "GameObject.Find(\"Cube\").transform.position = new Vector3(1,2,3);", "return Selection.activeGameObject?.name;". Does NOT trigger an AssemblyReload — the HTTP/WebSocket connection stays alive.
**Parameters:**
- `code`: string (required) - C# code to execute. Can be a single expression ("1+1") or statements ("var go = new GameObject(\"X\"); return go.name;"). Pre-imported namespaces: System, System.Linq, System.Collections.Generic, UnityEngine, UnityEditor.

### unity_send_chat_response
Send a response to the Unity chat interface
**Parameters:**
- `message`: string (required) - Message to send
- `type`: string - Severity style applied to the chat message in the Unity UI

### unity_set_hdrp_water_property
Modify properties of an existing HDRP Water surface
**Parameters:**
- `gameObjectName`: string (required) - Name of the Water GameObject
- `propertyName`: string (required) - Property name (e.g., "windSpeed", "waterColor", "foamAmount")
- `value`: string (required) - Value to set

### unity_set_property
Set a property value on any component
**Parameters:**
- `targetObject`: string (required) - Target GameObject name
- `componentType`: string (required) - Component type (e.g., Transform, Rigidbody)
- `propertyName`: string (required) - Property name to set
- `value`: string (required) - Value to set (will be parsed based on property type)

### unity_set_typography
Configure text styling and fonts
**Parameters:**
- `targetObject`: string (required) - Target UI Text or TextMeshPro GameObject name
- `fontAsset`: string - Path to font asset (TTF, OTF, or TMP_FontAsset)
- `fontSize`: number - Font size in points
- `fontStyle`: string - Font style applied to the text component
- `lineSpacing`: number - Line spacing multiplier between text lines
- `characterSpacing`: number - Spacing between individual characters in the text

### unity_setup_character_ik
Setup Inverse Kinematics for a character
**Parameters:**
- `targetObject`: string (required) - Character object name
- `ikType`: string - Inverse Kinematics setup type to configure on the Animator
- `weight`: number - IK influence weight from 0 (off) to 1 (full)

### unity_start_bt
Start running a behavior tree on an agent
**Parameters:**
- `agentName`: string (required) - Name of the BT agent

### unity_stop_bt
Stop a running behavior tree
**Parameters:**
- `agentName`: string (required) - Name of the BT agent

### unity_trigger_dissolve
Trigger dissolve animation on a GameObject with DissolveController
**Parameters:**
- `target`: string (required) - Target GameObject name
- `dissolveIn`: boolean - true = appear, false = disappear

### unity_trigger_shield_hit
Trigger hit impact effect on a GameObject with ShieldController
**Parameters:**
- `target`: string (required) - Target GameObject name
- `intensity`: number - Hit effect intensity

## Package (4 tools)

### unity_check_package
Check if a package is installed
**Parameters:**
- `packageName`: string (required) - Package name to check

### unity_export_package
Export assets as a .unitypackage file. Useful for distributing assets or creating backups.
**Parameters:**
- `assetPaths`: string (required) - Comma-separated asset paths to include (e.g., "Assets/MyFolder,Assets/Scripts")
- `outputPath`: string - Full output path including filename (optional, defaults to Desktop)
- `includeDependencies`: boolean - Include asset dependencies

### unity_install_package
Install a Unity package
**Parameters:**
- `packageId`: string (required) - Package identifier (e.g., com.unity.ai.navigation)

### unity_list_packages
List all installed Unity packages
**Parameters:**
- `filter`: string - Package list filter: all packages or only offline cached

## Physics (6 tools)

### unity_add_collider_extension
Add Collider Extension to Virtual Camera for obstacle avoidance
**Parameters:**
- `camera`: string (required) - Virtual camera name
- `minimumDistanceFromTarget`: number - Minimum distance from follow target
- `avoidObstacles`: boolean - Enable obstacle avoidance
- `distanceLimit`: number - Maximum raycast distance
- `smoothingTime`: number - Smoothing time for position changes
- `damping`: number - Damping for position changes

### unity_get_physics_info
Get information about physics objects in scene

### unity_get_physics_settings
Get Unity physics settings

### unity_setup_navmesh
Setup navigation mesh
**Parameters:**
- `agentRadius`: number - NavMesh agent radius in meters (default 0.5)
- `agentHeight`: number - NavMesh agent height in meters (default 2.0)
- `maxSlope`: number - Maximum walkable slope in degrees (default 45)
- `stepHeight`: number - Maximum step height the agent can climb (default 0.4)

### unity_setup_physics
Setup physics settings for a GameObject or global physics
**Parameters:**
- `target`: string - Target GameObject name (or "global" for global physics settings)
- `rigidbody`: boolean - Add Rigidbody component
- `mass`: number - Rigidbody mass
- `gravity`: string - Use gravity (bool), JSON string, or global gravity vector
- `collider`: string - Type of collider to add: box, sphere, capsule, mesh
- `defaultMaterial`: string - Default physics material path (e.g., "Assets/Materials/Ice.physicMaterial")

### unity_setup_ui_navigation
Create UI navigation system (tabs, buttons, toggles)
**Parameters:**
- `navigationName`: string - Name for the navigation root GameObject
- `navigationType`: string - Navigation control style to generate
- `itemCount`: number - Number of navigation items to create
- `orientation`: string - Layout direction for the navigation items
- `selectedIndex`: number - Index of the item initially selected

## Scene (10 tools)

### unity_add_scene_to_build
⚙️ Add or remove scenes from Build Settings. Manage build order and enable/disable scenes.
**Parameters:**
- `scenePath`: string (required) - Scene path (e.g., Assets/Scenes/Game.unity)
- `operation`: string - Operation type
- `buildIndex`: number - Build index (for add operation, -1 = append)

### unity_capture_scene_view
Capture a screenshot of the Unity Scene View. The image is saved to Assets/Screenshots and can be analyzed by Claude Vision. Returns the file path for immediate analysis.
**Parameters:**
- `filename`: string - Output filename (default: SceneView_timestamp.png)
- `path`: string - Output directory path

### unity_get_scene_changes_since
Get scene changes since a timestamp. Returns: added, removed, modified GameObjects. Use for efficient scene monitoring. On first call or if timestamp too old, returns full scene summary.
**Parameters:**
- `timestamp`: string (required) - ISO 8601 timestamp (e.g. "2025-01-15T12:00:00Z"). Use current time on first call, then use returned timestamp for next call.

### unity_get_scene_info
Get comprehensive information about the current Unity scene including hierarchy, statistics, lighting, and cameras. Now includes detailed Transform data (world/local position, rotation, scale) and RectTransform data (anchors, pivot, sizeDelta, rect) for all GameObjects. WARNING: Can return large response (>1MB) for complex scenes. For large scenes, use unity_get_scene_summary instead.

### unity_get_scene_summary
Get lightweight scene overview (<200KB). Returns: scene name, GameObject count, cameras, lights, root GameObjects list (max 50). Recommended for large scenes instead of unity_get_scene_info.

### unity_list_all_scenes
📋 List all scene files in the project. Returns scene paths, names, and build settings info. Supports filtering and sorting.
**Parameters:**
- `includeInactive`: boolean - Include scenes not in build settings
- `sortBy`: string - Sort order
- `searchPath`: string - Directory to search (e.g., Assets/Scenes)

### unity_load_scene
🎬 Load a scene in Editor mode. Supports Single (replace current) or Additive (load alongside current) modes. Can load by path or name.
**Parameters:**
- `scenePath`: string - Scene path (e.g., Assets/Scenes/Game.unity)
- `sceneName`: string - Scene name (e.g., Game) - will search in Assets
- `mode`: string - Load mode: Single (replace) or Additive (add)
- `setActive`: boolean - Set as active scene after loading (Additive mode only)

### unity_manage_scene
Scene management operations
**Parameters:**
- `operation`: string (required) - Scene operation: save current scene, load from path, or create new empty scene
- `path`: string - Scene file path (e.g., "Assets/Scenes/Main.unity"), required for save/load

### unity_pause_scene
Pause or unpause the scene view
**Parameters:**
- `pause`: boolean (required) - True to pause, false to unpause

### unity_unload_scene
🗑️ Unload a scene from the Editor. Useful for managing multi-scene setups. Cannot unload the last remaining scene.
**Parameters:**
- `sceneName`: string (required) - Name of the scene to unload
- `removeUnsavedChanges`: boolean - Remove without saving changes

## Screenshot (4 tools)

### unity_capture_game_view
Capture a screenshot of the Unity Game View including all Canvas/UI elements. WORKFLOW: 1) Call this tool → returns "status: pending" if Play mode transition needed. 2) DO NOT CALL ANY OTHER TOOLS. WAIT EXACTLY 3 SECONDS. This is REQUIRED for Play mode transition and rendering stabilization. 3) After 3 seconds, call unity_get_screenshot_result to retrieve the actual screenshot path and resolution. CRITICAL: The screenshot is NOT complete until you retrieve the result with unity_get_screenshot_re
**Parameters:**
- `filename`: string - Output filename (default: GameView_timestamp.png)
- `path`: string - Output directory path

### unity_capture_grid
Automatically split and capture the Game View into a grid of multiple screenshots. Useful for analyzing different areas of the UI systematically. WORKFLOW: 1) Call this tool with grid size (e.g., "2x2", "3x3"). 2) If returns "status: pending", WAIT EXACTLY 3 SECONDS for Play mode transition. 3) Call unity_get_screenshot_result to retrieve all grid files. Returns multiple image files (one for each grid cell) with their positions.
**Parameters:**
- `grid`: string (required) - Grid size in format "2x2", "3x3", "4x4", etc. (max 5x5). Each cell will be saved as a separate file.
- `basename`: string - Base name for output files (default: Grid_timestamp). Files will be named basename_r0_c0.png, basename_r0_c1.png, etc.
- `path`: string - Output directory path

### unity_capture_region
Capture a screenshot of a specific region within Unity Game View or Scene View. Useful for capturing specific UI elements or areas. WORKFLOW for view="game": 1) Call this tool → returns "status: pending" if Play mode transition needed. 2) DO NOT CALL ANY OTHER TOOLS. WAIT EXACTLY 3 SECONDS for Play mode transition and rendering stabilization. 3) After 3 seconds, call unity_get_screenshot_result to retrieve result. CRITICAL: The capture is NOT complete until you retrieve the result with unity_get
**Parameters:**
- `x`: number (required) - X coordinate of the region (top-left corner)
- `y`: number (required) - Y coordinate of the region (top-left corner)
- `width`: number (required) - Width of the region in pixels
- `height`: number (required) - Height of the region in pixels
- `view`: string - Which view to capture from: "game" (includes Canvas/UI, auto Play mode if needed) or "scene" (3D view only, works in Edit mode)
- `filename`: string - Output filename (default: Region_timestamp.png)
- `path`: string - Output directory path

### unity_get_screenshot_result
Retrieve the result of a screenshot capture operation that required Play mode transition. WORKFLOW: When unity_capture_game_view or unity_capture_region returns {"status": "pending"}, Unity is entering Play mode to capture Canvas/UI. Wait EXACTLY 3 SECONDS, then call THIS tool to retrieve the actual screenshot result including file path, width, and height. Returns {"status": "capturing"} if still in progress (you called too early - wait more), {"status": "no_result"} if no capture pending.

## Scripting (9 tools)

### unity_add_script_method
Add a new method to a Unity script.
**Parameters:**
- `scriptPath`: string - Full path (e.g., Assets/Scripts/MyScript.cs) - use this OR fileName
- `fileName`: string - Script name (e.g., MyScript.cs or just MyScript) - use this OR scriptPath
- `methodName`: string (required) - Name of the method to add
- `methodContent`: string (required) - Complete method implementation with proper indentation
- `insertAfter`: string - Insert after this method/pattern (optional, defaults to end of class)

### unity_analyze_script
🔍 Comprehensive script analysis tool that checks for syntax errors, code quality issues, Unity-specific problems, and provides improvement suggestions. Detects: bracket mismatches, long methods, unused variables, performance issues in Update(), null reference risks, naming conventions, and more. Use this to identify issues before modifying scripts.
**Parameters:**
- `scriptPath`: string - Full path to script (e.g., Assets/Scripts/MyScript.cs) - use this OR fileName
- `fileName`: string - Just the script name (e.g., MyScript.cs or MyScript) - use this OR scriptPath

### unity_edit_script_line
Edit a specific line in a Unity script.
**Parameters:**
- `scriptPath`: string - Full path (e.g., Assets/Scripts/MyScript.cs) - use this OR fileName
- `fileName`: string - Script name (e.g., MyScript.cs or just MyScript) - use this OR scriptPath
- `lineNumber`: number (required) - Line number to edit (1-based)
- `newContent`: string (required) - New content for the line

### unity_grep_scripts
🔍 Search for patterns across multiple script files using regex. Similar to grep command. Returns matching lines with file paths, line numbers, and context. Supports case-insensitive search and context lines.
**Parameters:**
- `pattern`: string (required) - Search pattern (supports regex)
- `filePattern`: string - File pattern (glob, e.g., Assets/Scripts/**/*.cs)
- `caseSensitive`: boolean - Case-sensitive search
- `contextLines`: number - Number of context lines to show (like grep -C)
- `showLineNumbers`: boolean - Show line numbers in results
- `maxResults`: number - Maximum number of results to return

### unity_list_script_files
📁 List script files in the project with glob pattern support. Can filter by directory, pattern, and sort by various criteria. Like using find or ls commands.
**Parameters:**
- `directory`: string - Directory to search in (e.g., Assets/Scripts)
- `pattern`: string - File pattern (glob, e.g., **/*Controller.cs)
- `recursive`: boolean - Search recursively in subdirectories
- `sortBy`: string - Sort files by
- `includeMetaFiles`: boolean - Include .meta files

### unity_modify_script
Edit existing Unity scripts.
**Parameters:**
- `scriptPath`: string - Full path to script (e.g., Assets/Scripts/MyScript.cs) - use this OR fileName
- `fileName`: string - Just the script name (e.g., MyScript.cs or MyScript) - use this OR scriptPath
- `operation`: string - Type of modification: replace=overwrite entire file content, insert=add at specific position, append=add to end, prepend=add to beginning
- `content`: string (required) - New content to add or replace. For replace operation, this will become the entire file content
- `searchText`: string - Text to search for when using replace or insert operations
- `lineNumber`: number - Line number for line-specific operations (1-based)

### unity_read_script
🔍 Search for patterns across multiple script files using regex. Similar to grep command. Returns matching lines with file paths, line numbers, and context. Supports case-insensitive search and context lines.
**Parameters:**
- `scriptPath`: string - Full path (e.g., Assets/Scripts/MyScript.cs) - use this OR fileName
- `fileName`: string - Script name (e.g., MyScript or MyScript.cs) - use this OR scriptPath

### unity_read_script_range
📄 Read a specific range of lines from a script file. Useful for large files where you only need to see a portion. Like using head/tail/sed commands.
**Parameters:**
- `scriptPath`: string - Full path (e.g., Assets/Scripts/MyScript.cs)
- `fileName`: string - Script name (e.g., MyScript.cs)
- `startLine`: number - Starting line number (1-based, optional)
- `endLine`: number - Ending line number (1-based, optional)
- `limit`: number - Maximum number of lines to read
- `offset`: number - Number of lines to skip from start

### unity_update_script_variable
Update variable declaration or value in a Unity script.
**Parameters:**
- `scriptPath`: string - Path to the script file
- `fileName`: string - Name of the script file to find
- `variableName`: string (required) - Name of the variable to update
- `newDeclaration`: string (required) - New variable declaration (e.g., "public float speed = 10f;")
- `updateType`: string - Update type: declaration or just value

## Shader (13 tools)

### unity_analyze_shader
Analyze a shader's structure without reading full content.
**Parameters:**
- `path`: string - Path to shader file
- `shader_name`: string - Shader name (e.g., "Standard")

### unity_animate_shader_texture
Create scrolling, flipbook, or rotating texture animations
**Parameters:**
- `targetObject`: string (required) - Name or path of the target GameObject whose material will be animated
- `propertyName`: string - Shader texture property to animate (defaults to main texture _MainTex)
- `animationType`: string - Animation mode: Scroll offsets UV, Flipbook plays sprite sheet, Rotate spins UVs
- `speed`: string - Scroll/rotation speed as comma-separated "x,y" UV units per second
- `scale`: string - Texture tiling scale as comma-separated "x,y"
- `columns`: number - Number of flipbook columns in the sprite sheet
- `rows`: number - Number of flipbook rows in the sprite sheet
- `fps`: number - Flipbook playback speed in frames per second

### unity_create_eye_material
Create realistic/stylized eye material with parallax iris and reflections
**Parameters:**
- `name`: string (required) - Material name
- `irisColor`: string - Iris color (hex)
- `pupilSize`: number - Pupil size (0-1)
- `irisDepth`: number - Iris parallax depth
- `scleraColor`: string - Sclera (white) color
- `reflectionStrength`: number - Cornea reflection strength
- `limbusWidth`: number - Limbus ring width
- `limbusColor`: string - Limbus ring color

### unity_create_hair_material
Create realistic/stylized hair material with Kajiya-Kay specular and anisotropy
**Parameters:**
- `name`: string (required) - Material name
- `hairColor`: string - Hair base color (hex)
- `specularColor1`: string - Primary specular color
- `specularColor2`: string - Secondary specular color
- `specularShift`: number - Specular shift along hair strand
- `anisotropy`: number - Anisotropy strength (0-1)
- `rimStrength`: number - Rim light strength
- `shadowColor`: string - Shadow color (hex)

### unity_create_shader_gradient
Apply gradient effects to materials
**Parameters:**
- `targetObject`: string (required) - Name or path of the GameObject to receive the gradient material
- `gradientType`: string - Gradient shape: Linear interpolates along an axis, Radial radiates from center
- `startColor`: string - Starting color of the gradient as hex (e.g. #FFFFFF)
- `endColor`: string - Ending color of the gradient as hex (e.g. #000000)
- `direction`: string - Linear gradient axis direction in UV space
- `blendMode`: string - How the gradient blends with the base material color

### unity_create_shader_graph
🎭 Create Shader Graph with natural language - Custom materials made easy!
**Parameters:**
- `shaderType`: string - Shader Graph master node preset that defines lighting model and base inputs
- `pipeline`: string - Render pipeline target that determines generated subgraph compatibility
- `features`: array - Additional shader features to wire into the graph (normal map, emission, etc.)
- `animated`: boolean - Include time-based animation

### unity_create_shader_property_animator
Animate shader properties like color, float, or vector values
**Parameters:**
- `targetObject`: string (required) - Name of the GameObject whose Renderer material property will be animated
- `propertyName`: string - Shader property name to animate (e.g., _Color, _EmissionColor, _MainTex_ST)
- `propertyType`: string - Shader property data type: Color for RGBA, Float for scalar, Vector for Vector4
- `startValue`: string (required) - Starting value as string (e.g., "1,0,0,1" for red color or "0" for float)
- `endValue`: string (required) - Ending value as string in the same format as startValue
- `duration`: number - Animation duration in seconds for one start-to-end cycle
- `loop`: boolean - When true the animation loops continuously between start and end values
- `curve`: string - Easing applied to the interpolation between start and end

### unity_create_toon_material
Create stylized toon/cel-shaded material with ramp shading and outlines
**Parameters:**
- `name`: string (required) - Material name
- `baseColor`: string - Base color (hex)
- `shadowColor`: string - Shadow color (hex)
- `shadowThreshold`: number - Shadow threshold (0-1)
- `shadowSoftness`: number - Shadow edge softness (0-1)
- `outlineColor`: string - Outline color (hex)
- `outlineWidth`: number - Outline width
- `specularSize`: number - Specular highlight size
- `rimColor`: string - Rim light color (hex)
- `rimPower`: number - Rim light power

### unity_create_water_material
Create Genshin Impact-quality water with physics-based wave reflection. Features: GGX BRDF specular, sun disk reflection on wave peaks, anisotropic highlights stretched along waves, micro-facet glitter, Beer-Lambert absorption, caustics with RGB split, and natural foam.

### unity_fix_urp_particle_shaders
Automatically fix particle materials that show pink/magenta in URP by converting to URP-compatible particle shaders

### unity_modify_shader
Modify an existing .shader file by replacing text.
**Parameters:**
- `path`: string (required) - Path to shader file
- `old_text`: string (required) - Exact text to find and replace (including whitespace)
- `new_text`: string (required) - New text to insert
- `replace_all`: boolean - Replace all occurrences

### unity_read_shader
Read the content of a .shader file. This must be called BEFORE modifying the shader.
**Parameters:**
- `path`: string (required) - Path to shader file (e.g., "Assets/Shaders/MyShader.shader")

### unity_read_shader_graph
Read and parse a Unity ShaderGraph (.shadergraph or .shadersubgraph) file.
**Parameters:**
- `path`: string (required) - Path to ShaderGraph file (e.g., "Assets/Shaders/MyGraph.shadergraph")

## Timeline (2 tools)

### unity_create_timeline
Create a Unity Timeline for cinematic sequences
**Parameters:**
- `name`: string - Name of the new Timeline asset
- `path`: string - Asset folder path where the Timeline asset will be saved
- `duration`: number - Total duration of the Timeline in seconds
- `frameRate`: number - Timeline frame rate in frames per second
- `targetObject`: string - GameObject that will receive the PlayableDirector bound to this Timeline

### unity_setup_avatar
Configure avatar for a 3D model
**Parameters:**
- `modelPath`: string (required) - Path to the 3D model
- `avatarName`: string - Name of the generated Avatar asset
- `isHumanoid`: boolean - If true, configure as a Humanoid avatar; otherwise Generic
- `rootBone`: string - Name of the root bone transform for Generic avatars

## TimeOfDay (4 tools)

### unity_create_day_night_preset
Apply preset lighting conditions for different environments
**Parameters:**
- `preset`: string - Environment preset that defines lighting and sky behavior
- `sunriseTime`: number - Sunrise time in hours (0-24)
- `sunsetTime`: number - Sunset time in hours (0-24)
- `sunriseColor`: string - Hex color of the directional light at sunrise
- `noonColor`: string - Hex color of the directional light at noon
- `sunsetColor`: string - Hex color of the directional light at sunset
- `nightColor`: string - Hex color of ambient lighting during night time

### unity_create_time_event
Create events triggered at specific times
**Parameters:**
- `eventName`: string (required) - Unique name identifier for the time event
- `triggerTime`: number (required) - Time to trigger event (0-24)
- `eventType`: string - Event trigger type: Once fires single time, Daily fires every day
- `action`: string (required) - Action to perform (activate, deactivate, toggle)
- `targetObject`: string - GameObject to affect

### unity_create_time_of_day
Create dynamic day-night cycle with sun and moon movement
**Parameters:**
- `startTime`: number - Initial time of day in hours (0-24)
- `dayDuration`: number - Duration of full day cycle in seconds
- `latitude`: number - Latitude in degrees for sun positioning
- `longitude`: number - Longitude in degrees for sun positioning
- `enableClouds`: boolean - Enable procedural cloud rendering in the sky
- `enableStars`: boolean - Enable star rendering during night time

### unity_set_time_of_day
Set specific time in the day-night cycle
**Parameters:**
- `time`: number (required) - Target time (0-24 hours)
- `instant`: boolean - If true, jump to target time instantly without transition
- `transitionDuration`: number - Duration in seconds for the smooth time transition

## Transform (4 tools)

### unity_move_asset
Move an asset to a different folder
**Parameters:**
- `sourcePath`: string (required) - Current asset path
- `destinationFolder`: string (required) - Destination folder path

### unity_remove_package
Remove an installed Unity package
**Parameters:**
- `packageName`: string (required) - Package name (e.g., com.unity.ai.navigation)

### unity_set_transform
Set position, rotation, and scale of a GameObject
**Parameters:**
- `gameObject`: string (required) - GameObject name

### unity_vfx_remove_block
Remove a block from a VFX context.
**Parameters:**
- `path`: string (required) - Path to VFX Graph file
- `contextIndex`: number (required) - Context index
- `blockIndex`: number (required) - Block index to remove

## UI (15 tools)

### unity_add_ui_effects
Add visual effects to UI elements
**Parameters:**
- `targetObject`: string (required) - Target UI GameObject to apply the effect to
- `effectType`: string - Visual effect component to add to the UI element
- `color`: string - Effect color in hex (e.g., #000000) or rgba string
- `intensity`: number - Effect strength multiplier controlling distance or alpha

### unity_apply_ui_theme
Apply a complete theme to UI elements
**Parameters:**
- `themeName`: string (required) - Theme name (e.g., Dark, Light, Custom)
- `targetCanvas`: string - Target canvas name
- `primaryColor`: string - Primary color hex
- `secondaryColor`: string - Secondary color hex
- `accentColor`: string - Accent color hex

### unity_capture_ui_element
Capture a specific UI element by its GameObject name. Automatically finds the element, calculates its screen bounds, and captures just that region. WORKFLOW: 1) Call this tool with the GameObject name (e.g., "MoveButton", "HealthBar"). 2) If returns "status: pending", WAIT EXACTLY 3 SECONDS for Play mode transition. 3) Call unity_get_screenshot_result to retrieve the captured element. Works with Canvas Overlay, Camera, and World Space render modes.
**Parameters:**
- `elementName`: string (required) - GameObject name of the UI element to capture (e.g., "MoveButton", "CharacterNameText")
- `filename`: string - Output filename (default: UIElement_{elementName}_timestamp.png)
- `path`: string - Output directory path

### unity_create_ui
Create UI elements in Unity
**Parameters:**
- `type`: string (required) - Type of UI element to create
- `name`: string (required) - Name for the new UI element
- `parent`: string - Parent GameObject name (typically a Canvas)

### unity_create_ui_dialog
Create modal dialogs (confirmation, alert, input)
**Parameters:**
- `dialogName`: string - Name for the dialog root GameObject
- `dialogType`: string - Dialog template to instantiate (confirmation, alert, or input)
- `title`: string - Title bar text displayed at the top of the dialog
- `message`: string - Body message shown inside the dialog
- `hasOverlay`: boolean - Add a dimmed full-screen overlay behind the dialog
- `isModal`: boolean - Block input to underlying UI while the dialog is open

### unity_create_ui_grid
Create UI grid layout with customizable elements
**Parameters:**
- `gridName`: string - Name of the GridLayoutGroup root GameObject
- `columns`: number - Number of grid columns
- `rows`: number - Number of grid rows
- `cellSize`: string - Cell size as "width,height"
- `spacing`: string - Spacing as "x,y"
- `padding`: string - Padding as "left,right,top,bottom"
- `fillType`: string - Type of UI element placed in each grid cell

### unity_create_ui_notification
Create notification system with different types and positions
**Parameters:**
- `notificationName`: string - Name of the notification manager GameObject
- `notificationType`: string - Visual style applied to the notification
- `position`: string - Anchor position of the notification on screen
- `animationType`: string - Show/hide animation for the notification
- `autoHide`: boolean - Automatically dismiss the notification after the delay
- `hideDelay`: number - Seconds before the notification auto-hides

### unity_get_ui_info
Get information about UI elements in scene
**Parameters:**
- `canvasName`: string - Specific Canvas GameObject name to inspect (omit for all canvases)

### unity_optimize_ui_canvas
Optimize Canvas for performance, quality, or mobile
**Parameters:**
- `canvasName`: string - Specific canvas name (leave empty for first found)
- `optimizationType`: string - Canvas optimization profile to apply
- `targetFrameRate`: number - Target frame rate (FPS) used to tune Canvas update settings
- `enablePixelPerfect`: boolean - Enable Canvas pixel perfect rendering for sharper UI

### unity_set_ui_anchor
Set UI element anchor presets or custom anchor values for RectTransform
**Parameters:**
- `target`: string (required) - Name of the UI element
- `preset`: string - Anchor preset to apply
- `anchorMin`: string - Custom anchor min (e.g., "0,0") - only for custom preset
- `anchorMax`: string - Custom anchor max (e.g., "1,1") - only for custom preset
- `pivot`: string - Pivot point (e.g., "0.5,0.5") - only for custom preset
- `anchoredPosition`: string - Anchored position (e.g., "0,0")
- `sizeDelta`: string - Size delta (e.g., "100,100")
- `keepPosition`: boolean - Keep current position when applying preset
- `keepSize`: boolean - Keep current size when applying preset
- `offset`: number - Offset for stretch-all/fill presets

### unity_set_ui_colors
Set colors for UI elements
**Parameters:**
- `targetObject`: string (required) - Target UI element
- `normalColor`: string - Default Selectable color in hex (e.g., #FFFFFF)
- `highlightedColor`: string - Hover/highlighted state color in hex
- `pressedColor`: string - Pressed state color in hex
- `selectedColor`: string - Selected state color in hex
- `disabledColor`: string - Disabled state color in hex

### unity_setup_ui_anchors
Automatically setup anchors and pivots for UI elements
**Parameters:**
- `targetObject`: string (required) - Target GameObject name
- `anchorPreset`: string - RectTransform anchor preset for UI alignment
- `pivotPreset`: string - Pivot point preset for the RectTransform
- `margin`: number - Margin in pixels from the anchored edges
- `recursive`: boolean - Apply anchor settings recursively to child UI elements

### unity_setup_ui_animation
Setup UI animations for elements (fade, scale, slide)
**Parameters:**
- `targetObject`: string (required) - Target GameObject name
- `animationType`: string - Type of tween animation to play on the UI element
- `duration`: number - Animation duration in seconds
- `delay`: number - Delay in seconds before the animation starts
- `easing`: string - Easing curve name applied to the animation (e.g., ease, linear)
- `autoPlay`: boolean - Play the animation automatically on enable

### unity_setup_ui_canvas
Configure UI Canvas with different render modes (overlay, camera, world) and settings
**Parameters:**
- `canvasName`: string - Name of the canvas
- `renderMode`: string - Canvas render mode
- `sortingOrder`: number - Sorting order for overlay mode
- `pixelPerfect`: boolean - Enable pixel perfect rendering
- `camera`: string - Camera name for camera mode (use "new" to create UI camera)
- `planeDistance`: number - Plane distance for camera mode
- `position`: string - Position for world space canvas (e.g., "0,0,5")
- `rotation`: string - Rotation for world space canvas (e.g., "0,180,0")
- `scale`: string - Scale for world space canvas (e.g., "0.01,0.01,0.01")
- `sizeDelta`: string - Canvas size for world space (e.g., "1920,1080")
- `scaleMode`: string - Canvas scaler mode
- `referenceResolution`: string - Reference resolution for scale-with-screen mode
- `match`: number - Width/Height match for scale-with-screen mode
- `scaleFactor`: number - Scale factor for constant-pixel mode
- `pixelsPerUnit`: number - Pixels per unit for constant-physical mode

### unity_style_ui_elements
Apply styling to UI elements
**Parameters:**
- `targetObject`: string (required) - Target UI GameObject name to style
- `borderRadius`: number - Corner radius in pixels for rounded UI borders
- `borderWidth`: number - Border outline width in pixels
- `borderColor`: string - Border color as hex code (e.g., #FFFFFF)
- `shadowOffset`: string - Shadow offset as "x,y" pixels from the element
- `shadowColor`: string - Drop shadow color as hex or rgba string

## Utility (26 tools)

### unity_add_target_to_group
Add a GameObject as a target to an existing Target Group
**Parameters:**
- `targetGroup`: string (required) - Name of the Target Group
- `target`: string (required) - Name of the GameObject to add as target
- `weight`: number - Target weight (influence on framing)
- `radius`: number - Target radius (bounding sphere)

### unity_auto_attach_ui
Automatically attach UI elements to component fields based on naming conventions
**Parameters:**
- `target`: string (required) - Name of the GameObject with the component (e.g., TetrisGameManager)
- `component`: string - Component name (optional, will find first custom component if not specified)

### unity_batch_import_settings
Apply import settings to all assets of a type in a folder.
**Parameters:**
- `assetType`: string (required) - Type of assets to modify
- `folder`: string (required) - Target folder path
- `includeSubfolders`: boolean - Include assets in subfolders

### unity_create_particle_preset
Create advanced particle effects with presets
**Parameters:**
- `effectName`: string (required) - Name of the particle effect GameObject to create in the Unity scene
- `preset`: string - Predefined Unity ParticleSystem preset configuring shape, emission, and color over lifetime
- `colors`: array - Array of hex color strings used for color over lifetime gradient
- `usePhysics`: boolean - When true adds a ParticleSystem collision module for world physics interaction

### unity_create_particle_system
Create a particle system with extended presets and customization options
**Parameters:**
- `name`: string (required) - Name for the new particle system GameObject
- `preset`: string - Predefined effect preset that auto-configures appearance and behavior
- `lifetime`: number - Particle lifetime in seconds (0.1-10)
- `startSpeed`: number - Initial particle speed (0-100)
- `startSize`: number - Initial particle size (0.01-10)
- `emission`: number - Particles emitted per second (1-1000)
- `gravity`: number - Gravity modifier (-10 to 10, 0 = no gravity)
- `shape`: string - Emitter shape that determines particle spawn pattern
- `usePhysics`: boolean - Enable particle collision with scene physics

### unity_create_prefab
Create a prefab from a GameObject in the scene.
**Parameters:**
- `gameObject`: string (required) - Name of the GameObject in scene to convert to prefab
- `path`: string (required) - Full save path including filename (e.g., "Assets/Prefabs/UI/MyButton.prefab"). ALWAYS specify a proper organized path.

### unity_create_responsive_ui
Create responsive UI container with layout groups
**Parameters:**
- `containerName`: string - Name of the responsive layout container GameObject
- `layoutType`: string - LayoutGroup orientation for arranging children
- `spacing`: number - Spacing in pixels between child elements
- `padding`: number - Inner padding in pixels around the layout
- `childAlignment`: string - Child alignment within the LayoutGroup
- `useContentSizeFitter`: boolean - Attach a ContentSizeFitter to auto-fit the container size

### unity_create_script
Scene management operations
**Parameters:**
- `name`: string (required) - Script name without .cs extension
- `path`: string - Folder path (e.g., "Assets/Scripts/Player/"). Defaults to "Assets/Synaptic_Generated/"
- `template`: string - Script template: MonoBehaviour for components, ScriptableObject for assets, Empty for plain C# (default MonoBehaviour)
- `content`: string - Full script content. If not provided, generates template based on template type

### unity_find_material_usage
🎨 Find all GameObjects, prefabs, and renderers using a specific material. Shows where materials are referenced in the project.
**Parameters:**
- `materialPath`: string (required) - Material path (e.g., Assets/Materials/Wood.mat)
- `materialName`: string - Material name (alternative to path)
- `searchInScenes`: boolean - Search in currently loaded scenes
- `searchInPrefabs`: boolean - Search in all prefabs

### unity_find_missing_references
⚠️ Find missing scripts, materials, textures, and other references in scenes and prefabs. Critical for project cleanup.
**Parameters:**
- `searchPath`: string - Directory to search in
- `types`: array - Types to check
- `searchInScenes`: boolean - Search in currently loaded scenes
- `searchInPrefabs`: boolean - Search in all prefabs
- `includeChildren`: boolean - Check child objects

### unity_find_texture_usage
🖼️ Find all materials and shaders using a specific texture. Useful for understanding texture dependencies.
**Parameters:**
- `texturePath`: string (required) - Texture path (e.g., Assets/Textures/Brick.png)
- `textureName`: string - Texture name (alternative to path)
- `includeShaderProperties`: boolean - Show which shader properties use this texture

### unity_find_unused_assets
Find assets that are not referenced in the project
**Parameters:**
- `assetTypes`: array - Asset types to scan for unused references
- `excludeFolders`: array - Folders to exclude from search
- `includePackages`: boolean - Whether to also scan assets inside the Packages folder

### unity_get_asset_file_info
Get file system information about an asset
**Parameters:**
- `path`: string (required) - Path to asset

### unity_get_asset_import_settings
Get import settings for an asset
**Parameters:**
- `path`: string (required) - Path to asset

### unity_group_gameobjects
Group multiple GameObjects under a parent
**Parameters:**
- `gameObjects`: array (required) - Names of GameObjects to group
- `parentName`: string (required) - Name for the parent group

### unity_list_assets
List assets in the project
**Parameters:**
- `path`: string - Project-relative folder path to list assets from (e.g., Assets/Prefabs)
- `type`: string - Optional Unity asset type filter such as Prefab, Material, Texture2D, or Script
- `recursive`: boolean - Recursively include assets in all subfolders under the given path

### unity_modify_particle_system
Animate shader properties like color, float, or vector values
**Parameters:**
- `target`: string - Name of GameObject with ParticleSystem
- `gameObject`: string - Alternative name parameter
- `module`: string - Module to modify (main, emission, shape, noise, etc.)
- `property`: string (required) - Property name to modify
- `value`: string (required) - New value for the property

### unity_place_objects
Place multiple objects with pattern
**Parameters:**
- `prefab`: string (required) - Prefab asset path or name to instantiate (e.g., Assets/Prefabs/Tree.prefab)
- `pattern`: string (required) - Placement pattern: grid layout, circle ring, straight line, or random scatter
- `count`: number (required) - Total number of prefab instances to place in the scene
- `spacing`: number - Distance in Unity world units between placed objects

### unity_read_particle_system
Read all properties of a Particle System component on a GameObject.
**Parameters:**
- `target`: string - Name of GameObject with ParticleSystem
- `gameObject`: string - Alternative name parameter

### unity_redo_operation
Redo previously undone operation

### unity_search
Search for objects in the scene
**Parameters:**
- `searchType`: string (required) - Type of search criterion to match GameObjects against
- `query`: string (required) - Search query string matched against the selected searchType
- `includeInactive`: boolean - Include inactive GameObjects in the search results

### unity_search_code
🔎 Search for code patterns across the entire Unity project. Can search in specific directories, filter by file types, and group results by file. More comprehensive than grep_scripts.
**Parameters:**
- `query`: string (required) - Search query (supports regex)
- `searchIn`: array - Directories to search in (e.g., ["Scripts", "Editor"])
- `fileTypes`: array - File extensions to search (e.g., [".cs", ".shader"])
- `includeMetaFiles`: boolean - Include .meta files in search
- `groupByFile`: boolean - Group results by file
- `caseSensitive`: boolean - Case-sensitive search
- `maxResults`: number - Maximum number of results

### unity_search_prefabs_by_component
🔍 Search for prefabs containing specific component(s). Useful for finding all prefabs with Rigidbody, Collider, custom scripts, etc.
**Parameters:**
- `componentName`: string (required) - Component name to search for (e.g., "Rigidbody", "AudioSource")
- `searchPath`: string - Directory to search in
- `recursive`: boolean - Search recursively
- `includeDisabled`: boolean - Include disabled components

### unity_setup_safe_area
Setup Safe Area for mobile devices with notch support
**Parameters:**
- `safeAreaName`: string - Name for the created Safe Area container GameObject
- `targetObject`: string - Target object (leave empty to create new)
- `applyToCanvas`: boolean - Apply Safe Area adjustments to the parent Canvas
- `includeNotch`: boolean - Account for device notch cutouts when computing the safe area

### unity_setup_scroll_view
Create complete scroll view with content and scrollbars
**Parameters:**
- `scrollViewName`: string - Name of the ScrollRect root GameObject
- `scrollDirection`: string - Axis the ScrollRect can scroll along
- `contentType`: string - Type of UI prefab used for each scroll item
- `itemCount`: number - Number of items to populate the content with
- `itemSize`: string - Item size as "width,height"
- `useScrollbar`: boolean - Add a Scrollbar component along the scroll axis
- `elasticity`: number - ScrollRect elasticity when scrolling past the bounds

### unity_undo_operation
Undo last Unity operation

## VFX (41 tools)

### unity_analyze_vfx_graph
Analyze a VFX Graph asset structure without reading full content.
**Parameters:**
- `path`: string (required) - Path to VFX Graph file

### unity_create_bloom
🌟 Create bloom effect with auto-generated shader - Adds beautiful glow to bright areas!
**Parameters:**
- `intensity`: number - Bloom intensity (0-10)
- `threshold`: number - Brightness threshold for bloom (0-1)
- `blurSize`: number - Blur size for bloom effect (0-10)

### unity_create_chromatic_aberration
Add lens distortion and color separation effect
**Parameters:**
- `intensity`: number - Chromatic aberration strength in 0..1 controlling RGB channel separation
- `camera`: string - Name of the Camera GameObject the post-process volume targets

### unity_create_decal
Create decal projections for details like dirt, damage, etc
**Parameters:**
- `decalName`: string (required) - Name of the DecalProjector GameObject to create in the scene
- `texture`: string - Asset path of the base color texture used by the decal
- `size`: object - Projection box size in Unity units (x,y are footprint, z is depth)
- `opacity`: number - Decal blend opacity from 0 (invisible) to 1 (fully opaque)
- `normalBlend`: number - Strength of normal map blending against underlying surfaces (0..1)
- `maskClipping`: boolean - When true clips the decal against surfaces facing away beyond a normal threshold

### unity_create_depth_of_field
📷 Create depth of field effect with auto-generated shader - Professional camera focus!
**Parameters:**
- `focusDistance`: number - Focus distance (0-100)
- `blurSize`: number - Blur size for out-of-focus areas (0-10)
- `aperture`: number - Camera aperture simulation (0.1-32)

### unity_create_film_grain
🎬 Create film grain effect with auto-generated shader - Adds cinematic film texture!
**Parameters:**
- `intensity`: number - Grain intensity (0-1)
- `grainSize`: number - Grain texture size (0.1-10)

### unity_create_lens_distortion
🔍 Create lens distortion effect with auto-generated shader - Realistic camera lens effects!
**Parameters:**
- `distortionStrength`: number - Distortion strength (-1 to 1, negative = pincushion, positive = barrel)
- `chromaticAberration`: number - Chromatic aberration amount (0-1)
- `vignette`: number - Vignette effect strength (0-1)

### unity_create_lens_flare
Create realistic lens flare effects
**Parameters:**
- `flareName`: string (required) - Name of the LensFlare GameObject to create in the scene
- `intensity`: number - Brightness multiplier for the lens flare elements
- `fadeSpeed`: number - Speed in seconds at which the flare fades when occluded by geometry
- `color`: string - Hex color tint applied to all flare elements (e.g., #FFFFFF)

### unity_create_motion_blur
💨 Create motion blur effect with auto-generated shader - Adds dynamic motion feel!
**Parameters:**
- `blurStrength`: number - Motion blur strength (0-1)
- `sampleCount`: number - Quality samples (4-32, higher = better quality)

### unity_create_screen_fade
Create fade in/out transitions
**Parameters:**
- `fadeType`: string - FadeIn reveals the scene from the color, FadeOut covers the scene to the color
- `duration`: number - Fade animation duration in seconds
- `color`: string - Hex color of the fullscreen overlay used for the fade (e.g., #000000)
- `delay`: number - Delay in seconds before the fade animation starts
- `curve`: string - Animation easing curve applied to the alpha interpolation

### unity_create_screen_shake
Apply screen shake effect for dramatic impact
**Parameters:**
- `duration`: number - Total shake duration in seconds before the camera returns to rest
- `intensity`: number - Peak displacement amplitude in Unity units applied to the camera
- `frequency`: number - Oscillation frequency in Hz controlling how rapidly the camera vibrates
- `damping`: number - Decay factor reducing intensity over duration; 1 = linear falloff to zero
- `camera`: string - Name of the Camera GameObject to apply the shake effect to

### unity_create_vfx_graph
Create VFX particle effects with advanced features. Supports mesh spawning, SDF shapes, splines, custom output modes. Uses VFX Graph (GPU) if available, otherwise Particle System.
**Parameters:**
- `effectType`: string - Type of VFX effect preset
- `name`: string - Custom name for the VFX GameObject
- `intensity`: number - Effect intensity multiplier
- `duration`: number - Effect duration in seconds
- `looping`: boolean - Whether effect loops continuously
- `particleCount`: number - Maximum particle count (GPU can handle millions!)
- `color`: string - Start/main color in hex (e.g., "#00FFFF")
- `endColor`: string - End color for gradient effects
- `position`: string - World position as "x,y,z"
- `shapeType`: string - Advanced spawn shape (requires VFX Graph package)
- `meshPath`: string - Asset path to mesh for mesh spawning (e.g., "Assets/Models/Sword.fbx")
- `meshName`: string - Name of GameObject in scene to use as mesh source
- `splinePoints`: string - Spline points as "x,y,z;x,y,z;..." for path-based effects
- `sdfShape`: string - SDF shape type
- `outputMode`: string - Output rendering mode
- `blendMode`: string - Blend mode for rendering

### unity_create_vignette_effect
Add cinematic vignette framing to scene
**Parameters:**
- `intensity`: number - Vignette darkening strength from 0 (off) to 1 (fully dark edges)
- `smoothness`: number - Edge smoothness of the vignette falloff in 0..1; higher is softer
- `color`: string - Hex color of the vignette overlay (typically #000000 for darkening)
- `rounded`: boolean - When true forces a circular vignette regardless of aspect ratio

### unity_create_visual_effect
Create complex visual effects combining particles, lights, and more
**Parameters:**
- `effectName`: string (required) - Name of the visual effect GameObject
- `effectType`: string - Visual effect type
- `target`: string - Name of the GameObject to attach the effect to (parents the effect under it)
- `duration`: number - Effect lifetime in seconds; 0 means infinite when loop is true
- `loop`: boolean - Loop the effect continuously while the GameObject is active
- `intensity`: number - Overall intensity multiplier applied to emission rate, light, and alpha

### unity_get_vfx_properties
Get all exposed properties of a VFX Graph. See available parameters for modification.
**Parameters:**
- `gameObjectName`: string (required) - Name of GameObject with VisualEffect component

### unity_modify_vfx_graph
Modify an existing VFX Graph asset by text replacement.
**Parameters:**
- `path`: string (required) - Path to VFX Graph file
- `old_text`: string (required) - Text to find and replace
- `new_text`: string (required) - Replacement text
- `replace_all`: boolean - Replace all occurrences

### unity_read_vfx_graph
Read and analyze an existing VFX Graph (.vfx) asset file.
**Parameters:**
- `path`: string (required) - Path to VFX Graph file (e.g., "Assets/VFX/MyEffect.vfx")

### unity_set_vfx_property
Modify exposed properties of a VFX Graph at runtime. Change colors, intensity, particle count, etc.
**Parameters:**
- `gameObjectName`: string (required) - Name of GameObject with VisualEffect component
- `propertyName`: string (required) - Exposed property name (e.g., "Intensity", "Color", "ParticleCount")
- `propertyType`: string (required) - Type of the property
- `value`: string (required) - Value to set. Float: "1.5", Color: "#FF00FF", Vector3: "1,2,3", Bool: "true"

### unity_setup_color_grading
Apply color grading for cinematic look
**Parameters:**
- `preset`: string - Color grading preset applied via PostProcess ColorAdjustments and Tonemapping
- `temperature`: number - White balance temperature offset in -100..100; positive warms, negative cools
- `tint`: number - White balance tint offset in -100..100; positive magenta, negative green
- `contrast`: number - Contrast adjustment in -100..100 applied to the final image
- `brightness`: number - Post-exposure brightness offset in stops (EV)
- `saturation`: number - Color saturation adjustment in -100..100; -100 desaturates fully

### unity_setup_hdrp_settings
🌟 Configure High Definition Render Pipeline settings - For photorealistic visuals!
**Parameters:**
- `platform`: string - Target platform preset that scales HDRP feature set
- `quality`: string - HDRP quality tier for shadows, reflections, and post effects
- `raytracing`: boolean - Enable ray tracing features
- `volumetrics`: boolean - Enable volumetric lighting
- `reflections`: string - Reflection technique: screen-space, ray-traced, or hybrid combination

### unity_setup_post_processing
🎨 Configure post-processing effects stack - Professional color grading and effects!
**Parameters:**
- `profile`: string - Visual style preset that selects the base Volume Profile
- `bloom`: boolean - Enable Bloom effect for glowing bright highlights
- `colorgrading`: boolean - Enable Color Adjustments / Tonemapping for color grading
- `vignette`: boolean - Enable Vignette darkening at screen edges
- `filmgrain`: boolean - Enable Film Grain texture overlay for cinematic feel
- `motionblur`: boolean - Enable Motion Blur for camera and object movement

### unity_setup_urp_settings
🖼️ Configure Universal Render Pipeline settings with natural language - Optimize for any platform!
**Parameters:**
- `platform`: string - Target platform preset that biases URP settings for performance vs. fidelity
- `quality`: string - Overall URP quality tier controlling render features and resolutions
- `shadows`: string - Shadow quality level and atlas resolution
- `antialiasing`: string - Post-process anti-aliasing technique applied to the camera
- `renderscale`: number - Render scale multiplier (0.5-2.0)
- `hdr`: boolean - Enable HDR rendering
- `msaa`: string - Hardware MSAA sample count for forward rendering

### unity_trigger_vfx_event
Send event to VFX Graph (play, stop, custom events)
**Parameters:**
- `gameObjectName`: string (required) - Name of GameObject with VisualEffect component
- `eventName`: string - Event name (OnPlay, OnStop, or custom event)

### unity_vfx_add_block
Add a block to a context. Blocks define particle behavior (position, velocity, color, forces, etc.)
**Parameters:**
- `vfxPath`: string (required) - Path to VFX asset
- `contextIndex`: number (required) - Index of context to add block to (0-based)
- `blockType`: string (required) - Type of block to add
- `attribute`: string - Attribute name for SetAttribute blocks (e.g., "position", "color", "size", "lifetime", "velocity")
- `value`: string - Value to set (e.g., "1,0,0" for vector, "#FF0000" for color)
- `min`: string - Minimum value for setattributerandom (e.g., 0.5 for float, "0,0,0" for vector)
- `max`: string - Maximum value for setattributerandom (e.g., 2.0 for float, "1,1,1" for vector)

### unity_vfx_add_context
Add a context (Spawn, Initialize, Update, Output) to VFX Graph. Contexts define the particle lifecycle.
**Parameters:**
- `vfxPath`: string (required) - Path to VFX asset (e.g., "Assets/VFX/Fire.vfx")
- `contextType`: string (required) - Type of context to add
- `capacity`: number - Particle capacity (for Initialize context)
- `spawnRate`: number - Spawn rate (for Spawn context)

### unity_vfx_add_operator
Add an operator node to VFX Graph. Operators perform calculations (math, noise, sampling, etc.)
**Parameters:**
- `vfxPath`: string (required) - Path to VFX asset
- `operatorType`: string (required) - Type of operator to add

### unity_vfx_add_parameter
Add an exposed parameter to VFX Graph that can be controlled from Inspector or scripts
**Parameters:**
- `vfxPath`: string (required) - Path to VFX asset
- `name`: string (required) - Parameter name
- `type`: string (required) - Parameter type
- `defaultValue`: string - Default value (e.g., "1.0", "1,2,3" for vector)
- `exposed`: boolean - Whether parameter is exposed in Inspector

### unity_vfx_compile
Compile and save the VFX Graph
**Parameters:**
- `vfxPath`: string (required) - Path to VFX asset

### unity_vfx_configure_output
Configure VFX output context settings (texture, blend mode, soft particles, etc.)
**Parameters:**
- `vfxPath`: string (required) - Path to VFX asset (e.g., "Assets/VFX/Fire.vfx")
- `contextIndex`: number (required) - Index of the output context
- `texture`: string - Path to texture asset
- `blendMode`: string - Blend mode
- `softParticle`: boolean - Enable soft particles
- `castShadow`: boolean - Cast shadows
- `sortPriority`: number - Sort priority

### unity_vfx_connect_slots
Connect output slot of one node to input slot of another (operator->block, parameter->operator, etc.)
**Parameters:**
- `vfxPath`: string (required) - Path to VFX asset
- `sourceNodeIndex`: number (required) - Index of source node
- `sourceSlotIndex`: number (required) - Index of output slot on source
- `targetNodeIndex`: number (required) - Index of target node (for blocks: contextIndex << 16 | blockIndex)
- `targetSlotIndex`: number (required) - Index of input slot on target
- `sourceType`: string - Type of source node
- `targetType`: string - Type of target node

### unity_vfx_create
Create a new VFX Graph asset. This is the first step for building custom VFX.
**Parameters:**
- `name`: string (required) - Name of the VFX Graph asset
- `folder`: string - Folder path to save the asset

### unity_vfx_create_preset
Create a complete VFX Graph from preset (fire, smoke, sparks, trail, explosion)
**Parameters:**
- `name`: string (required) - Name for the VFX asset
- `preset`: string (required) - Preset type
- `folder`: string - Folder to save the asset

### unity_vfx_get_available_types
List all available context, block, and operator types
**Parameters:**
- `category`: string - Category to list

### unity_vfx_get_block_info
Get detailed information about a specific VFX block including current values.
**Parameters:**
- `path`: string (required) - Path to VFX Graph file
- `contextIndex`: number (required) - Context index
- `blockIndex`: number (required) - Block index

### unity_vfx_get_structure
Get the structure of a VFX Graph (contexts, blocks, operators)
**Parameters:**
- `vfxPath`: string (required) - Path to VFX asset

### unity_vfx_link_contexts
Link two contexts together (e.g., Spawn -> Initialize -> Update -> Output)
**Parameters:**
- `vfxPath`: string (required) - Path to VFX asset
- `fromIndex`: number (required) - Index of source context
- `toIndex`: number (required) - Index of target context

### unity_vfx_list_blocks
List all contexts and blocks in a VFX Graph with their indices and types.
**Parameters:**
- `path`: string (required) - Path to VFX Graph file

### unity_vfx_set_attribute
Set attribute value on a SetAttribute block (position, velocity, color, size, lifetime, etc.)
**Parameters:**
- `vfxPath`: string (required) - Path to VFX asset
- `contextIndex`: number (required) - Index of context containing the block
- `blockIndex`: number (required) - Index of SetAttribute block within context
- `attribute`: string (required) - Attribute name (position, velocity, color, size, lifetime, alpha, angle, etc.)
- `value`: string (required) - Value to set (e.g., "1,2,3" for vector, "#FF0000" for color, "0.5" for float)
- `composition`: string - How to combine with existing value

### unity_vfx_set_block_value
Set the spawn rate of a VFX Graph.
**Parameters:**
- `path`: string (required) - Path to VFX Graph file
- `contextIndex`: number (required) - Context index (0=spawn, 1=init, 2=update, 3=output)
- `blockIndex`: number (required) - Block index within context
- `property`: string - Property name to set
- `value`: string (required) - Value to set (e.g., "1,0.5,0" for color, "150" for rate)

### unity_vfx_set_output
Set output context settings on a VFX Graph (blendMode, texture, etc.)
**Parameters:**
- `path`: string (required) - Path to VFX Graph file
- `contextIndex`: number - Context index (output is usually 3)
- `blendMode`: string - Blend mode
- `texture`: string - Texture asset path (e.g., Assets/Synaptic AI Pro/Resources/VFX/Textures/flame_01.png)
- `softParticle`: boolean - Enable soft particles
- `sortPriority`: number - Sort priority

### unity_vfx_set_spawn_rate
Set the spawn rate of a VFX Graph.
**Parameters:**
- `path`: string (required) - Path to VFX Graph file
- `rate`: number (required) - Particles per second

## Weather (9 tools)

### unity_create_rain_effect
Create realistic rain effect with particle system
**Parameters:**
- `intensity`: number - Overall rain density and emission rate (0-1)
- `dropSize`: number - Size of each rain drop particle in world units
- `dropSpeed`: number - Vertical fall speed of rain drops in units per second
- `windStrength`: number - Horizontal wind force applied to falling drops
- `rainArea`: string - Box volume size for rain emitter as comma-separated "x,y,z"
- `useSplash`: boolean - Spawn splash particles where drops hit the ground

### unity_create_snow_effect
Create snow effect with falling snowflakes
**Parameters:**
- `intensity`: number - Overall snowfall density and emission rate (0-1)
- `flakeSize`: string - Min/max snowflake size as comma-separated "min,max" world units
- `fallSpeed`: number - Vertical fall speed of snowflakes in units per second
- `turbulence`: number - Random horizontal sway applied to snowflakes (0-1)
- `snowArea`: string - Box volume size for snow emitter as comma-separated "x,y,z"
- `accumulation`: boolean - Build up snow layer on ground meshes over time

### unity_create_terrain
Create a terrain in Unity
**Parameters:**
- `name`: string (required) - Name for the new terrain GameObject
- `width`: number - Terrain width in world units (default 500)
- `height`: number - Maximum terrain height in world units (default 600)
- `length`: number - Terrain length in world units (default 500)
- `heightmapResolution`: number - Heightmap resolution in pixels (default 513, must be 2^n + 1)

### unity_create_thunderstorm
Create complete thunderstorm with rain, wind, lightning and fog
**Parameters:**
- `intensity`: number - Overall thunderstorm intensity from 0 (light) to 1 (heavy)
- `windStrength`: number - Wind strength affecting rain direction and particle motion
- `lightningFrequency`: number - Lightning strikes per second during the storm
- `fogDensity`: number - Density of atmospheric fog applied to the scene
- `duration`: number - Duration in seconds (0 = continuous)

### unity_create_weather_system
🌦️ Create complete weather system with cinematic presets - One command for movie-quality weather!
**Parameters:**
- `preset`: string - Cinematic weather preset that configures particles, lighting, fog, and skybox
- `intensity`: number - Overall weather intensity (0-1)
- `transitionTime`: number - Time to transition between weather states

### unity_create_wind_effect
Create wind effect affecting objects and particles
**Parameters:**
- `strength`: number - Base wind force magnitude applied to affected objects
- `direction`: string - Wind direction as comma-separated normalized vector "x,y,z"
- `turbulence`: number - Random variation added on top of the base wind direction (0-1)
- `gustFrequency`: number - How often gusts occur, in Hz (gusts per second)
- `affectTrees`: boolean - Apply wind to Unity Terrain trees via WindZone
- `affectParticles`: boolean - Apply wind force to particle systems in the scene

### unity_get_terrain_info
Get information about terrain in the scene
**Parameters:**
- `terrainName`: string - Specific terrain GameObject name to query (omit to list all terrains)

### unity_modify_terrain
Modify terrain height or textures
**Parameters:**
- `name`: string (required) - Name of the terrain GameObject to modify
- `operation`: string (required) - Modification operation: raise heights, lower heights, flatten to a level, or smooth roughness
- `radius`: number - Brush radius in world units (default 10)
- `strength`: number - Brush strength from 0 to 1 (default 0.5)

### unity_set_weather_preset
Smoothly transition to a different weather preset
**Parameters:**
- `preset`: string (required) - Target weather preset to smoothly transition the existing weather system to
- `transitionTime`: number - Transition duration in seconds


---
Use execute(tool_name, params) to run any tool.