# Universal Task Delegation Template (OpenRouter Worker)

Use this template when preparing the `task` argument for `delegate_script` or `ask_worker`.

---

## 1. Task Definition
- **Objective**: [Clear 1-2 sentence description of what must be created, transformed, or refactored]
- **Target Path(s)**: 
  - Input: `[Explicit source path or directory]`
  - Output: `[Explicit target path or directory]`

## 2. Task Archetype & Execution Strategy
- **Archetype**: `[Data ETL / Batch Refactor / Static Tree Audit / Code Generation / External Mining]`
- **Engine**: Python 3 standard library only (`pathlib`, `csv`, `json`, `re`, `sqlite3`, `hashlib`, `os`, `sys`). Zero external pip dependencies.

## 3. Domain Guardrails & Constraints
- **Scope Isolation**: Touch ONLY the specified target files. Never modify unrelated project files.
- **File Encodings**: UTF-8 with BOM (`0xEF, 0xBB, 0xBF`) for game CSV tables; standard UTF-8 (no BOM) for JSON/source code; preserve existing line endings (LF/CRLF).
- **Data Integrity**: Preserve header rows, schemas, comments, and immutable lines as specified.
- **Null Safety**: Provide safe defaults (e.g., `0` for numeric fields, `""` for strings).
- **Idempotency**: Running the script repeatedly must produce identical results.

## 4. Minimal Reference Pattern / Schema (Phase 1 Sample)
```
[Paste only 3–5 sample lines of input data or old code pattern]
---
[Paste only 3–5 sample lines of target output format or new code pattern]
```

## 5. Self-Verification Assertions
The generated script must execute local verification before exiting:
- Print total records/files processed and modified count.
- Assert output file exists and is non-empty.
- Exit code 0 on success; non-zero with traceback on failure.
