#!/usr/bin/env python3
"""JSON-stdin bridge to the worker tools.

    echo '{"tool":"worker_status","args":{}}' | python tool.py

Reads {"tool": "<tool_worker_status|tool_ask_worker|tool_delegate_script|tool_execute_python>", "args": {...}}
and prints the MCP-style tool result as JSON. Exit code 1 when the tool reported an error.
Used by the pi extension in ~/.pi/agent/extensions/heavy-task-delegator.ts.
"""

import importlib.util
import json
import sys
from pathlib import Path

WORKER = Path(__file__).resolve().parent.parent / "mcp" / "openrouter_worker.py"


def load_worker():
    spec = importlib.util.spec_from_file_location("openrouter_worker", WORKER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    try:
        request = json.load(sys.stdin)
    except json.JSONDecodeError as exc:
        print(json.dumps({"content": [{"type": "text", "text": f"bad request: {exc}"}], "isError": True}))
        return 1

    name = str(request.get("tool") or "")
    fn = getattr(load_worker(), f"tool_{name}", None)
    if fn is None:
        print(json.dumps({"content": [{"type": "text", "text": f"unknown tool: {name}"}], "isError": True}))
        return 1

    result = fn(request.get("args") or {})
    json.dump(result, sys.stdout, ensure_ascii=False)
    return 1 if result.get("isError") else 0


if __name__ == "__main__":
    raise SystemExit(main())
