<#
.SYNOPSIS
    Delegate a heavy/mechanical task to a cheap worker model via headless pi.

.DESCRIPTION
    Runs `pi -p` isolated from project context (no AGENTS.md, skills, extensions, session),
    writes the full transcript to .delegate/<timestamp>-<task>.log and prints only the tail.

.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File delegate.ps1 -TaskFile DELEGATE_TASK.md -Background

.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File delegate.ps1 -TaskFile DELEGATE_TASK.md -Model openrouter/free
#>
[CmdletBinding()]
param(
    [string]$TaskFile = "DELEGATE_TASK.md",
    [string]$Model    = "deepseek/deepseek-v4.1-flash",
    [string]$Provider = "openrouter",
    [int]$TailLines   = 40,
    [string]$Thinking = "off",
    [switch]$Free,
    [switch]$Background
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

if (-not (Test-Path -LiteralPath $TaskFile)) {
    throw "Task file not found: '$TaskFile'. Write the spec first (templates/DELEGATE_TASK.md)."
}

if ($Free) { $Model = "openrouter/free" }

$root   = (Get-Location).Path
$logDir = Join-Path $root ".delegate"
New-Item -ItemType Directory -Force -Path $logDir | Out-Null

$slug  = [System.IO.Path]::GetFileNameWithoutExtension($TaskFile).ToLowerInvariant() -replace '[^a-z0-9]+', '-'
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$log   = Join-Path $logDir "$stamp-$slug.log"

$piArgs = @(
    "-p",
    "-nc", "-ns", "-ne", "-np", "-na",
    "--provider", $Provider,
    "--model",    $Model,
    "--thinking", $Thinking,
    "--no-session",
    "@$TaskFile"
)

if ($Background) {
    $errLog = "$log.err"
    $proc = Start-Process -FilePath "pi" -ArgumentList $piArgs -NoNewWindow -PassThru `
              -RedirectStandardOutput $log -RedirectStandardError $errLog
    Write-Output "PID=$($proc.Id)"
    Write-Output "LOG=$log"
    Write-Output "ERR=$errLog"
    Write-Output "MODEL=$Provider/$Model"
    exit 0
}

$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
$output = & pi @piArgs 2>&1
$exitCode = $LASTEXITCODE
$stopwatch.Stop()

$output | Out-File -LiteralPath $log -Encoding utf8

Write-Output "=== DELEGATE RESULT ==="
Write-Output "exit=$exitCode  model=$Provider/$Model  elapsed=$([int]$stopwatch.Elapsed.TotalSeconds)s"
Write-Output "log=$log"
Write-Output "--- tail (last $TailLines lines) ---"
$output | Select-Object -Last $TailLines | ForEach-Object { Write-Output $_ }

exit $exitCode
