#!/usr/bin/env python3
"""Run the openrouter-worker delegation from the shell (no MCP gateway, no 30s call timeout).

Usage:
    python delegate.py --task DELEGATE_TASK.md --workdir F:/GihOt/n108-client
    python delegate.py --ask "summarize these 20 log lines: ..."
    python delegate.py --run-script .delegate/transform.py --workdir .
"""

import argparse
import importlib.util
import sys
from pathlib import Path

WORKER = Path(__file__).resolve().parent.parent / "mcp" / "openrouter_worker.py"


def load_worker():
    spec = importlib.util.spec_from_file_location("openrouter_worker", WORKER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    parser = argparse.ArgumentParser(description="Delegation without the MCP transport.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--task", help="Path to the spec file, or '-' for stdin.")
    group.add_argument("--ask", help="One-shot prompt for the worker model.")
    group.add_argument("--run-script", dest="run_script", help="Path to a Python script to execute locally.")
    parser.add_argument("--workdir", default=".", help="Directory the script runs in (default: cwd).")
    parser.add_argument("--model", default=None, help="Override model, single attempt (no chain).")
    parser.add_argument("--timeout", type=int, default=600, help="Script execution timeout in seconds.")
    parser.add_argument("--keep-script", action="store_true", help="Keep the generated script after success.")
    args = parser.parse_args()

    worker = load_worker()

    if args.task:
        text = sys.stdin.read() if args.task == "-" else Path(args.task).read_text(encoding="utf-8")
        result = worker.tool_delegate_script(
            {
                "task": text,
                "workdir": args.workdir,
                "model": args.model,
                "timeout_s": args.timeout,
                "keep_script": args.keep_script,
            }
        )
    elif args.ask:
        prompt = sys.stdin.read() if args.ask == "-" else args.ask
        result = worker.tool_ask_worker({"prompt": prompt, "model": args.model})
    else:
        result = worker.tool_execute_python(
            {
                "script_path": args.run_script,
                "workdir": args.workdir,
                "timeout_s": args.timeout,
                "keep_script": args.keep_script,
            }
        )

    print(result["content"][0]["text"])
    return 1 if result.get("isError") else 0


if __name__ == "__main__":
    raise SystemExit(main())
