#!/usr/bin/env python3
"""Benchmark OpenRouter free models on the real worker job: spec -> Python script -> run -> verify.

The fixture is a UTF-8-BOM CSV with Vietnamese text in the 2nd header row and an empty numeric
cell — i.e. the exact failure modes that matter for this project (BOM loss, mojibake, header
rewrite, empty numeric cells).

Usage:
    python bench_free_models.py                 # every :free model, 1 run each
    python bench_free_models.py --runs 2 --parallel 4
    python bench_free_models.py --models poolside/laguna-s-2.1:free,google/gemma-4-31b-it:free
Results are appended to bench_results.jsonl next to this script.
"""

import argparse
import ast
import concurrent.futures
import importlib.util
import json
import pathlib
import statistics
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

HERE = pathlib.Path(__file__).resolve().parent
WORKER = HERE.parent / "mcp" / "openrouter_worker.py"
RESULTS = HERE / "bench_results.jsonl"

SPEC = """Working directory: {workdir}
Edit {csv} IN PLACE (that exact file; do not search the directory for other CSVs).
Data rows start at line 3; the first 2 header rows must stay byte-identical (the file contains
Vietnamese UTF-8 text - do not corrupt it).
For each data row: Cost is column index 2; if the cell is empty treat it as 0; multiply by 1.5;
round to 2 decimals; write it back formatted as f'{{v:.2f}}'.
Do not touch Id, Name, Lv. Do not add or remove rows. Keep the UTF-8 BOM.
Print exactly: rows_changed=N bom=OK|FAIL lines=N"""

FIXTURE = "\ufeffId,Name,Cost,Lv\nID,Tên,Giá,Level\n1,Sword,,5\n2,Shield,10.0,3\n3,Bow,2.55,7\n"
EXPECTED_HEADER = ["Id,Name,Cost,Lv", "ID,Tên,Giá,Level"]
EXPECTED_COST = (["0.00", "15.00", "3.82"], ["0.00", "15.00", "3.83"])


def load_worker():
    spec = importlib.util.spec_from_file_location("openrouter_worker", WORKER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


OW = load_worker()
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def free_models() -> list:
    req = urllib.request.Request(
        "https://openrouter.ai/api/v1/models", headers={"Authorization": f"Bearer {OW.api_key()}"}
    )
    models = json.load(OPENER.open(req, timeout=120))["data"]
    return sorted(m["id"] for m in models if m["id"].endswith(":free"))


def generate(model: str, spec: str) -> dict:
    payload = {
        "model": model,
        "messages": [{"role": "system", "content": OW.SYSTEM_SCRIPT}, {"role": "user", "content": spec}],
        "max_tokens": OW.MAX_SCRIPT_TOKENS,
        "temperature": 0.1,
    }
    if OW.REASONING_EFFORT and OW.REASONING_EFFORT.lower() not in ("off", "none", "0"):
        payload["reasoning"] = {"effort": OW.REASONING_EFFORT}
    req = urllib.request.Request(
        OW.API_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {OW.api_key()}", "Content-Type": "application/json"},
        method="POST",
    )
    meta = {"model": model}
    started = time.time()
    try:
        body = json.loads(OPENER.open(req, timeout=600).read())
    except urllib.error.HTTPError as exc:
        meta.update(error=f"HTTP {exc.code}", detail=exc.read().decode("utf-8", "replace")[:160])
        meta["seconds"] = round(time.time() - started, 1)
        return meta
    except Exception as exc:  # network / timeout
        meta.update(error=type(exc).__name__, detail=str(exc)[:160])
        meta["seconds"] = round(time.time() - started, 1)
        return meta
    choice = (body.get("choices") or [{}])[0]
    usage = body.get("usage") or {}
    content = (choice.get("message") or {}).get("content") or ""
    meta.update(
        seconds=round(time.time() - started, 1),
        finish=choice.get("finish_reason"),
        tokens=usage.get("completion_tokens"),
        reasoning=((usage.get("completion_tokens_details") or {}).get("reasoning_tokens")) or 0,
        content=content,
    )
    return meta


def verify(workdir: pathlib.Path, csv: pathlib.Path, code: str) -> tuple:
    checks = {"parse": False, "run": False, "bom": False, "header": False, "rows": False, "cost": False}
    diag = {}
    try:
        ast.parse(code)
        checks["parse"] = True
    except SyntaxError as exc:
        diag["syntax_error"] = str(exc)[:160]
        return checks, diag
    script = workdir / "gen.py"
    script.write_text(code, encoding="utf-8")
    try:
        proc = subprocess.run(
            [sys.executable, str(script)], cwd=workdir, capture_output=True, text=True, timeout=180
        )
        checks["run"] = proc.returncode == 0
        diag["run_exit"] = proc.returncode
        if proc.returncode != 0:
            diag["stderr"] = (proc.stderr or "").strip()[-300:]
    except subprocess.TimeoutExpired:
        diag["run_exit"] = "timeout180"
        return checks, diag
    raw = csv.read_bytes()
    checks["bom"] = raw[:3] == b"\xef\xbb\xbf"
    try:
        lines = raw.decode("utf-8-sig").splitlines()
    except UnicodeDecodeError:
        diag["decode"] = "UnicodeDecodeError"
        return checks, diag
    checks["header"] = lines[:2] == EXPECTED_HEADER
    checks["rows"] = len(lines) == 5 and all(len(line.split(",")) == 4 for line in lines)
    costs = [line.split(",")[2] for line in lines[2:]] if len(lines) > 2 else []
    checks["cost"] = costs in EXPECTED_COST
    if not checks["cost"]:
        diag["cost_actual"] = costs
        diag["header_actual"] = lines[:2]
    return checks, diag


def run_once(model: str) -> dict:
    workdir = pathlib.Path(tempfile.mkdtemp(prefix="owbench_"))
    csv = workdir / "Test.csv"
    csv.write_text(FIXTURE, encoding="utf-8", newline="")
    spec = SPEC.format(workdir=workdir.as_posix(), csv=csv.as_posix())
    result = generate(model, spec)
    if "content" in result:
        content = result.pop("content")
        try:
            code = OW.extract_code(content)
        except RuntimeError:
            result["checks"] = {k: False for k in ("parse", "run", "bom", "header", "rows", "cost")}
            result["error"] = "no python block"
            result["diag"] = {"raw_head": content.strip()[:200]}
        else:
            result["checks"], result["diag"] = verify(workdir, csv, code)
    else:
        result["checks"] = {k: False for k in ("parse", "run", "bom", "header", "rows", "cost")}
    result["pass"] = all(result["checks"].values())
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", default="", help="Comma-separated model ids (default: all :free).")
    parser.add_argument("--runs", type=int, default=1)
    parser.add_argument("--parallel", type=int, default=4)
    args = parser.parse_args()

    models = [m.strip() for m in args.models.split(",") if m.strip()] or free_models()
    jobs = [(model, run) for model in models for run in range(args.runs)]

    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.parallel) as pool:
        futures = {pool.submit(run_once, model): (model, run) for model, run in jobs}
        for future in concurrent.futures.as_completed(futures):
            model, run = futures[future]
            try:
                result = future.result()
            except Exception as exc:  # benchmark harness must never die on one model
                result = {"model": model, "error": f"{type(exc).__name__}: {exc}", "pass": False, "checks": {}}
            result["run"] = run + 1
            results.append(result)
            with RESULTS.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(result) + "\n")
            flag = "PASS" if result["pass"] else "FAIL"
            failed = [k for k, v in (result.get("checks") or {}).items() if not v]
            diag = result.get("diag") or {}
            detail = result.get("error") or ("failed:" + ",".join(failed) if failed else "")
            if diag:
                detail += " " + json.dumps(diag, ensure_ascii=False)[:220]
            print(
                f"{flag} {model:<52} run={result['run']} {result.get('seconds', '?')}s "
                f"tok={result.get('tokens')} rsn={result.get('reasoning')} "
                f"finish={result.get('finish')} {detail}",
                flush=True,
            )

    print("\n=== SUMMARY (passes / runs, median seconds, median tokens) ===")
    for model in models:
        rows = [r for r in results if r["model"] == model]
        passes = sum(1 for r in rows if r["pass"])
        secs = [r["seconds"] for r in rows if r.get("seconds")]
        toks = [r["tokens"] for r in rows if r.get("tokens")]
        reasons = {(r.get("error") or ",".join(k for k, v in (r.get("checks") or {}).items() if not v)) for r in rows}
        print(
            f"{passes}/{len(rows)}  {statistics.median(secs) if secs else '?':>6}s  "
            f"{int(statistics.median(toks)) if toks else '?':>6}tok  {model:<52} {' | '.join(sorted(x for x in reasons if x))[:60]}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
