---
name: heavy-task-delegator
description: >-
  Universal token-saving 3-phase delegation framework for heavy, mechanical, multi-file,
  or repetitive tasks across any codebase or domain. Infused with Ponytail's lazy senior dev
  discipline (-53% code, -45% tokens, shortest working diff). Phase 1: 2-3 call micro-recon
  (codebase-memory-mcp / direct paths). Phase 2: isolated background execution on pi 1.4.0's
  native tools — `worker_exec` → `worker_ask` / `worker_delegate` → `free_agent` — over the free
  cascade (`poolside/laguna-s` → `nvidia/nemotron-3-ultra` → `openrouter/free`
  → `minimax/minimax-m3.1-flash` → `recursive/flint-v1.0`). Phase 3: Ponytail QA gate.
  Triggers autonomously whenever a task involves >1 file edit, >100 rows/lines, directory traversal,
  external codebase mining, or repetitive mechanical changes.
---

# Heavy Task Delegator (Universal Ponytail Edition)

*Rev 1.5 — synced to pi 1.4.0 (2026-10-21): the MCP `call_mcp_tool` route is retired; the
native `worker_*` ladder is authoritative; codemode worker admission, `// @options`, image
classifiers and no-cap summaries are folded into §7.*

Main model = **Architect & Senior QA Gate**.  
Worker model = **Fast, Isolated, Minimal Mechanical Executor**.  
*"The best code is the code you never wrote. The shortest working diff wins."*

---

## 🛑 UNIVERSAL DELEGATION MANDATE (CỔNG CHẶN BẮT BUỘC CHO MỌI TÁC VỤ)

Whenever a task involves heavy, mechanical, multi-file, or repetitive work (regardless of domain, language, or project):

1. **STRICT MAX 2–3 RECON CALLS TOTAL**:
   - Phase 1 Recon is hard-capped at **2 to 3 targeted tool calls maximum** in the main conversation.
   - Typically: 1 tool call to locate the target path/symbol + 1 tool call to inspect 3–5 sample lines of schema/input.
2. **ZERO ITERATIVE FILE-READS / DIR-CRAWLS IN MAIN CONTEXT**:
   - **NEVER** execute sequential `view_file` calls across multiple files.
   - **NEVER** execute recursive directory searches (`Get-ChildItem -Recurse`, `find`, `ls -R`), or bash grep loops in the main conversation.
   - If multiple files, directories, external codebases, or vendor folders need to be scanned or mined, pass their root paths to the worker (`worker_delegate` / `free_agent`)!
3. **IMMEDIATE DELEGATION TRANSITION**:
   - The moment the target input/output boundaries and sample schema are identified (within 2–3 calls), **STOP LOCAL EXPLORATION IMMEDIATELY**.
   - 👉 **YOUR VERY NEXT TOOL CALL MUST BE `worker_exec` (deterministic script) or `worker_delegate` (generated script)** — `free_agent` when real multi-file edits are needed. The old `call_mcp_tool(ServerName="openrouter-worker", …)` route **does not exist in pi**.
   - Continuing to read files, run bash loops, or inspect data yourself in the main session is a **STRICT POLICY BREACH**.

---

## 1. Universal Scope — When to Delegate (Every Task Archetype)

This skill is completely task-agnostic and applies to **any project, language, or domain**:

| Task Archetype | Real-World Examples | Delegation Strategy |
|---|---|:---:|
| **1. Data Wrangling, ETL & Schema Migration** | CSV, JSON, YAML, XML, SQL, SQLite, Protobuf, TSV, Parquet; converting tables, normalizing fields, re-indexing keys, syncing schemas. | **YES — Phase 1 + 2** |
| **2. Multi-File Refactor & AST Rewrites** | Project-wide symbol renames, updating deprecated APIs, import reorganization, dead-code removal, batch formatting across >1 file. | **YES — Phase 1 + 2** |
| **3. Static Analysis, Audits & Diagnostics** | Scanning trees for broken links, missing asset GUIDs, secret leaks, dependency CVEs, encoding checks (BOM/CRLF), schema drift. | **YES — Fast-Path (`worker_exec`)** |
| **4. Boilerplate & Code Generation** | Generating DTOs, serializers, interfaces, client SDK bindings, unit test fixtures, mock data generators across multiple files. | **YES — Phase 2** |
| **5. External Codebase & Upstream Mining** | Crawling external repos, upstream vendor code, submodules, SDKs, or legacy source trees to extract constants, signatures, or datasets. | **YES — Phase 1 + 2** |
| **6. Massive Log & Trace Diagnostics** | Parsing multi-megabyte log files, crash stacks, profiler traces, network captures to extract structured root-cause summaries. | **YES — Phase 2** |
| **7. Unity Editor via `unity-synaptic`** | Scene/build-settings edits, component wiring, playtest runs, screenshots, compile checks, YAML project settings. | **YES — `references/unity-bridge-playbook.md` (budgeted, §6)** |
| **Core Architecture & Single-File Bugfixes** | Designing module structure, pinpointing complex single-point bugs, writing custom shaders/algorithms (<1 file). | **NO — Main Session** |
| **Ambiguous Requirements** | Underspecified requirements needing user input or design decisions. | **NO — Clarify First** |

---

## 2. Autonomous Ponytail Mode Decision (Zero-Prompt Auto-Switch)

The agent autonomously evaluates the task and selects the Ponytail engagement level **without requiring user prompt**:

| Task Category | Auto Ponytail Mode | Behavior & Execution Strategy |
|---|:---:|---|
| **Bulk Data Edits / Table Sync / Ingestion** | **PONYTAIL FULL (Auto)** | Shortest working diff, 0 wrappers/classes, stdlib `csv`/`json`/`pathlib`, encoding auto-enforced. |
| **Mechanical Refactor / Bulk Rename / Dead Code** | **PONYTAIL FULL (Auto)** | Minimal targeted edit, reuse existing code/helpers, delete beats add. |
| **Audits / Integrity Checks / Encoding Verification** | **PONYTAIL FAST-PATH (Auto)** | Use `worker_exec` directly (0s latency, 0 AI tokens) instead of LLM generation. |
| **Over-Engineered Spec / Bloated Architecture** | **PONYTAIL ULTRA (Auto)** | Proactively push back: replace complex multi-class plan with the 5-line native solution. |
| **Foundational Modules / New Frameworks** | **PONYTAIL LITE (Auto)** | Preserve necessary architecture/interfaces while cutting speculative options. |
| **Complex Visual Tools / Interactive Dashboards** | **PONYTAIL OFF (Auto)** | Full implementation permitted (UI controls, 3D math, canvas rendering) without aggressive golf. |

### Ponytail Core Principles (Lazy Senior Dev)
1. **The Smallest Complete Change**: Solve the entire task with the least new code. No abstractions, no wrappers, no classes, no speculative "for later" features nobody asked for.
2. **Reuse Before Writing**: Check if the codebase already has a script in `tools/` or a pattern in the standard library. Reuse it.
3. **Standard Library Only**: Worker scripts must use Python stdlib (`csv`, `pathlib`, `re`, `json`, `sqlite3`, `hashlib`). Zero new dependencies.
4. **Never Cut Safety**: Never compromise file integrity, encoding requirements (e.g. UTF-8 BOM where required), schema headers, or data validation at boundaries.
5. **Ponytail Disclosure**: Always end the task summary with 1–2 lines: what was skipped, and any risks the user must know.

---

## 3. The 3-Phase Execution Architecture

```mermaid
flowchart TD
    Task["Any Heavy Task<br>(Data ETL, Multi-File Refactor, Tree Audit, External Source)"] --> Decider{"Autonomous Decider"}
    
    Decider -->|"Static Audit / Known Transform"| FastPath["FAST-PATH: worker_exec<br>(Direct execution in 0.1s, 0 AI tokens)"]
    Decider -->|"Mechanical Generation / Search / Convert"| P1["Phase 1: Micro-Recon<br>(Max 2-3 calls: Locate path + 3-5 line sample schema)"]
    
    P1 -->|"Immediate Gate Transition"| P2["Phase 2: worker_delegate / free_agent<br>(Free cascade: Laguna -> Nemotron -> OpenRouter -> MiniMax -> Flint)"]
    P2 -->|"Worker runs isolated local Python"| P3["Phase 3: Ponytail QA Gate<br>(Main session audits diff & verifies integrity)"]
    FastPath --> P3
    
    P3 -->|"Git diff check + 1-line Ponytail disclosure"| Done["Task Shipped Cleanly"]
```

### Phase 1 — Micro-Reconnaissance (Strict Max 2–3 Calls)
- Use graph tools (`search_graph`, `trace_path`, `get_code_snippet`) or direct known paths to locate target boundaries.
- Inspect at most **3–5 sample lines** of input/output to extract the data schema or pattern.
- **NEVER** crawl folders or open multiple data files in the main session.
- Immediately package the task specification and call Phase 2.

### Phase 2 — Delegate to the free worker (pi-native tools)

> **pi harness (this machine):** pi has no MCP transport, so `call_mcp_tool` does not
> exist here. Use the native tools registered by
> `~/.pi/agent/extensions/heavy-task-delegator.ts` — **`worker_status`**, **`worker_ask`**,
> **`worker_delegate`**, **`worker_exec`** — which reach the same server through
> `scripts/tool.py` (JSON on stdin). Shell equivalents:
> `python scripts/delegate.py --ask "…"` / `--task spec.md` / `--run-script x.py`.
> `workdir` must be a native Windows path (`C:\…`) — `/tmp/…` and `/d/…` fail with
> "workdir not found". Windows has no POSIX temp; use `%LOCALAPPDATA%\Temp`.
>
> **Cheapest-first ladder (token saving):**
> 1. `worker_exec` — deterministic local Python, zero model calls.
> 2. `worker_ask` / `worker_delegate` — free OpenRouter tiers for text and script generation.
> 3. `free_agent` — a nested pi agent on a free model **with full tools**, for real
>    multi-file work (verified: writes files correctly). Give it a self-contained task.
> 4. Only then do the work in the main session.
>
> Slash commands: **`/free`** moves the session onto a free OpenRouter model,
> **`/paid`** returns to the `settings.json` default (`defaultProvider`/`defaultModel`).

The worker backend (`scripts/tool.py`, driven by the native `worker_*` tools; chain and budgets live in `worker.json`) executes a cascading 5-tier fallback across free models with an integrated timeout budget:

| Tier | Model | Benchmark Role | Latency | Cost |
|:---:|---|---|:---:|:---:|
| **1** | `poolside/laguna-s-2.1:free` | Coding specialist (fastest pure Python generator) | 5.4s | $0 |
| **2** | `nvidia/nemotron-3-ultra-550b-a55b:free` | Data precision specialist (CSV/JSON/dialect master) | 10.5s | $0 |
| **3** | `openrouter/free` | Dynamic router (auto-routes to healthiest free endpoint) | 7.7s | $0 |
| **4** | `minimax/minimax-m3.1-flash:free` | Reliable workhorse (100% pass rate, self-repair) | 16.3s | $0 |
| **5** | `recursive/flint-v1.0:free` | Complex reasoning backup | 40.9s | $0 |

#### The Four Worker Tools (pi names; MCP-era alias in brackets):
- **`worker_delegate`** [was `delegate_script`] (*Primary*): The worker model writes a self-contained Python script; it is executed locally, exit code 0 validated, and only the summary output returned. Auto-repairs once on failure.
- **`worker_exec`** [was `execute_python`] (*Fast-Path*): Execute deterministic Python code directly without LLM generation (instant, 0 tokens).
- **`worker_ask`** [was `ask_worker`]: Pure text generation without code execution (for boilerplate, enums, regex patterns, or a second opinion).
- **`worker_status`**: Diagnostic check on worker health, OpenRouter key, active chain, and environment.
- **`free_agent`**: nested pi agent on a free model **with full tools** (read/bash/edit/write) for real multi-file work. Give it absolute paths and a verification step — it cannot see this conversation.

#### Writing the Universal Task Specification:
The `task` parameter is self-contained (the worker cannot see your conversation context):
1. **Objective**: 1–2 sentences defining the exact required end state.
2. **Target Paths**: Explicit input and output paths (absolute or workspace-relative).
3. **Data Schema / Pattern**: Provide the exact 3–5 line sample extracted in Phase 1.
4. **Guardrails**: Specific safety rules (e.g., UTF-8 BOM, preserve headers, immutable files, standard library only).
5. **Self-Verification**: Require the script to print verification statistics (e.g. processed record count, error count).

### Phase 3 — Ponytail QA Gate (Mandatory in Main Context)
The main agent reviews the output as a senior engineer:
1. **Diff Audit**: Verify `git diff --stat` — only specified files may be touched.
2. **Schema & Data Integrity**: Verify row/line counts, required encodings (e.g. UTF-8 BOM for CSV tables), and null-safety.
3. **Ponytail Lean Standard**: Ensure zero leftover debug scripts, zero bloated wrapper classes, and zero unneeded dependencies.
4. **Ponytail Disclosure**: Close the response with a 1–2 line disclosure of what was completed, what was skipped, and any runtime considerations.

---

## 4. Universal Task Recipes

### Recipe A: Bulk Data Ingestion / Conversion (Any Format)
```python
# Task spec for worker_delegate:
task = """
Convert input dataset <source_path> (JSON/XML/SQL) into target format <target_path> (CSV/JSON).
Sample Input Schema:
{sample_input}
Target Output Schema:
{sample_output}
Guardrails:
- Standard library only (json, csv, pathlib).
- Encoding: UTF-8 with BOM (0xEF, 0xBB, 0xBF) if CSV.
- Null safety: default numeric fields to 0, strings to empty.
- Print verification: total records converted, total errors.
"""
```

### Recipe B: Multi-File Code Refactoring / Migration
```python
# Task spec for worker_delegate:
task = """
Refactor deprecated API calls across all files in <source_directory>.
Pattern to replace:
  Old: `OldService.Execute(query, timeout)`
  New: `NewClient.Run(query, Options(timeout=timeout))`
Guardrails:
  - Only touch files matching '*.cs' or '*.py'.
  - Preserve all existing comments, docstrings, and formatting.
  - Print list of modified files and total replacements made.
"""
```

### Recipe C: Fast-Path Static Tree Audit (`worker_exec`)
```python
# Direct code passed to worker_exec:
code = """
import pathlib, sys

root = pathlib.Path(r"<directory_path>")
issues = []
for p in root.rglob("*.json"):
    try:
        # Check integrity or encoding
        raw = p.read_bytes()
        # Custom validation logic...
    except Exception as e:
        issues.append(f"{p}: {e}")

print(f"Scanned {len(list(root.rglob('*.json')))} files. Found {len(issues)} issues.")
for iss in issues[:10]:
    print(" -", iss)
"""
```

### Recipe D: External Repository / Directory Mining
```python
# Task spec for worker_delegate:
task = """
Scan external repository at <external_source_path> to extract all constant definitions matching 'CONFIG_*'.
Write the extracted constants into local project file <project_target_path>.
Guardrails:
- Scan read-only; never modify any file in the external directory.
- Deduplicate keys and sort alphabetically.
- Output clean JSON or target code definition.
"""
```

---

## 5. Hard Rules & Failure Recovery

- **Zero Broad Crawls**: The main session must never crawl large directories or execute sequential file reads. Delegate to the worker immediately after Phase 1 micro-recon.
- **Stdlib Only**: Worker scripts must rely exclusively on Python standard library modules (`pathlib`, `csv`, `json`, `re`, `sqlite3`, `hashlib`, `os`, `sys`).
- **Terminal Fallback**: If all free worker tiers fail (`WORKER_UNAVAILABLE`), perform the minimal necessary targeted edit in the main session using graph tools.
- **Single Turn Focus**: Execute one delegation task per turn. Verify diff before moving to subsequent tasks.

---

## 6. Domain Adapter — Unity Editor (`unity-synaptic`)

Unity is the one domain where the worker model **cannot** act (the bridge is stateful and
sits in the main session's tool list), so the *main* session must behave. Full detail,
verified tool table and params: **`references/unity-bridge-playbook.md`**.
Grep-able catalog of all 358 inner tools: **`references/unity-tools-catalog.md`**.

Six rules — each one is a scar from a real session that burnt ~15 bridge calls on a
3-call task:

1. **Never guess a `unity_*` tool name.** 0 calls: grep the catalog file. 1 call:
   `list_categories` (plain text, safe). `list_tools` / `search_tools` can die with
   `UnicodeEncodeError` on emoji titles — one crash = change strategy, never retry.
2. **Budget: recon ≤3, act ≤3, verify ≤2** bridge calls. Over budget → stop and report
   unknowns instead of poking the editor. First Unity call of a task:
   **`unity_bridge_status`** (2 layers, ≤20 s each) — it tells `node server` from
   `Unity editor` before you spend calls. A link failure opens a 60 s circuit breaker
   (30 s for busy) and every further call fails in ~0 s with `UNITY_DOWN`; recovery is
   Unity → `Tools > Synaptic Pro > AI Reconnect`. Never re-send a call into a socket
   that already dropped (playbook §9).
3. **`run_csharp` = ≤3 statements + one `return <expr>;`**, fully-qualified types, no
   `var`/`foreach`/LINQ/`StringBuilder`. Never read the `CS1685` mcs warning wall, never
   grep `Editor.log` for `error CS` (matches eval noise, truncates at 50 KB).
4. **Verify with a dedicated getter, not a mutation's return value** —
   `unity_get_runtime_status` (play/compile/FPS), `unity_get_build_settings`,
   `unity_get_component_details`, then `git diff`. Empty/`exit null` body = **the Editor
   main thread is blocked (usually a modal dialog: "Reload Scene?", unsaved changes,
   compile errors, play-mode switch)** — the request is still queued and will execute late,
   so never retry; read state first (playbook §8).
5. **Tools before YAML.** `unity_add_scene_to_build`, `unity_add_component`,
   `unity_update_component`, `unity_load_scene`, `unity_execute_menu_item` exist —
   hand-editing `.unity` YAML with an invented `fileID` is the last resort and must be
   proven by loading the scene and reading the component back.
6. **Announce editor-state mutations before doing them** — load/unload scene, enter
   Play mode, `force_refresh_assets(force)`, build/HybridCLR menus. Read-only `get_*`
   calls are free inside the budget.

Playtest = the recipe in the playbook §7: `list_all_scenes` → `get_build_settings` →
`add_scene_to_build` → read back → `Edit/Play` → `get_runtime_status` →
`capture_game_view`. Close with a Ponytail line: what editor state was mutated, whether
the scene was saved, which verification was skipped.

---

## 7. pi 1.4.0 Harness Notes (verified 2026-10-25 on pi 1.4.0)

Facts that change *how* you delegate — no delegation decision may contradict them.

1. **Codemode workers are a shared pool of 2.** Parallel codemode calls and in-process
   subagents now queue up to 60 s instead of failing; `PI_CODEMODE_MAX_WORKERS=N` raises the
   limit. Prefer **one** codemode script using `Promise.allSettled(...)` over N parallel
   calls: one worker, no queue, one result.
2. **`// @options:` must be line 1** of a codemode script. Anywhere else the call now fails
   *before* running. That is where a long audit's `timeout_ms` belongs.
3. **Output is capped** at 16 Mi characters / 100 000 items per script — a print-loop kills
   the run. Worker scripts print *stats only* (`processed=… errors=…`), never rows.
4. **`models.classify()` accepts images** (TypeSafe Jev, Cloudflare Clef on `typesafe`,
   `cloudflare-workers-ai`, `openrouter`) and `models.generateImages()` exists. Use a
   classifier for triage ("is this a CSV or a log?") instead of spending a whole worker
   call. `tools.read()` on an image returns an image block, which `image()` shows and saves
   to a named temp file.
5. **Never delegate summaries.** Compaction and branch summaries now use the model's own
   output limit (`compaction.reserveTokens` only decides *when* to compact), so `/compact`
   no longer dies on long reasoning — there is nothing for a worker to rescue.
6. **Search:** the built-in grep runs `rg --no-config` (a hostile `RIPGREP_CONFIG_PATH` can
   no longer silently turn a regex into a literal); `codebase_memory.search_code` takes
   `pattern` (not `query`), `search_graph` takes `query`, and `codebase_projects` names the
   project first.
7. **Model switching:** `/free` moves the session onto a free OpenRouter model, `/paid`
   returns to `settings.json`. `minimax/minimax-m3.1-flash` is now a first-class model on the
   `minimax` / `minimax-cn` providers (thinking `low`…`max`), not only worker tier 4.
8. **Windows:** every `workdir` is a native path (`C:\…`); `/tmp/…` and `/d/…` fail with
   "workdir not found". Use `%LOCALAPPDATA%\Temp`.

*Rev 1.5 changelog — removed the retired MCP route (`call_mcp_tool` / `openrouter-worker`)
from every section; the `worker_exec` → `worker_ask` / `worker_delegate` → `free_agent`
ladder is authoritative; recipes renamed to the real tool names; §7 added for pi 1.4.0
(codemode admission limits, `@options` placement, output caps, image classifiers, no-cap
summaries, `rg --no-config`, `/free` `/paid`).*
