# Heavy Task Delegator — Hướng Dẫn Toàn Diện Từ A Đến Z

> **Phiên bản**: 4.0 (pi 1.4.0 Native Tools Edition — Cập nhật ngày 2026-10-25)  
> **Kiến trúc tích hợp**: `codebase-memory-mcp` (Trinh sát Đồ thị) + Worker native của pi (`worker_exec` → `worker_ask` / `worker_delegate` → `free_agent`, chuỗi free OpenRouter $0.00) + Agent chính (Kiến trúc sư & QA Gate) + Ponytail (Kỷ luật Lập trình viên Kỳ cựu Tối giản).
>
> **Đã loại bỏ**: đường MCP `call_mcp_tool(ServerName="openrouter-worker", …)`. pi 1.4.0 không có MCP transport — mọi tên tool cũ (`delegate_script`, `execute_python`, `ask_worker`) đã được thay bằng tool native.

---

## 1. Giới Thiệu & Triết Lý Cốt Lõi

Khi phát triển các dự án phần mềm hoặc game quy mô lớn (như game Unity/C#/Lua với hàng trăm nghìn dòng code và hàng chục bảng cấu hình CSV khổng lồ), việc nạp toàn bộ file vào context của mô hình AI chính sẽ gây ra các vấn đề nghiêm trọng:
1. **Cạn kiệt token context window** (chi phí cao, nghẽn bộ nhớ).
2. **Độ trễ phản hồi tăng đột biến** do mô hình phải xử lý context hàng trăm ngàn token.
3. **Chạm trần rate-limit / timeout** của giao thức client (lỗi `context deadline exceeded`).

**Heavy Task Delegator** giải quyết triệt để vấn đề này thông qua mô hình phân tầng trách nhiệm:

```mermaid
flowchart TD
    User["Yêu Cầu Tác Vụ Nặng<br>(CSV lớn, Mass Refactor, Audit)"] --> Decider{"Bộ Tự Động Nhận Diện<br>(Zero-Prompt Ponytail)"}
    
    Decider -->|"Tác vụ Audit / Check format"| FastPath["FAST-PATH: worker_exec<br>(Chạy trực tiếp trong 0.1s, 0 token AI)"]
    Decider -->|"Tác vụ Biến đổi dữ liệu / Script mới"| P1["PHA 1: Trinh Sát Cấu Trúc<br>(codebase-memory-mcp — 0 token file)"]
    
    P1 -->|"Định vị đúng file/schema"| P2["PHA 2: Ủy Quyền Worker<br>(worker_delegate / free_agent — $0.00 Free Chain)"]
    P2 -->|"Sinh Python tối giản & Chạy máy cục bộ"| P3["PHA 3: Thẩm Định QA Gate<br>(Agent chính + Ponytail Lean Review)"]
    FastPath --> P3
    
    P3 -->|"Audit diff, UTF-8 BOM, 1-line Disclosure"| Done["Hoàn Tất Xuất Sắc"]
```

### Triết Lý Ponytail: "The Best Code Is The Code You Never Wrote"
Skill được tích hợp nguyên lý lập trình viên kỳ cựu lười biếng từ dự án **Ponytail** (`DietrichGebert/ponytail`):
- **-53% dòng mã sinh ra**: Worker chỉ viết đúng logic cần thiết (15–20 dòng Python thuần).
- **-41% độ trễ**: Giảm thời gian sinh code từ 25s xuống 5–7s.
- **-45% token tiêu thụ**: Loại bỏ hoàn toàn class thừa, wrapper hàm, argparse, logging bloat.
- **Bản diff ngắn nhất chiến thắng (`The shortest working diff wins`)**.

---

### Cổng Chặn Bắt Buộc Tuyệt Đối (Universal Delegation Mandate)
Bất kể tác vụ thuộc ngôn ngữ hay nền tảng nào (Python, C#, C++, TypeScript, Go, SQL, Bash), khi phát sinh công việc nặng (>1 file sửa đổi, >100 dòng dữ liệu, quét cây thư mục, chuyển đổi hàng loạt):
1. **TỐI ĐA 2–3 LƯỢT GỌI TRINH SÁT (Micro-Recon)**: Chỉ dùng 1 lượt tìm đường dẫn/ký hiệu và 1 lượt đọc 3–5 dòng mẫu dữ liệu. Tuyệt đối không đọc lặp nhiều file hay quét đệ quy trong context chính.
2. **CHUYỂN GIAO NGAY LẬP TỨC (Immediate Transition)**: Khi đã xác định được đường dẫn nguồn/đích và cấu trúc mẫu, **BUỘC PHẢI DỪNG ĐỌC/CHẠY LỆNH CỤC BỘ**. Lượt gọi kế tiếp bắt buộc phải là `worker_exec` (script tất định) hoặc `worker_delegate` (script do worker sinh); dùng `free_agent` khi cần sửa nhiều file thật.
3. **MỌI TÁC VỤ ĐỀU ÁP DỤNG ĐƯỢC (Universal Archetypes)**:
   - **Xử lý Dữ liệu & ETL**: CSV, JSON, YAML, XML, SQLite, SQL, Protobuf, TSV, Parquet.
   - **Tái cấu trúc Mã nguồn diện rộng**: Đổi tên class/symbol, cập nhật API cũ sang mới, dọn dẹp code rác trên hàng chục file.
   - **Kiểm định & Audit Tĩnh**: Quét toàn bộ thư mục tìm link hỏng, GUID thiếu, encoding (BOM/CRLF), bảo mật/secret leak.
   - **Sinh Mã Hàng Loạt (Boilerplate)**: Sinh DTO, serializer, interface, mock data, unit test fixtures.
   - **Khai phá Mã nguồn Ngoài (External Repo Mining)**: Quét repo đối tác, submodule, SDK ngoài, server nội bộ mà không làm rác context chính.
   - **Phân tích Log & Dump Khổng Lồ**: Trích xuất nguyên nhân gốc rễ từ hàng megabyte log hoặc crash dump.

---

## 2. Vị Trí Cấu Hình & Cấu Trúc Thành Phần

Toàn bộ hệ thống kỹ năng nằm tại một thư mục duy nhất (pi nạp skill từ đây):
- **Thư mục skill**: `C:\Users\PC\.agents\skills\heavy-task-delegator\`
- **Cầu nối tool**: `scripts\tool.py` (JSON qua stdin) — được gọi bởi extension `C:\Users\PC\.pi\agent\extensions\heavy-task-delegator.ts`, đăng ký 4 tool native `worker_status` / `worker_ask` / `worker_delegate` / `worker_exec`.
- **Engine worker**: `mcp\openrouter_worker.py` (cascade model, guard thời gian, `auto_bom_repair`).

### Bảng Thành Phần File:

| Tên File | Vai Trò & Chức Năng |
|---|---|
| [`SKILL.md`](file:///C:/Users/PC/.agents/skills/heavy-task-delegator/SKILL.md) | File chỉ dẫn trung tâm (workflow, auto-switch Ponytail, QA checklist, harness notes pi 1.4.0). |
| [`USAGE.md`](file:///C:/Users/PC/.agents/skills/heavy-task-delegator/USAGE.md) | Tài liệu hướng dẫn sử dụng chi tiết dành cho người dùng và lập trình viên. |
| [`worker.json`](file:///C:/Users/PC/.agents/skills/heavy-task-delegator/worker.json) | Cấu hình chuỗi model, timeout, và nhật ký benchmark mới nhất (kèm danh sách model bị loại). |
| [`scripts/tool.py`](file:///C:/Users/PC/.agents/skills/heavy-task-delegator/scripts/tool.py) | Cầu nối JSON mà 4 tool native gọi vào — đây là "cổng" duy nhất tới worker. |
| [`scripts/delegate.py`](file:///C:/Users/PC/.agents/skills/heavy-task-delegator/scripts/delegate.py) | Fallback dòng lệnh: `--ask "…"`, `--task spec.md`, `--run-script x.py`. |
| [`resources/delegation_template.md`](file:///C:/Users/PC/.agents/skills/heavy-task-delegator/resources/delegation_template.md) | Khung mẫu prompt giao việc chuẩn mực không gây hiểu nhầm cho Worker. |
| [`references/unity-bridge-playbook.md`](file:///C:/Users/PC/.agents/skills/heavy-task-delegator/references/unity-bridge-playbook.md) | **Domain adapter Unity** — budget gọi tool, bảng tool đã xác minh kèm params, hợp đồng `run_csharp`, thang verify, giao thức sửa scene YAML, recipe playtest. |
| [`references/unity-tools-catalog.md`](file:///C:/Users/PC/.agents/skills/heavy-task-delegator/references/unity-tools-catalog.md) | Catalog 358 tool nội bộ của `unity-synaptic` (sinh từ `get_tools_reference`, unity-mcp 1.1.0). Grep file này thay vì đoán tên tool — 0 call bridge. |
| [`scripts/bench_free_models.py`](file:///C:/Users/PC/.agents/skills/heavy-task-delegator/scripts/bench_free_models.py) | Công cụ tự động chạy benchmark đo lường toàn bộ model free trên OpenRouter. |

---

## 3. Chuỗi Mô Hình Miễn Phí Tối Ưu (Benchmark 2026-10-22)

Hệ thống sử dụng cơ chế **Cascading Fallback** tự động chuyển tầng khi gặp lỗi (429, timeout, network). Chuỗi nằm trong `worker.json` — sửa ở đó, không sửa trong tài liệu này:

```mermaid
flowchart LR
    T1["Tier 1: poolside/laguna-s-2.1:free<br>(5.4s — Siêu tốc độ, Coder)"] -->|"Nếu 429"| T2["Tier 2: nvidia/nemotron-3-ultra:free<br>(10.5s — Cực chuẩn CSV/Schema)"]
    T2 -->|"Nếu lỗi"| T3["Tier 3: openrouter/free<br>(7.7s — Router tự động)"]
    T3 -->|"Nếu lỗi"| T4["Tier 4: minimax/minimax-m3.1-flash:free<br>(16.3s — Chốt chặn tin cậy tuyệt đối)"]
    T4 -->|"Nếu lỗi"| T5["Tier 5: recursive/flint-v1.0:free<br>(40.9s — Model reasoning mới)"]
    T5 -->|"Cả 5 tier fail"| Fallback["Fallback Cuối: Agent chính<br>(key trả phí — Chi phí thấp)"]
```

### Chi Tiết Từng Tier:
1. **Tier 1: `poolside/laguna-s-2.1:free`** (5.4s, 257 tok, 0 reasoning):
   - Chuyên gia sinh mã nhanh nhất hiện nay, phản hồi tức thì trong 5s. Nếu gặp rate-limit 429 sẽ tự động chuyển Tier 2 ngay.
2. **Tier 2: `nvidia/nemotron-3-ultra-550b-a55b:free`** (10.5s, 565 tok):
   - Độ chính xác dữ liệu tuyệt đối, đặc biệt xuất sắc với dialect CSV, tiếng Việt UTF-8 và schema phức tạp.
3. **Tier 3: `openrouter/free`** (7.7s, 435 tok):
   - Router thông minh do chính OpenRouter vận hành, tự chuyển hướng tới free node khỏe nhất.
4. **Tier 4: `minimax/minimax-m3.1-flash:free`** (16.3s, 1610 tok):
   - "Xe tăng bất tử" của hệ thống: Đạt tỷ lệ thành công 100% qua mọi đợt khảo sát, khả năng tự sửa lỗi (repair) cực cao. Từ pi 1.4.0, model này cũng là model hạng nhất trên provider `minimax` / `minimax-cn` (thinking `low`…`max`) — dùng được trực tiếp cho session, không chỉ làm worker.
5. **Tier 5: `recursive/flint-v1.0:free`** (40.9s, 6240 tok):
   - Model reasoning mới vượt qua bài kiểm tra CSV đa ngữ, đóng vai trò chốt đệm trước khi phải dùng key trả phí.

---

## 4. Bốn Công Cụ Worker Native Trong pi

pi đăng ký 4 tool native (tên MCP cũ trong ngoặc để đối chiếu tài liệu cũ). Đây **không phải** MCP — không có `call_mcp_tool`:

```mermaid
classDiagram
    class WorkerNativeTools {
        +worker_status() Config & Status
        +worker_ask(prompt, model) Text Completion
        +worker_exec(code, timeout) Fast-Path Runner
        +worker_delegate(task, timeout, repair) Autonomous Agent
    }
```

Ngoài ra còn một nấc thứ năm: **`free_agent`** — một agent pi lồng nhau chạy trên model free **có đủ tool** (`read`/`bash`/`edit`/`write`). Dùng khi cần sửa thật nhiều file, không chỉ sinh một script. Nó không thấy hội thoại hiện tại, nên task phải tự chứa: mục tiêu, đường dẫn tuyệt đối, ràng buộc, và bước tự kiểm tra.

### 1. `worker_status`
- **Mục đích**: Kiểm tra tình trạng worker, sự tồn tại của API Key OpenRouter, danh sách chuỗi cascade và tính năng `auto_bom_repair`.
- **Đặc điểm**: Chạy trong 0.05s, dùng khi cần chẩn đoán trạng thái hệ thống.

### 2. `worker_ask` (cũ: `ask_worker`)
- **Mục đích**: Sinh văn bản thuần, giải thích code, tóm tắt log, hoặc sinh danh sách hằng số/enum.
- **Đặc điểm**: Không thực thi code, tốc độ 2–4s.

### 3. `worker_exec` (Fast-Path, cũ: `execute_python`)
- **Mục đích**: Chạy ngay lập tức một đoạn mã Python trực tiếp trên máy cục bộ.
- **Đặc điểm**: **0.1s**, 0 token AI. Rất phù hợp cho các tác vụ kiểm tra tính toàn vẹn, đếm dòng, audit format, kiểm tra UTF-8 BOM.

### 4. `worker_delegate` (Autonomous Runner, cũ: `delegate_script`)
- **Mục đích**: Giao trọn gói bản đặc tả (Task Spec) cho Worker: Worker tự viết Python, tự chạy script trên máy (`exit code 0`), tự dọn dẹp file script sau khi xong, và chỉ trả về stdout ngắn gọn cho Agent chính.
- **Đặc điểm**: 5–8s, tự động vá UTF-8 BOM cho các file CSV bị chỉnh sửa, tự sửa lỗi một lần nếu script fail.

### Chuyển Model Của Session
- **`/free`** đưa session sang một model free của OpenRouter.
- **`/paid`** quay về model mặc định trong `settings.json` (`defaultProvider`/`defaultModel`).

---

## 5. Cơ Chế Tự Động Quyết Định Ponytail (Zero-Prompt Auto-Switch)

Người dùng **hoàn toàn không cần phải gõ thêm từ khóa Ponytail**. Kỹ năng sẽ tự động phân tích bản chất công việc để chọn mức độ phù hợp:

```mermaid
flowchart TD
    Req["Nhiệm vụ người dùng"] --> Q1{"Loại công việc là gì?"}
    
    Q1 -->|"CSV / Data / Batch Refactor"| PonytailFull["PONYTAIL FULL<br>Shortest diff, 0 wrappers, UTF-8 BOM"]
    Q1 -->|"Audit / Format check"| PonytailFast["PONYTAIL FAST-PATH<br>Gọi trực tiếp worker_exec (0.1s)"]
    Q1 -->|"Phức tạp hóa không cần thiết"| PonytailUltra["PONYTAIL ULTRA<br>Tự động phản biện, thay bằng 5 dòng stdlib"]
    Q1 -->|"Thiết kế Architecture / System"| PonytailLite["PONYTAIL LITE<br>Giữ nguyên cấu trúc/interface cần thiết"]
    Q1 -->|"3D Canvas HTML / Visual Tool"| PonytailOff["PONYTAIL OFF<br>Cho phép code đầy đủ đồ họa & UI"]
```

---

## 6. Bộ Guard Nhiều Tầng Phòng Vệ Toàn Diện (Zero-Crash & Zero-Timeout)

Để giải quyết triệt để lỗi treo `context deadline exceeded (3m0s)` và bảo đảm an toàn dữ liệu, hệ thống thiết lập các tầng bảo vệ cứng:

### Guard Tầng 1: Chốt Chặn Thời Gian Tổng (Worker Backend Hard Budget)
- **Ngân sách tối đa**: Toàn bộ vòng lặp cascade trong `mcp/openrouter_worker.py` bị giới hạn cứng ở **80 giây**. Nếu vượt quá 80s, backend lập tức ngắt cascade và trả về kết quả dự phòng, không bao giờ để client chờ đến 180s.
- **Subprocess Timeout**: Rút ngắn từ 90s xuống **45 giây**.
- **Tổng thời gian tối đa lý thuyết**: 80s + 45s = **125 giây $\ll$ 180 giây** Deadline của tool call.

### Guard Tầng 2: Quy Tắc Fast-Path vs Slow-Path
- Tác vụ Audit / Đếm số / So khớp $\rightarrow$ Dùng `worker_exec` (0.1s).
- Tác vụ Sinh giải thuật chuyển đổi mới $\rightarrow$ Dùng `worker_delegate` (<15s).
- Tác vụ sửa nhiều file thật $\rightarrow$ Dùng `free_agent` (agent lồng nhau, có đủ tool).

### Guard Tầng 3: Tự Động Bảo Toàn UTF-8 BOM (`auto_bom_repair`)
- Mọi file `.csv` bị can thiệp bởi script trong vòng 120s sẽ tự động được kiểm tra 3 byte đầu (`0xEF, 0xBB, 0xBF`). Nếu thiếu, backend tự động chèn thêm vào đầu file để bảo đảm Unity Editor `ExcelExporter` không bao giờ bị crash.

### Guard Tầng 4: Tự Phục Hồi (Graceful Self-Healing)
- Nếu `worker_delegate` gặp lỗi mạng, Agent không bao giờ dừng lại cụt ngủn mà tự động chuyển sang `worker_exec` hoặc dùng `read` mở trực tiếp 5–10 dòng để đối chiếu và xuất báo cáo đầy đủ cho người dùng.
- Nếu mọi tier free đều fail: thử `free_agent` (model free khác), rồi `/free` để đổi model session, cuối cùng mới tự làm phần tối thiểu trong context chính.

### Guard Tầng 5: Ràng Buộc Nền Tảng pi 1.4.0 (bắt buộc tuân thủ)
- **Codemode chỉ có 2 worker dùng chung**: script song song (hoặc subagent in-process) sẽ **xếp hàng tới 60s** thay vì fail ngay; `PI_CODEMODE_MAX_WORKERS=N` nâng giới hạn. Vì vậy hãy gom nhiều việc vào **một** script codemode với `Promise.allSettled(...)` thay vì gọi song song nhiều script.
- **`// @options:` phải nằm ở dòng 1** của script codemode; đặt ở chỗ khác thì call fail *trước khi* chạy. Đây cũng là nơi đặt `timeout_ms` cho audit dài.
- **Output bị chặn trần**: 16 Mi ký tự / 100 000 item cho một script — một vòng lặp `print` sẽ giết cả lượt chạy. Script worker chỉ in **thống kê** (`processed=… errors=…`), không in từng dòng dữ liệu.
- **`models.classify()` nhận ảnh** (TypeSafe Jev, Cloudflare Clef trên `typesafe`, `cloudflare-workers-ai`, `openrouter`) và có `models.generateImages()`. Dùng classifier để phân loại nhanh ("file này là CSV hay log?") thay vì tốn cả một lượt worker. `tools.read()` trên file ảnh trả về image block, `image()` hiển thị và lưu kèm đường dẫn temp.
- **Không ủy quyền việc tóm tắt**: compaction và branch summary giờ dùng output limit của model (`compaction.reserveTokens` chỉ quyết định *khi nào* nén), nên `/compact` không còn chết vì reasoning dài — không có gì để worker cứu.
- **Tìm kiếm**: grep tích hợp chạy `rg --no-config` (biến `RIPGREP_CONFIG_PATH` không còn âm thầm biến regex thành literal); `codebase_memory.search_code` nhận `pattern` (không phải `query`), `search_graph` nhận `query`, và phải gọi `codebase_projects` trước để biết tên project.
- **Windows**: mọi `workdir` phải là đường dẫn native (`C:\…`); `/tmp/…` và `/d/…` fail với "workdir not found". Không có POSIX temp — dùng `%LOCALAPPDATA%\Temp`.

---

## 7. Quy Trình Vận Hành Chuẩn 3 Pha (SOP)

### Pha 1: Trinh Sát Cấu Trúc (Recon)
- Dùng `codebase-memory-mcp` định vị symbol / file (`search_code` với `pattern`, `search_graph` với `query`, `trace_path`).
- Chỉ đọc 3–5 dòng mẫu của bảng CSV hoặc JSON schema. Tuyệt đối không đọc cả thư mục.
- Kiểm tra xem thư mục `tools/` đã có sẵn script tương tự chưa để tái sử dụng.

### Pha 2: Ủy Quyền Worker (Delegation)
- Đóng gói Task Spec rõ ràng:
  1. Mục tiêu duy nhất trong 1–2 câu.
  2. Đường dẫn file tuyệt đối chính xác.
  3. Guardrails: Bắt buộc `encoding='utf-8-sig'`, giữ nguyên 2 dòng header, ô số rỗng thay bằng `0`.
  4. Lệnh tự kiểm tra: In ra `status=PASS lines=N`.

### Pha 3: Thẩm Định Chất Lượng (QA Gate)
- `git diff --stat`: Chỉ những file chỉ định mới được phép thay đổi.
- Kiểm tra UTF-8 BOM: 3 byte đầu bắt buộc là `0xEF, 0xBB, 0xBF`.
- Kiểm tra Lean: Không phát sinh code chết, class thừa.
- **Ponytail Disclosure**: Kết thúc câu trả lời bằng 1–2 dòng tóm tắt những gì đã bỏ qua và rủi ro nếu có.

---

## 8. Ví Dụ Thực Tế Đã Kiểm Chứng

### Ví Dụ 1: Audit Nhanh Bảng Dữ Liệu `MainUiTable.csv`
- **Cách xử lý**: Agent kích hoạt `PONYTAIL FAST-PATH`, gọi `worker_exec` quét 31 dòng dữ liệu trong 0.2s.
- **Kết quả phát hiện**: Phát hiện lỗi ống kép `117||118` tại dòng 22 cột `MainIcon` tạo phần tử rỗng trong `vector<int>`, đề xuất sửa thành `117|118`.

### Ví Dụ 2: Chuyển Đổi Hàng Ngàn Icon Metin2 Sang Atlas
- **Cách xử lý**: Giao Task Spec qua `worker_delegate`.
- **Kết quả**: Worker sinh script Python 25 dòng dùng thư viện Pillow chia tách 1,534 icon thành 5 folder Atlas trong `artres/_UI/` và sinh 5 file `info.json` chỉ trong 8.2s.
