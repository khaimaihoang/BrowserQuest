#!/usr/bin/env python3
"""openrouter-worker — MCP stdio server that uses a cheap OpenRouter model as a bulk-work worker.

Tools
  worker_status    : config / key / python sanity check
  ask_worker       : one-shot text completion from the worker model
  delegate_script  : worker model writes a Python script, server runs it locally, returns stdout only
  execute_python   : run a Python script you already have (code string or path)

Design rule: file content never travels back into the caller's context. Only exit codes,
stdout/stderr tails (capped) are returned, so heavy/mechanical work costs almost no tokens.
"""

import json
import os
import re
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

API_URL = "https://openrouter.ai/api/v1/chat/completions"
PROTOCOL_VERSION = "2024-11-05"


def _file_config() -> dict:
    """Runtime config next to the skill: re-read on every spawn, so no pi restart for model swaps."""
    path = Path(__file__).resolve().parent.parent / "worker.json"
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return {}


_CFG = _file_config()


def _pick(key: str, env_name: str, default: str) -> str:
    return str(_CFG.get(key) or os.environ.get(env_name) or default).strip()


def _pick_list(key: str) -> list:
    value = _CFG.get(key)
    if not isinstance(value, list):
        return []
    return [str(item).strip() for item in value if str(item).strip()]


DEFAULT_MODEL = _pick("model", "OPENROUTER_WORKER_MODEL", "poolside/laguna-s-2.1:free")
RESERVE_MODEL = _pick("reserve", "OPENROUTER_WORKER_RESERVE", "nvidia/nemotron-3-ultra-550b-a55b:free")
ROUTER_MODEL = _pick("router", "OPENROUTER_WORKER_ROUTER", "openrouter/free")
CHAIN = _pick_list("chain")
HTTP_TIMEOUT_S = int(_pick("http_timeout_s", "OPENROUTER_WORKER_HTTP_TIMEOUT_S", "35"))
REASONING_EFFORT = _pick("reasoning_effort", "OPENROUTER_WORKER_REASONING_EFFORT", "low")
MAX_SCRIPT_TOKENS = int(_pick("max_script_tokens", "OPENROUTER_WORKER_MAX_SCRIPT_TOKENS", "16384"))
MAX_OUTPUT = int(_pick("max_output", "OPENROUTER_WORKER_MAX_OUTPUT", "4000"))


class WorkerUnavailable(RuntimeError):
    """OpenRouter could not answer: the caller must stop delegating and do the work itself."""

SYSTEM_SCRIPT = (
    "You are a lazy senior Python developer (Ponytail principle: the best code is the code never written). "
    "Reply with ONE ```python fenced block and nothing else. The shortest working script wins: standard library only, "
    "zero wrappers, zero classes, zero logging bloat. "
    "Rules: read and write every file with encoding='utf-8-sig' and newline='' ONLY (never the locale "
    "default); preserve all existing text bytes exactly; never re-encode, never strip, reformat or re-add "
    "header rows; edit only the exact paths given (never search directories for other files); standard "
    "library only; no TODO, no placeholders, no prose; print exactly the short summary the task asks for. "
    "Every module you reference must be imported at the top of the file. "
    "The script must be idempotent. "
    "For CSV use exactly this pattern: "
    "with open(p, encoding='utf-8-sig', newline='') as f: rows = list(csv.reader(f)); "
    "...modify rows in memory...; "
    "with open(p, 'w', encoding='utf-8-sig', newline='') as f: csv.writer(f, lineterminator='\\n').writerows(rows). "
    "csv.writer must receive an open file object (or io.StringIO), never a str or list."
)
SYSTEM_ASK = (
    "You are a precise mechanical coding worker. Answer only what is asked, minimal tokens, "
    "no preamble, no restating the question."
)

FENCE = re.compile(r"```(?:python|py)?\s*\n(.*?)```", re.S)


# --------------------------------------------------------------------------- helpers

def agent_dir() -> Path:
    env = os.environ.get("PI_AGENT_DIR")
    return Path(env) if env else Path.home() / ".pi" / "agent"


def api_key() -> str:
    key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    if key:
        return key
    auth = agent_dir() / "auth.json"
    try:
        data = json.loads(auth.read_text(encoding="utf-8-sig"))
    except OSError as exc:
        raise RuntimeError(f"cannot read {auth}: {exc}")
    entry = data.get("openrouter") or {}
    for field in ("key", "access", "apiKey"):  # pi uses key, older installs used access
        key = (entry.get(field) or "").strip()
        if key.startswith("sk-or-"):
            return key
    raise RuntimeError("no OpenRouter key: set OPENROUTER_API_KEY or ~/.pi/agent/auth.json openrouter.key")


def cap(text: str, limit: int = MAX_OUTPUT) -> str:
    text = (text or "").replace("\r\n", "\n").rstrip()
    if len(text) <= limit:
        return text
    return f"…[{len(text) - limit} chars trimmed]…\n" + text[-limit:]


def _messages(prompt: str, system: str) -> list:
    return [{"role": "system", "content": system}, {"role": "user", "content": prompt}]


def _completion(url: str, key: str, model: str, messages: list, max_tokens: int, temperature: float, timeout_s: int | None = None) -> str:
    payload = {"model": model, "messages": messages, "max_tokens": max_tokens, "temperature": temperature}
    if REASONING_EFFORT and REASONING_EFFORT.lower() not in ("off", "none", "0"):
        payload["reasoning"] = {"effort": REASONING_EFFORT}
    data = json.dumps(payload).encode("utf-8")
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    if "openrouter" in url:
        headers["HTTP-Referer"] = "https://localhost/pi-openrouter-worker"
        headers["X-Title"] = "pi-openrouter-worker"
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    timeout = timeout_s or HTTP_TIMEOUT_S
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(req, timeout=timeout) as resp:
            body = json.loads(resp.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:400]
        raise RuntimeError(f"HTTP {exc.code}: {detail}")
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise RuntimeError(f"network/timeout ({timeout}s): {exc}")
    choices = body.get("choices") or []
    if not choices:
        raise RuntimeError(f"empty response: {cap(json.dumps(body), 300)}")
    choice = choices[0]
    content = (choice.get("message") or {}).get("content") or ""
    if not content.strip():
        usage = body.get("usage") or {}
        reasoning = ((usage.get("completion_tokens_details") or {}).get("reasoning_tokens")) or 0
        raise RuntimeError(
            f"empty completion (finish={choice.get('finish_reason')}, completion_tokens={usage.get('completion_tokens')}, "
            f"reasoning_tokens={reasoning}) - reasoning ate the budget; lower reasoning_effort or raise max_tokens"
        )
    return content


def chat(prompt: str, system: str, model: str, max_tokens: int = 8192, temperature: float = 0.1, timeout_s: int | None = None) -> str:
    """OpenRouter completion."""
    return _completion(API_URL, api_key(), model, _messages(prompt, system), max_tokens, temperature, timeout_s)


def worker_chain() -> list:
    """Free tiers in the order they were benchmarked, then the always-up free router."""
    models = CHAIN or [m for m in (DEFAULT_MODEL, RESERVE_MODEL, ROUTER_MODEL) if m]
    chain, seen = [], set()
    for model in models:
        if model in seen:
            continue
        seen.add(model)
        chain.append((f"openrouter:{model}", lambda p, s, m, mdl=model: chat(p, s, mdl, m)))
    return chain


def complete(prompt: str, system: str, model: str | None = None, max_tokens: int = 8192) -> tuple[str, str]:
    """No model override -> walk the full chain. Explicit model -> one attempt only."""
    if model:
        return chat(prompt, system, model, max_tokens), model
    errors = []
    t_start = time.time()
    for label, call in worker_chain():
        if time.time() - t_start > 80:
            errors.append("cascade overall safety budget (80s) reached to protect MCP transport deadline")
            break
        try:
            return call(prompt, system, max_tokens), label
        except RuntimeError as exc:
            errors.append(f"{label} -> {exc}")
    raise WorkerUnavailable(" | ".join(errors) or "no worker tier available")


def extract_code(text: str) -> str:
    blocks = FENCE.findall(text or "")
    if blocks:
        return max(blocks, key=len).strip("\n")
    stripped = (text or "").strip()
    if stripped.startswith(("import ", "from ", "#!", "def ", "class ", '"""')):
        return stripped
    raise RuntimeError(f"worker returned no python block: {cap(text, 300)}")


def workdir_of(value) -> Path:
    path = Path(value or os.getcwd()).expanduser()
    if not path.is_dir():
        raise RuntimeError(f"workdir not found: {path}")
    return path.resolve()


def _ensure_csv_bom(workdir: Path) -> list[str]:
    """Ensure any recently modified CSV file in workdir has UTF-8 BOM (0xEF, 0xBB, 0xBF)."""
    healed = []
    bom = b"\xef\xbb\xbf"
    now = time.time()
    try:
        for root, dirs, files in os.walk(workdir):
            dirs[:] = [d for d in dirs if d not in (".git", "Library", "Temp", "Logs", "Packages", ".delegate")]
            for f in files:
                if f.lower().endswith(".csv"):
                    p = Path(root) / f
                    try:
                        mtime = p.stat().st_mtime
                        if (now - mtime) <= 120:
                            data = p.read_bytes()
                            if data and not data.startswith(bom):
                                p.write_bytes(bom + data)
                                healed.append(str(p.relative_to(workdir)))
                    except OSError:
                        pass
    except OSError:
        pass
    return healed


def _run(code: str, workdir: Path, timeout_s: int, keep_script: bool) -> dict:
    target_dir = workdir if os.access(workdir, os.W_OK) else Path(tempfile.gettempdir())
    script_dir = target_dir / ".delegate"
    script_dir.mkdir(exist_ok=True)
    fd, raw_path = tempfile.mkstemp(suffix=".py", dir=str(script_dir), prefix="worker_")
    path = Path(raw_path)
    with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(code if code.endswith("\n") else code + "\n")

    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    env["PYTHONLEGACYWINDOWSSTDIO"] = "0"

    try:
        proc = subprocess.run(
            [sys.executable, str(path)],
            cwd=str(workdir),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=env,
            timeout=timeout_s,
        )
        exit_code, out, err = proc.returncode, proc.stdout, proc.stderr
    except subprocess.TimeoutExpired as exc:
        exit_code = 124
        out = exc.stdout if isinstance(exc.stdout, str) else ""
        err = f"TIMEOUT after {timeout_s}s"

    bom_healed = []
    if exit_code == 0:
        bom_healed = _ensure_csv_bom(workdir)
        if not keep_script:
            path.unlink(missing_ok=True)
            script_note = "deleted (success)"
        else:
            script_note = str(path)
    else:
        script_note = str(path)
    return {"exit": exit_code, "stdout": out, "stderr": err, "script": script_note, "path": path, "bom_healed": bom_healed}


def _format_run(result: dict, note: str = "") -> str:
    parts = [f"exit={result['exit']}", f"script={result['script']}"]
    if result.get("bom_healed"):
        parts.append(f"bom_auto_fixed={', '.join(result['bom_healed'])}")
    if note:
        parts.append(note)
    if result["stdout"].strip():
        parts.append("--- stdout ---\n" + cap(result["stdout"]))
    if result["stderr"].strip():
        parts.append("--- stderr ---\n" + cap(result["stderr"]))
    return "\n".join(parts)


def run_script(code: str, workdir: Path, timeout_s: int, keep_script: bool) -> str:
    return _format_run(_run(code, workdir, timeout_s, keep_script))


def tool_result(text: str, is_error: bool = False) -> dict:
    return {"content": [{"type": "text", "text": text}], "isError": is_error}


# --------------------------------------------------------------------------- tools

def tool_worker_status(args: dict) -> dict:
    key = ""
    try:
        key = "present" if api_key() else "missing"
    except RuntimeError as exc:
        key = f"missing ({exc})"
    chain = worker_chain()
    lines = [f"chain ({len(chain)} free tiers, then the main agent):"]
    for index, (label, _) in enumerate(chain, start=1):
        lines.append(f"  {index}. {label}")
    lines += [
        f"openrouter_key={key}",
        f"python={sys.version.split()[0]}",
        f"cwd={os.getcwd()}",
        f"reasoning_effort={REASONING_EFFORT} max_script_tokens={MAX_SCRIPT_TOKENS} max_output_chars={MAX_OUTPUT}",
        f"http_timeout_s={HTTP_TIMEOUT_S} auto_bom_repair=active (UTF-8 BOM auto-enforced for Unity)",
        "tier_last=main agent on DeepSeek key (does the work when every free tier fails)",
    ]
    return tool_result("\n".join(lines))


def tool_ask_worker(args: dict) -> dict:
    prompt = (args.get("prompt") or "").strip()
    if not prompt:
        return tool_result("prompt is required", True)
    model = args.get("model") or None
    text, used = complete(prompt, SYSTEM_ASK, model, int(args.get("max_tokens") or 4096))
    return tool_result(f"[model={used}]\n{cap(text)}")


def tool_delegate_script(args: dict) -> dict:
    task = (args.get("task") or "").strip()
    if not task:
        return tool_result("task is required (full spec: objective, target files, guardrails, verification)", True)
    model = args.get("model") or None
    workdir = workdir_of(args.get("workdir"))
    timeout_s = int(args.get("timeout_s") or 600)
    max_tokens = int(args.get("max_tokens") or MAX_SCRIPT_TOKENS)

    prompt = (
        f"Working directory: {workdir}\n"
        f"Python interpreter: {sys.version.split()[0]}\n\n"
        f"TASK SPEC\n{task}\n"
    )
    text, used = complete(prompt, SYSTEM_SCRIPT, model, max_tokens)
    try:
        code = extract_code(text)
    except RuntimeError as exc:
        return tool_result(f"[model={used}] {exc}", True)

    result = _run(code, workdir, timeout_s, bool(args.get("keep_script")))
    note = ""
    repair = args.get("repair", True)
    if result["exit"] != 0 and repair:
        fix_prompt = (
            f"Working directory: {workdir}\n"
            "The Python script below failed when executed. Fix the actual bug and return the FULL "
            "corrected script in one ```python block. Same rules as before.\n\n"
            f"--- failing script ---\n{code}\n\n--- stderr (tail) ---\n{cap(result['stderr'], 1500)}"
        )
        try:
            fixed_text, repaired_by = complete(fix_prompt, SYSTEM_SCRIPT, model, max_tokens)
            fixed_code = extract_code(fixed_text)
        except RuntimeError as exc:
            note = f"repair=skipped ({cap(str(exc), 200)})"
        else:
            retried = _run(fixed_code, workdir, timeout_s, bool(args.get("keep_script")))
            if retried["exit"] == 0:
                result["path"].unlink(missing_ok=True)
            result = retried
            used = f"{used} +repair:{repaired_by}"
            note = "repair=applied"

    return tool_result(f"[model={used}]\n" + _format_run(result, note))


def tool_execute_python(args: dict) -> dict:
    workdir = workdir_of(args.get("workdir"))
    timeout_s = int(args.get("timeout_s") or 600)
    code = (args.get("code") or "").strip()
    script_path = (args.get("script_path") or "").strip()
    if script_path:
        path = Path(script_path).expanduser()
        if not path.is_absolute():
            path = workdir / path
        if not path.is_file():
            return tool_result(f"script not found: {path}", True)
        code = path.read_text(encoding="utf-8")
    if not code:
        return tool_result("code or script_path is required", True)
    return tool_result(run_script(code, workdir, timeout_s, bool(args.get("keep_script"))))


TOOLS = [
    {
        "name": "worker_status",
        "description": "Report the worker model, OpenRouter key availability, python version, and cwd. Call this first when a delegation fails.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "ask_worker",
        "description": "Send a single prompt to the cheap worker model (default deepseek flash via OpenRouter) and return only its answer, capped. Use for boilerplate generation, log parsing rules, regex/enum scaffolding, or a second opinion — never for architecture decisions.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "The full request with all needed context pasted inline."},
                "model": {"type": "string", "description": "OpenRouter model id override. Bypasses the free->free->deepseek chain for a single attempt."},
                "max_tokens": {"type": "integer", "description": "Response cap, default 4096."},
            },
            "required": ["prompt"],
        },
    },
    {
        "name": "delegate_script",
        "description": "Hand a heavy/mechanical spec to the worker model: it writes a Python script, the server runs it locally in workdir, and only exit code plus capped stdout/stderr come back. Use for bulk CSV/table transforms, mass refactors, log parsing. The script is auto-deleted on success and kept (path returned) on failure.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "Complete spec: objective, exact target file paths, guardrails (encoding/BOM, header rows, no empty numeric cells, untouched files), and self-verification commands.",
                },
                "workdir": {"type": "string", "description": "Directory the script runs in (default: server cwd)."},
                "model": {"type": "string", "description": "OpenRouter model id override. Bypasses the free->free->deepseek chain for a single attempt."},
                "timeout_s": {"type": "integer", "description": "Script execution timeout, default 600."},
                "max_tokens": {"type": "integer", "description": "Code generation cap, default 8192."},
                "keep_script": {"type": "boolean", "description": "Keep the generated script even on success."},
                "repair": {
                    "type": "boolean",
                    "description": "On a runtime failure, feed the traceback back to the worker for ONE fix attempt (default true).",
                },
            },
            "required": ["task"],
        },
    },
    {
        "name": "execute_python",
        "description": "Run a Python script locally without any model call: pass `code` inline or `script_path`. Returns exit code plus capped stdout/stderr. Use for deterministic, already-reviewed transforms.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "Python source to run."},
                "script_path": {"type": "string", "description": "Path to an existing .py file (relative to workdir allowed)."},
                "workdir": {"type": "string", "description": "Directory the script runs in (default: server cwd)."},
                "timeout_s": {"type": "integer", "description": "Timeout, default 600."},
                "keep_script": {"type": "boolean", "description": "Keep the temp script after success."},
            },
        },
    },
]

HANDLERS = {
    "worker_status": tool_worker_status,
    "ask_worker": tool_ask_worker,
    "delegate_script": tool_delegate_script,
    "execute_python": tool_execute_python,
}


# --------------------------------------------------------------------------- jsonrpc

def send(message: dict) -> None:
    sys.stdout.write(json.dumps(message) + "\n")
    sys.stdout.flush()


def handle(msg: dict) -> None:
    method = msg.get("method")
    msg_id = msg.get("id")
    params = msg.get("params") or {}

    if method == "initialize":
        send(
            {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "protocolVersion": params.get("protocolVersion") or PROTOCOL_VERSION,
                    "capabilities": {"tools": {"listChanged": False}},
                    "serverInfo": {"name": "openrouter-worker", "version": "1.0.0"},
                },
            }
        )
        return

    if method in ("notifications/initialized", "initialized"):
        return

    if method == "ping":
        send({"jsonrpc": "2.0", "id": msg_id, "result": {}})
        return

    if method == "tools/list":
        send({"jsonrpc": "2.0", "id": msg_id, "result": {"tools": TOOLS}})
        return

    if method == "tools/call":
        name = params.get("name")
        handler = HANDLERS.get(name)
        if handler is None:
            send({"jsonrpc": "2.0", "id": msg_id, "error": {"code": -32601, "message": f"unknown tool: {name}"}})
            return
        try:
            result = handler(params.get("arguments") or {})
        except WorkerUnavailable as exc:
            result = tool_result(
                "WORKER_UNAVAILABLE - delegation is closed. Do not retry, do not switch models.\n"
                f"Reason: {exc}\n"
                "Action: both free tiers failed. Do this task yourself right now in the main session "
                "on the user's DeepSeek key (normal tools: read/edit/write/bash). Do not retry the "
                "worker, do not switch models, do not ask the user unless the job really exceeds the "
                "remaining budget.",
                True,
            )
        except Exception as exc:  # surface any failure as a tool error, never crash the server
            result = tool_result(f"{type(exc).__name__}: {exc}", True)
        send({"jsonrpc": "2.0", "id": msg_id, "result": result})
        return

    if msg_id is not None:
        send({"jsonrpc": "2.0", "id": msg_id, "error": {"code": -32601, "message": f"unsupported method: {method}"}})


def main() -> None:
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(msg, list):
            for item in msg:
                handle(item)
        else:
            handle(msg)


if __name__ == "__main__":
    main()
